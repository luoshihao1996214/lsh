/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50553
Source Host           : localhost:3306
Source Database       : phpmywind_db

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2017-07-04 23:52:45
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for pmw_admanage
-- ----------------------------
DROP TABLE IF EXISTS `pmw_admanage`;
CREATE TABLE `pmw_admanage` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '信息id',
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '1' COMMENT '站点id',
  `classid` smallint(5) unsigned NOT NULL COMMENT '投放范围(广告位)',
  `parentid` smallint(5) unsigned NOT NULL COMMENT '所属广告位父id',
  `parentstr` varchar(80) NOT NULL COMMENT '所属广告位父id字符串',
  `title` varchar(30) NOT NULL COMMENT '广告标识',
  `admode` char(10) NOT NULL COMMENT '展示模式',
  `picurl` varchar(100) NOT NULL COMMENT '上传内容地址',
  `adtext` text NOT NULL COMMENT '展示内容',
  `linkurl` varchar(255) NOT NULL COMMENT '跳转链接',
  `orderid` smallint(5) unsigned NOT NULL COMMENT '排列排序',
  `posttime` int(10) unsigned NOT NULL COMMENT '提交时间',
  `checkinfo` enum('true','false') NOT NULL COMMENT '审核状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_admanage
-- ----------------------------
INSERT INTO `pmw_admanage` VALUES ('1', '1', '1', '0', '0,', 'QQ电脑管家', 'image', '', '', 'http://guanjia.qq.com/', '1', '1326771010', 'true');
INSERT INTO `pmw_admanage` VALUES ('2', '1', '2', '0', '0,', '迅雷看看', 'image', '', '', 'http://www.xunlei.com/', '2', '1326771024', 'true');

-- ----------------------------
-- Table structure for pmw_admin
-- ----------------------------
DROP TABLE IF EXISTS `pmw_admin`;
CREATE TABLE `pmw_admin` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '信息id',
  `username` varchar(30) NOT NULL COMMENT '用户名',
  `password` char(32) NOT NULL COMMENT '密码',
  `nickname` char(32) NOT NULL COMMENT '昵称',
  `question` tinyint(1) unsigned NOT NULL COMMENT '登录提问',
  `answer` varchar(50) NOT NULL COMMENT '登录回答',
  `levelname` tinyint(1) unsigned NOT NULL COMMENT '级别',
  `checkadmin` enum('true','false') NOT NULL COMMENT '审核',
  `loginip` char(20) NOT NULL COMMENT '登录IP',
  `logintime` int(10) unsigned NOT NULL COMMENT '登录时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_admin
-- ----------------------------
INSERT INTO `pmw_admin` VALUES ('1', 'admin', 'c3284d0f94606de1fd2af172aba15bf3', '', '0', '', '1', 'true', '0.0.0.0', '1499148259');

-- ----------------------------
-- Table structure for pmw_admingroup
-- ----------------------------
DROP TABLE IF EXISTS `pmw_admingroup`;
CREATE TABLE `pmw_admingroup` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT COMMENT '管理组id',
  `groupname` varchar(30) NOT NULL COMMENT '管理组名称',
  `description` text NOT NULL COMMENT '管理组描述',
  `groupsite` varchar(30) NOT NULL COMMENT '默认进入站',
  `checkinfo` set('true','false') NOT NULL COMMENT '审核状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_admingroup
-- ----------------------------
INSERT INTO `pmw_admingroup` VALUES ('1', '超级管理员', '超级管理员组', '1', 'true');
INSERT INTO `pmw_admingroup` VALUES ('2', '站点管理员', '站点管理员组', '1', 'true');
INSERT INTO `pmw_admingroup` VALUES ('3', '文章发布员', '文章发布员组', '1', 'true');

-- ----------------------------
-- Table structure for pmw_adminnotes
-- ----------------------------
DROP TABLE IF EXISTS `pmw_adminnotes`;
CREATE TABLE `pmw_adminnotes` (
  `uname` varchar(30) NOT NULL COMMENT '用户名',
  `body` mediumtext NOT NULL COMMENT '便签内容',
  `posttime` int(10) unsigned NOT NULL COMMENT '提交时间',
  `postip` varchar(30) NOT NULL COMMENT '提交IP',
  PRIMARY KEY (`uname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_adminnotes
-- ----------------------------

-- ----------------------------
-- Table structure for pmw_adminprivacy
-- ----------------------------
DROP TABLE IF EXISTS `pmw_adminprivacy`;
CREATE TABLE `pmw_adminprivacy` (
  `groupid` tinyint(3) unsigned NOT NULL COMMENT '所属管理组id',
  `siteid` tinyint(1) unsigned NOT NULL COMMENT '站点id',
  `model` varchar(30) NOT NULL COMMENT '管理模块',
  `classid` int(10) NOT NULL COMMENT '类型id',
  `action` varchar(10) NOT NULL COMMENT '可执行操作'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_adminprivacy
-- ----------------------------
INSERT INTO `pmw_adminprivacy` VALUES ('2', '0', 'upload_filemgr_sql', '0', 'all');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '0', 'web_config', '0', 'all');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '0', 'admin', '0', 'all');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '0', 'database_backup', '0', 'all');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '0', 'infoclass', '0', 'all');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '0', 'info', '0', 'all');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '0', 'infolist', '0', 'all');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '0', 'infoimg', '0', 'all');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '0', 'soft', '0', 'all');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '0', 'goodstype', '0', 'all');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '0', 'goods', '0', 'all');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '0', 'infoclass', '0', 'all');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '0', 'info', '0', 'all');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '0', 'infolist', '0', 'all');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '0', 'infoimg', '0', 'all');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '0', 'soft', '0', 'all');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '0', 'goodstype', '0', 'all');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '0', 'goods', '0', 'all');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '13', 'del');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '13', 'update');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '13', 'add');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '13', 'list');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '12', 'del');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '12', 'update');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '12', 'add');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '12', 'list');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '11', 'del');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '11', 'update');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '11', 'add');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '11', 'list');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '10', 'del');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '10', 'update');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '10', 'add');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '10', 'list');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '9', 'del');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '9', 'update');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '9', 'add');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '9', 'list');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '8', 'del');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '8', 'update');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '8', 'add');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '8', 'list');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '7', 'del');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '7', 'update');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '7', 'add');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '7', 'list');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '6', 'del');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '6', 'update');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '6', 'add');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '6', 'list');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '5', 'del');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '5', 'update');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '5', 'add');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '5', 'list');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '4', 'del');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '4', 'update');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '4', 'add');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '4', 'list');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '3', 'del');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '3', 'update');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '3', 'add');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '3', 'list');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '2', 'del');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '2', 'update');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '2', 'add');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '2', 'list');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '1', 'del');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '1', 'update');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '1', 'add');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '1', 'category', '1', 'list');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '0', 'message', '0', 'all');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '0', 'weblink', '0', 'all');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '0', 'job', '0', 'all');
INSERT INTO `pmw_adminprivacy` VALUES ('2', '0', 'nav', '0', 'all');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '1', 'list');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '1', 'add');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '1', 'update');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '1', 'del');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '2', 'list');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '2', 'add');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '2', 'update');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '2', 'del');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '3', 'list');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '3', 'add');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '3', 'update');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '3', 'del');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '4', 'list');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '4', 'add');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '4', 'update');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '4', 'del');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '5', 'list');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '5', 'add');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '5', 'update');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '5', 'del');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '6', 'list');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '6', 'add');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '6', 'update');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '6', 'del');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '7', 'list');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '7', 'add');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '7', 'update');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '7', 'del');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '8', 'list');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '8', 'add');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '8', 'update');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '8', 'del');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '9', 'list');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '9', 'add');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '9', 'update');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '9', 'del');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '10', 'list');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '10', 'add');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '10', 'update');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '10', 'del');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '11', 'list');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '11', 'add');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '11', 'update');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '11', 'del');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '12', 'list');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '12', 'add');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '12', 'update');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '12', 'del');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '13', 'list');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '13', 'add');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '13', 'update');
INSERT INTO `pmw_adminprivacy` VALUES ('3', '1', 'category', '13', 'del');

-- ----------------------------
-- Table structure for pmw_adtype
-- ----------------------------
DROP TABLE IF EXISTS `pmw_adtype`;
CREATE TABLE `pmw_adtype` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '广告位id',
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '1' COMMENT '站点id',
  `parentid` smallint(5) unsigned NOT NULL COMMENT '上级id',
  `parentstr` varchar(50) NOT NULL COMMENT '上级id字符串',
  `classname` varchar(30) NOT NULL COMMENT '广告位名称',
  `width` smallint(5) unsigned NOT NULL COMMENT '广告位宽度',
  `height` smallint(5) unsigned NOT NULL COMMENT '广告位高度',
  `orderid` smallint(5) unsigned NOT NULL COMMENT '排列顺序',
  `checkinfo` enum('true','false') NOT NULL COMMENT '审核状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_adtype
-- ----------------------------
INSERT INTO `pmw_adtype` VALUES ('1', '1', '0', '0,', '首页广告位', '1003', '80', '1', 'true');
INSERT INTO `pmw_adtype` VALUES ('2', '1', '0', '0,', '子页广告位', '100', '70', '2', 'true');

-- ----------------------------
-- Table structure for pmw_cascade
-- ----------------------------
DROP TABLE IF EXISTS `pmw_cascade`;
CREATE TABLE `pmw_cascade` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '级联组id',
  `groupname` varchar(30) NOT NULL COMMENT '级联组名称',
  `groupsign` varchar(30) NOT NULL COMMENT '级联组标识',
  `orderid` smallint(5) unsigned NOT NULL COMMENT '排列排序',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_cascade
-- ----------------------------
INSERT INTO `pmw_cascade` VALUES ('1', '地区', 'area', '1');
INSERT INTO `pmw_cascade` VALUES ('2', '星座', 'astro', '2');
INSERT INTO `pmw_cascade` VALUES ('3', '血型', 'bloodtype', '3');
INSERT INTO `pmw_cascade` VALUES ('4', '证件类型', 'cardtype', '4');
INSERT INTO `pmw_cascade` VALUES ('5', '安全问题', 'question', '5');
INSERT INTO `pmw_cascade` VALUES ('6', '行业分布', 'trade', '6');

-- ----------------------------
-- Table structure for pmw_cascadedata
-- ----------------------------
DROP TABLE IF EXISTS `pmw_cascadedata`;
CREATE TABLE `pmw_cascadedata` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '级联数据id',
  `dataname` char(30) NOT NULL COMMENT '级联数据名称',
  `datavalue` char(20) NOT NULL COMMENT '级联数据值',
  `datagroup` char(20) NOT NULL COMMENT '所属级联组',
  `orderid` smallint(5) unsigned NOT NULL COMMENT '排列排序',
  `level` tinyint(1) unsigned NOT NULL COMMENT '级联数据层次',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20020 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_cascadedata
-- ----------------------------

-- ----------------------------
-- Table structure for pmw_diyfield
-- ----------------------------
DROP TABLE IF EXISTS `pmw_diyfield`;
CREATE TABLE `pmw_diyfield` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT COMMENT '自定义字段id',
  `infotype` tinyint(1) unsigned NOT NULL COMMENT '所属模型',
  `catepriv` varchar(255) NOT NULL COMMENT '所属栏目',
  `fieldname` varchar(30) NOT NULL COMMENT '字段名称',
  `fieldtitle` varchar(30) NOT NULL COMMENT '字段标题',
  `fielddesc` varchar(255) NOT NULL COMMENT '字段提示',
  `fieldtype` varchar(30) NOT NULL COMMENT '字段类型',
  `fieldlong` varchar(10) NOT NULL COMMENT '字段长度',
  `fieldsel` varchar(255) NOT NULL COMMENT '字段选项值',
  `fieldcheck` varchar(80) NOT NULL COMMENT '校验正则',
  `fieldcback` varchar(30) NOT NULL COMMENT '未通过提示',
  `orderid` smallint(6) NOT NULL COMMENT '排列排序',
  `checkinfo` enum('true','false') NOT NULL COMMENT '审核状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_diyfield
-- ----------------------------

-- ----------------------------
-- Table structure for pmw_diymenu
-- ----------------------------
DROP TABLE IF EXISTS `pmw_diymenu`;
CREATE TABLE `pmw_diymenu` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '自定义菜单id',
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '1' COMMENT '站点id',
  `parentid` smallint(5) unsigned NOT NULL COMMENT '所属菜单id',
  `classname` varchar(30) NOT NULL COMMENT '菜单项名称',
  `linkurl` varchar(255) NOT NULL COMMENT '跳转链接',
  `orderid` smallint(5) unsigned NOT NULL COMMENT '排列排序',
  `checkinfo` enum('true','false') NOT NULL COMMENT '审核状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_diymenu
-- ----------------------------

-- ----------------------------
-- Table structure for pmw_diymodel
-- ----------------------------
DROP TABLE IF EXISTS `pmw_diymodel`;
CREATE TABLE `pmw_diymodel` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT COMMENT '自定义模型id',
  `modeltitle` varchar(30) NOT NULL COMMENT '模型标题',
  `modelname` varchar(30) NOT NULL COMMENT '模型名称',
  `modeltbname` varchar(30) NOT NULL COMMENT '模型表名',
  `defaultfield` varchar(80) NOT NULL COMMENT '预设栏目',
  `orderid` smallint(6) NOT NULL COMMENT '排列排序',
  `checkinfo` enum('true','false') NOT NULL COMMENT '审核状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_diymodel
-- ----------------------------

-- ----------------------------
-- Table structure for pmw_failedlogin
-- ----------------------------
DROP TABLE IF EXISTS `pmw_failedlogin`;
CREATE TABLE `pmw_failedlogin` (
  `username` char(30) NOT NULL COMMENT '用户名',
  `ip` char(15) NOT NULL COMMENT '登录IP',
  `time` int(10) unsigned NOT NULL COMMENT '登录时间',
  `num` tinyint(1) NOT NULL COMMENT '失败次数',
  `isadmin` tinyint(1) NOT NULL COMMENT '是否是管理员',
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_failedlogin
-- ----------------------------

-- ----------------------------
-- Table structure for pmw_fragment
-- ----------------------------
DROP TABLE IF EXISTS `pmw_fragment`;
CREATE TABLE `pmw_fragment` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '碎片数据id',
  `title` varchar(30) NOT NULL COMMENT '碎片数据名称',
  `picurl` varchar(80) NOT NULL COMMENT '碎片数据缩略图',
  `linkurl` varchar(80) NOT NULL COMMENT '碎片数据连接',
  `content` mediumtext NOT NULL COMMENT '碎片数据内容',
  `posttime` int(10) unsigned NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_fragment
-- ----------------------------

-- ----------------------------
-- Table structure for pmw_getmode
-- ----------------------------
DROP TABLE IF EXISTS `pmw_getmode`;
CREATE TABLE `pmw_getmode` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '货到方式id',
  `classname` varchar(30) NOT NULL COMMENT '货到方式名称',
  `orderid` smallint(5) unsigned NOT NULL COMMENT '排列排序',
  `checkinfo` enum('true','false') NOT NULL COMMENT '审核状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_getmode
-- ----------------------------
INSERT INTO `pmw_getmode` VALUES ('1', '送货上门', '1', 'true');
INSERT INTO `pmw_getmode` VALUES ('2', '用户自取', '2', 'true');

-- ----------------------------
-- Table structure for pmw_goods
-- ----------------------------
DROP TABLE IF EXISTS `pmw_goods`;
CREATE TABLE `pmw_goods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '商品id',
  `classid` smallint(5) unsigned NOT NULL COMMENT '所属栏目',
  `parentid` smallint(5) unsigned NOT NULL COMMENT '所属栏目父id',
  `parentstr` varchar(80) NOT NULL COMMENT '所属栏目父id字符串',
  `typeid` smallint(5) unsigned NOT NULL COMMENT '商品分类',
  `typepid` smallint(5) unsigned NOT NULL COMMENT '商品分类父id',
  `typepstr` varchar(80) NOT NULL COMMENT '商品分类父id字符串',
  `brandid` smallint(5) NOT NULL COMMENT '商品品牌id',
  `brandpid` smallint(5) NOT NULL COMMENT '品牌上级id',
  `brandpstr` varchar(80) NOT NULL COMMENT '品牌上级id字符串',
  `title` varchar(80) NOT NULL COMMENT '商品名称',
  `colorval` char(10) NOT NULL COMMENT '标题颜色',
  `boldval` char(10) NOT NULL COMMENT '标题加粗',
  `flag` varchar(30) NOT NULL COMMENT '属性',
  `goodsid` varchar(30) NOT NULL COMMENT '货号',
  `payfreight` enum('0','1') NOT NULL COMMENT '运费承担',
  `weight` varchar(10) NOT NULL COMMENT '重量',
  `attrstr` text NOT NULL COMMENT '属性字符串',
  `marketprice` char(10) NOT NULL COMMENT '市场价格',
  `salesprice` char(10) NOT NULL COMMENT '销售价格',
  `housenum` smallint(5) unsigned NOT NULL COMMENT '库存数量',
  `housewarn` enum('true','false') NOT NULL COMMENT '库存警告',
  `warnnum` smallint(5) unsigned NOT NULL COMMENT '警告数量',
  `integral` char(10) NOT NULL COMMENT '积分点数',
  `source` varchar(50) NOT NULL COMMENT '文章来源',
  `author` varchar(50) NOT NULL COMMENT '作者编辑',
  `linkurl` varchar(255) NOT NULL COMMENT '跳转链接',
  `keywords` varchar(30) NOT NULL COMMENT '关键词',
  `description` varchar(255) NOT NULL COMMENT '摘要',
  `content` mediumtext NOT NULL COMMENT '详细内容',
  `picurl` varchar(100) NOT NULL COMMENT '缩略图片',
  `picarr` text NOT NULL COMMENT '组图',
  `hits` int(10) unsigned NOT NULL COMMENT '点击次数',
  `orderid` int(10) unsigned NOT NULL COMMENT '排列排序',
  `posttime` int(10) unsigned NOT NULL COMMENT '更新时间',
  `checkinfo` enum('true','false') NOT NULL COMMENT '审核状态',
  `delstate` set('true') NOT NULL COMMENT '删除状态',
  `deltime` int(10) NOT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_goods
-- ----------------------------
INSERT INTO `pmw_goods` VALUES ('1', '12', '0', '0,', '10', '1', '0,1,', '-1', '-1', '', '苹果（APPLE）iPhone 5 16G版 3G手机（黑色）WCDMA/GSM 0元购机', '', '', '', '800292', '0', '0.350', 'array(\"1\"=>\"黑色|白色\",\"2\"=>\"WCDMA|GSM\");', '5899.00', '5499.00', '100', 'true', '20', '0', '', 'admin', '', 'APPLEiPhone 5,苹果iPhone 5,苹果iPh', '【苹果iPhone 5】null 360BUY京东商城(360BUY.COM)提供苹果iPhone 5正品行货，全国价格最低，并包括APPLEiPhone 5手机网购指南，以及苹果iPhone 5图片、iPhone 5参数、iPhone 5评论、iPhone 5心得、iPhone 5技巧等信息，网购苹果iPhone 5手机上京东,放心又轻松', '<p>\r\n	北京时间2012年9月13日凌晨1点（美国时间9月12日上午10点），苹果公司在美国旧金山芳草地艺术中心举行新品发布会。发布会发布了旗下的第六款手机iPhone5。此外，苹果还在大会上更推出最新款的音乐播放器iPod Touch 5、iPod nano 7和之前曝光过的新款耳机“EarPods”。\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	<strong>iPhone 5</strong> 配备了4英寸1136×640分辨率的屏幕，全新的机身设计，800万像素摄像头，A6处理器和iOS 6。在存储空间方面，iPhone5将包含16GB、32GB、64GB三种版本，两年合约的售价分别为649美元、749美元、849美元。　iPhone价格信息：N42A-美国-199美元、N42B-美国-199美元、N42A-美国-299美元、N42B-美国-299美元、iphone 5，N42A-美国-399美元和N42B-美国-399美元。A和B分别代表黑色和白色。\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	<strong>iPhone 5</strong>与上一代产品iPhone4S相比，iPhone5是更轻薄，屏幕尺寸更大，它的厚度是7.6毫米，比前一代是薄了18%，重量为112克，比4S轻了20%，采用速度更快的A6处理器，整体外观也拉长。iPhone5屏幕的尺寸扩大到4英寸，屏幕的比例是16：9，应用软件的图标比之前前一代增加了一行，而处理器方面iPhone5采用的是苹果自家研发的A6处理器（内含两个CPU核心和三个图形核心），性能是A5处理器的两倍，得益于更先进的制程，处理器的核心面积缩小了22%，在大幅提升了性能的同时很好地控制了功耗和发热，iPhone5支持LTE网络,不支持NFC近场芯片。Siri也有升级，支持中文和拓展功能。iPhone 5的网速峰值速率可达到iPhone 4S的7倍。\r\n</p>', 'templates/default/images/imgdata/iphone5_01.jpg', 'a:5:{i:0;s:48:\"templates/default/images/imgdata/iphone5_01.jpg,\";i:1;s:48:\"templates/default/images/imgdata/iphone5_02.jpg,\";i:2;s:48:\"templates/default/images/imgdata/iphone5_03.jpg,\";i:3;s:48:\"templates/default/images/imgdata/iphone5_04.jpg,\";i:4;s:48:\"templates/default/images/imgdata/iphone5_05.jpg,\";}', '327', '1', '1357786470', 'true', '', '0');

-- ----------------------------
-- Table structure for pmw_goodsattr
-- ----------------------------
DROP TABLE IF EXISTS `pmw_goodsattr`;
CREATE TABLE `pmw_goodsattr` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '商品属性id',
  `goodsid` smallint(5) unsigned NOT NULL COMMENT '所属分类',
  `attrname` varchar(30) NOT NULL COMMENT '属性名称',
  `orderid` mediumint(8) unsigned NOT NULL COMMENT '排列排序',
  `checkinfo` enum('true','false') NOT NULL COMMENT '审核状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_goodsattr
-- ----------------------------
INSERT INTO `pmw_goodsattr` VALUES ('1', '10', '颜色', '1', 'true');
INSERT INTO `pmw_goodsattr` VALUES ('2', '10', '型号', '2', 'true');

-- ----------------------------
-- Table structure for pmw_goodsbrand
-- ----------------------------
DROP TABLE IF EXISTS `pmw_goodsbrand`;
CREATE TABLE `pmw_goodsbrand` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '商品品牌id',
  `parentid` mediumint(8) unsigned NOT NULL COMMENT '品牌上级id',
  `parentstr` varchar(50) NOT NULL COMMENT '品牌上级id字符串',
  `classname` varchar(30) NOT NULL COMMENT '品牌名称',
  `picurl` varchar(100) NOT NULL COMMENT '缩略图片',
  `linkurl` varchar(255) NOT NULL COMMENT '跳转链接',
  `orderid` mediumint(10) unsigned NOT NULL COMMENT '排列排序',
  `checkinfo` enum('true','false') NOT NULL COMMENT '审核状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_goodsbrand
-- ----------------------------

-- ----------------------------
-- Table structure for pmw_goodsflag
-- ----------------------------
DROP TABLE IF EXISTS `pmw_goodsflag`;
CREATE TABLE `pmw_goodsflag` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '商品标记id',
  `flag` varchar(30) NOT NULL COMMENT '标记名称',
  `flagname` varchar(30) NOT NULL COMMENT '标记标识',
  `orderid` smallint(5) unsigned NOT NULL COMMENT '排列排序',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_goodsflag
-- ----------------------------
INSERT INTO `pmw_goodsflag` VALUES ('1', 'c', '推荐', '1');
INSERT INTO `pmw_goodsflag` VALUES ('2', 'f', '幻灯', '2');
INSERT INTO `pmw_goodsflag` VALUES ('3', 'a', '特推', '3');
INSERT INTO `pmw_goodsflag` VALUES ('4', 't', '特价', '4');
INSERT INTO `pmw_goodsflag` VALUES ('5', 'h', '热卖', '5');

-- ----------------------------
-- Table structure for pmw_goodsorder
-- ----------------------------
DROP TABLE IF EXISTS `pmw_goodsorder`;
CREATE TABLE `pmw_goodsorder` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '商品订单id',
  `username` varchar(30) NOT NULL COMMENT '会员用户名',
  `attrstr` text NOT NULL COMMENT '商品列表',
  `truename` varchar(30) NOT NULL COMMENT '收货人姓名',
  `telephone` varchar(30) NOT NULL COMMENT '电话',
  `idcard` varchar(30) NOT NULL COMMENT '证件号码',
  `zipcode` varchar(30) NOT NULL COMMENT '邮编',
  `postarea_prov` varchar(10) NOT NULL COMMENT '配送地区_省',
  `postarea_city` varchar(10) NOT NULL COMMENT '配送地区_市',
  `postarea_country` varchar(10) NOT NULL COMMENT '配送地区_县',
  `address` varchar(80) NOT NULL COMMENT '地址',
  `postmode` smallint(5) NOT NULL COMMENT '配送方式',
  `paymode` smallint(5) NOT NULL COMMENT '支付方式',
  `getmode` smallint(5) NOT NULL COMMENT '货到方式',
  `ordernum` varchar(30) NOT NULL COMMENT '订单号',
  `postid` varchar(30) NOT NULL COMMENT '运单号',
  `weight` varchar(10) NOT NULL COMMENT '物品重量',
  `cost` varchar(10) NOT NULL COMMENT '商品运费',
  `amount` varchar(10) NOT NULL COMMENT '订单金额',
  `integral` smallint(5) unsigned NOT NULL COMMENT '积分点数',
  `buyremark` text NOT NULL COMMENT '购物备注',
  `sendremark` text NOT NULL COMMENT '发货方备注',
  `posttime` int(10) unsigned NOT NULL COMMENT '订单时间',
  `orderid` mediumint(10) unsigned NOT NULL COMMENT '排列排序',
  `checkinfo` varchar(255) NOT NULL COMMENT '审核状态',
  `core` set('true') NOT NULL COMMENT '是否加星',
  `delstate` set('true') NOT NULL COMMENT '删除状态',
  `deltime` int(10) unsigned NOT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_goodsorder
-- ----------------------------

-- ----------------------------
-- Table structure for pmw_goodstype
-- ----------------------------
DROP TABLE IF EXISTS `pmw_goodstype`;
CREATE TABLE `pmw_goodstype` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '商品类型id',
  `parentid` mediumint(8) unsigned NOT NULL COMMENT '类型上级id',
  `parentstr` varchar(50) NOT NULL COMMENT '类型上级id字符串',
  `classname` varchar(30) NOT NULL COMMENT '类别名称',
  `picurl` varchar(255) DEFAULT NULL COMMENT '缩略图片',
  `linkurl` varchar(255) DEFAULT NULL COMMENT '跳转链接',
  `orderid` mediumint(8) unsigned NOT NULL COMMENT '排列顺序',
  `checkinfo` enum('true','false') NOT NULL COMMENT '隐藏类别',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_goodstype
-- ----------------------------
INSERT INTO `pmw_goodstype` VALUES ('1', '0', '0,', '手机通讯', '', '', '1', 'true');
INSERT INTO `pmw_goodstype` VALUES ('2', '0', '0,', '电脑笔记本', '', '', '2', 'true');
INSERT INTO `pmw_goodstype` VALUES ('3', '0', '0,', '相机 摄相机', '', '', '3', 'true');
INSERT INTO `pmw_goodstype` VALUES ('4', '0', '0,', '随身视听', '', '', '4', 'true');
INSERT INTO `pmw_goodstype` VALUES ('5', '0', '0,', '电脑外设', '', '', '5', 'true');
INSERT INTO `pmw_goodstype` VALUES ('6', '0', '0,', 'DIY装机', '', '', '6', 'true');
INSERT INTO `pmw_goodstype` VALUES ('7', '0', '0,', '办公用品', '', '', '7', 'true');
INSERT INTO `pmw_goodstype` VALUES ('8', '1', '0,1,', '通讯产品', '', '', '8', 'true');
INSERT INTO `pmw_goodstype` VALUES ('9', '1', '0,1,', '手机配件', '', '', '9', 'true');
INSERT INTO `pmw_goodstype` VALUES ('10', '1', '0,1,', '手机', '', '', '10', 'true');
INSERT INTO `pmw_goodstype` VALUES ('11', '2', '0,2,', '电脑整机', '', '', '11', 'true');
INSERT INTO `pmw_goodstype` VALUES ('12', '2', '0,2,', '笔记本', '', '', '12', 'true');
INSERT INTO `pmw_goodstype` VALUES ('13', '2', '0,2,', '电脑配件', '', '', '13', 'true');
INSERT INTO `pmw_goodstype` VALUES ('14', '3', '0,3,', '相机配件', '', '', '14', 'true');
INSERT INTO `pmw_goodstype` VALUES ('15', '3', '0,3,', '数码摄相机', '', '', '15', 'true');
INSERT INTO `pmw_goodstype` VALUES ('16', '3', '0,3,', '数码相机', '', '', '16', 'true');
INSERT INTO `pmw_goodstype` VALUES ('17', '4', '0,4,', '电子阅读', '', '', '17', 'true');
INSERT INTO `pmw_goodstype` VALUES ('18', '4', '0,4,', 'MID', '', '', '18', 'true');
INSERT INTO `pmw_goodstype` VALUES ('19', '4', '0,4,', 'MP3|MP4', '', '', '19', 'true');
INSERT INTO `pmw_goodstype` VALUES ('20', '5', '0,5,', '移动硬盘', '', '', '20', 'true');
INSERT INTO `pmw_goodstype` VALUES ('21', '5', '0,5,', '键盘', '', '', '21', 'true');
INSERT INTO `pmw_goodstype` VALUES ('22', '5', '0,5,', '鼠标', '', '', '22', 'true');
INSERT INTO `pmw_goodstype` VALUES ('23', '6', '0,6,', '扩展配件', '', '', '23', 'true');
INSERT INTO `pmw_goodstype` VALUES ('24', '6', '0,6,', '装机配件', '', '', '24', 'true');
INSERT INTO `pmw_goodstype` VALUES ('25', '6', '0,6,', '显示器', '', '', '25', 'true');
INSERT INTO `pmw_goodstype` VALUES ('26', '7', '0,7,', '投影显示', '', '', '26', 'true');
INSERT INTO `pmw_goodstype` VALUES ('27', '7', '0,7,', '办公打印', '', '', '27', 'true');

-- ----------------------------
-- Table structure for pmw_info
-- ----------------------------
DROP TABLE IF EXISTS `pmw_info`;
CREATE TABLE `pmw_info` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '单页id',
  `classid` smallint(5) unsigned NOT NULL COMMENT '所属栏目id',
  `mainid` smallint(5) NOT NULL COMMENT '二级类别id',
  `picurl` varchar(100) NOT NULL COMMENT '缩略图片',
  `content` mediumtext NOT NULL COMMENT '内容',
  `posttime` int(10) unsigned NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_info
-- ----------------------------
INSERT INTO `pmw_info` VALUES ('1', '1', '-1', '', '测试信息来自互联网，若涉及侵权，请联系我们删除！', '1326769494');
INSERT INTO `pmw_info` VALUES ('2', '2', '-1', '', '<p style=\"text-indent:2em;\">\r\n	百度，全球最大的中文搜索引擎、最大的中文网站。2000年1月创立于北京中关村。\r\n</p>\r\n<br />\r\n<p style=\"text-indent:2em;\">\r\n	1999年底，身在美国硅谷的李彦宏看到了中国互联网及中文搜索引擎服务的巨大发展潜力，抱着技术改变世界的梦想，他毅然辞掉硅谷的高薪工作，携搜索引擎专利技术，于2000年1月1日在中关村创建了百度公司。从最初的不足10人发展至今，员工人数超过12000人。如今的百度，已成为中国最受欢迎、影响力最大的中文网站。\r\n</p>\r\n<br />\r\n<p style=\"text-indent:2em;\">\r\n	百度拥有数千名研发工程师，这是中国乃至全球最为优秀的技术团队，这支队伍掌握着世界上最为先进的搜索引擎技术，使百度成为中国掌握世界尖端科学核心技术的中国高科技企业，也使中国成为美国、俄罗斯、和韩国之外，全球仅有的4个拥有搜索引擎核心技术的国家之一。\r\n</p>\r\n<br />\r\n<p style=\"text-indent:2em;\">\r\n	从创立之初，百度便将“让人们最便捷地获取信息，找到所求”作为自己的使命，成立以来，公司秉承“以用户为导向”的理念，不断坚持技术创新，致力于为用户提供“简单，可依赖”的互联网搜索产品及服务，其中包括：以网络搜索为主的功能性搜索，以贴吧为主的社区搜索，针对各区域、行业所需的垂直搜索，Mp3搜索，以及门户频道、IM等，全面覆盖了中文网络世界所有的搜索需求，根据第三方权威数据，百度在中国的搜索份额接近80%。\r\n</p>\r\n<br />\r\n<p style=\"text-indent:2em;\">\r\n	在面对用户的搜索产品不断丰富的同时，百度还创新性地推出了基于搜索的营销推广服务，并成为最受企业青睐的互联网营销推广平台。目前，中国已有数十万家企业使用了百度的搜索推广服务，不断提升着企业自身的品牌及运营效率。通过持续的商业模式创新，百度正进一步带动整个互联网行业和中小企业的经济增长，推动社会经济的发展和转型。\r\n</p>\r\n<br />\r\n<p style=\"text-indent:2em;\">\r\n	为推动中国数百万中小网站的发展，百度借助超大流量的平台优势，联合所有优质的各类网站，建立了世界上最大的网络联盟，使各类企业的搜索推广、品牌营销的价值、覆盖面均大面积提升。与此同时，各网站也在联盟大家庭的互助下，获得最大的生存与发展机会。\r\n</p>\r\n<hr style=\"page-break-after:always;\" class=\"ke-pagebreak\" />\r\n<p style=\"text-indent:2em;\">\r\n	作为国内的一家知名企业，百度也一直秉承“弥合信息鸿沟，共享知识社会”的责任理念，坚持履行企业公民的社会责任。成立来，百度利用自身优势积极投身公益事业，先后投入巨大资源，为盲人、少儿、老年人群体打造专门的搜索产品，解决了特殊群体上网难问题,极大地弥补了社会信息鸿沟问题。此外，在加速推动中国信息化进程、净化网络环境、搜索引擎教育及提升大学生就业率等方面，百度也一直走在行业领先的地位。2011年初，百度还特别成立了百度基金会，围绕知识教育、环境保护、灾难救助等领域，更加系统规范地管理和践行公益事业。\r\n</p>\r\n<br />\r\n<p style=\"text-indent:2em;\">\r\n	2005年，百度在美国纳斯达克上市，一举打破首日涨幅最高等多项纪录，并成为首家进入纳斯达克成分股的中国公司。通过数年来的市场表现，百度优异的业绩与值得依赖的回报，使之成为中国企业价值的代表，傲然屹立于全球资本市场。\r\n</p>\r\n<br />\r\n<p style=\"text-indent:2em;\">\r\n	2009年，百度更是推出全新的框计算技术概念，并基于此理念推出百度开放平台，帮助更多优秀的第三方开发者利用互联网平台自主创新、自主创业，在大幅提升网民互联网使用体验的同时，带动起围绕用户需求进行研发的产业创新热潮，对中国互联网产业的升级和发展产生巨大的拉动效应。\r\n</p>\r\n<br />\r\n<p style=\"text-indent:2em;\">\r\n	今天，百度已经成为中国最具价值的品牌之一，英国《金融时报》将百度列为“中国十大世界级品牌”，成为这个榜单中最年轻的一家公司，也是唯一一家互联网公司。而“亚洲最受尊敬企业”、“全球最具创新力企业”、“中国互联网力量之星”等一系列荣誉称号的获得，也无一不向外界展示着百度成立数年来的成就。\r\n</p>\r\n<br />\r\n<p style=\"text-indent:2em;\">\r\n	多年来，百度董事长兼CEO李彦宏，率领百度人所形成的“简单可依赖”的核心文化，深深地植根于百度。这是一个充满朝气、求实坦诚的公司，以搜索改变生活，推动人类的文明与进步，促进中国经济的发展为己任，正朝着更为远大的目标而迈进。\r\n</p>', '1326769513');
INSERT INTO `pmw_info` VALUES ('3', '3', '-1', 'templates/default/images/aboutus_img.png', '百度，全球最大的中文搜索引擎最大的中文网站。二零零零年一月创立于北京中关村。从最初的不足十人人发展至今，员工人数超过一万两千人。如今的百度，已成为中国最受欢迎、影响力最大的中文网站。百度拥有数千名研发工程师，这是中国乃至全球最为优秀的技术团队，这支队伍掌握着世界上最为先进的搜索引擎技术，使百度成为中国掌握世界尖端科学核心技术的中国高科技企业，也使中国成为美国、俄罗斯、和韩国之外，全球仅有的4个拥有搜索引擎核心技术的国家之一。', '1326769523');
INSERT INTO `pmw_info` VALUES ('4', '9', '-1', '', '<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"ke-zeroborder\">\r\n	<tbody>\r\n		<tr>\r\n			<td width=\"30%\" valign=\"top\">\r\n				<strong> <span style=\"color:#333333;\">百度大厦：</span></strong><br />\r\n地　址：北京市海淀区上地十街10号<br />\r\n邮　编：100085<br />\r\n			</td>\r\n			<td valign=\"top\">\r\n				<br />\r\nAddress:    Baidu Campus, No.10, Shangdi 10th Street Haidian District, Beijing, China<br />\r\nPost Code:&nbsp;100085\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n<br />\r\n<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"ke-zeroborder\">\r\n	<tbody>\r\n		<tr>\r\n			<td width=\"30%\" valign=\"top\">\r\n				总　机：(+86 10) 5992 8888<br />\r\n传　真：(+86 10) 5992 0000<br />\r\n			</td>\r\n			<td valign=\"top\">\r\n				Tel:&nbsp;(+86 10) 5992 8888<br />\r\nFAX:&nbsp;(+86 10) 5992 0000\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n<br />\r\n<img src=\"templates/default/images/imgdata/map.png\" />', '1326769535');
INSERT INTO `pmw_info` VALUES ('5', '10', '-1', '', '地址:北京市海淀区上地十街10号<br />\r\n总机:(+86 10) 5992 8888<br />\r\n传真:(+86 10) 5992 0000', '1326769548');

-- ----------------------------
-- Table structure for pmw_infoclass
-- ----------------------------
DROP TABLE IF EXISTS `pmw_infoclass`;
CREATE TABLE `pmw_infoclass` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '栏目id',
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '1' COMMENT '站点id',
  `parentid` smallint(5) unsigned NOT NULL COMMENT '栏目上级id',
  `parentstr` varchar(50) NOT NULL COMMENT '栏目上级id字符串',
  `infotype` tinyint(1) unsigned NOT NULL COMMENT '栏目类型',
  `classname` varchar(30) NOT NULL COMMENT '栏目名称',
  `linkurl` varchar(255) NOT NULL COMMENT '跳转链接',
  `picurl` varchar(100) NOT NULL COMMENT '缩略图片',
  `picwidth` varchar(5) NOT NULL COMMENT '缩略图宽度',
  `picheight` varchar(5) NOT NULL COMMENT '缩略图高度',
  `seotitle` varchar(80) NOT NULL COMMENT 'SEO标题',
  `keywords` varchar(50) NOT NULL COMMENT '关键词',
  `description` varchar(255) NOT NULL COMMENT '描述',
  `orderid` smallint(5) unsigned NOT NULL COMMENT '排列排序',
  `checkinfo` enum('true','false') NOT NULL COMMENT '审核状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_infoclass
-- ----------------------------
INSERT INTO `pmw_infoclass` VALUES ('1', '1', '0', '0,', '0', '网站公告', '', '', '', '', '', '', '', '1', 'false');
INSERT INTO `pmw_infoclass` VALUES ('2', '1', '0', '0,', '0', '关于我们', 'about.php', '', '', '', '', '', '', '2', 'true');
INSERT INTO `pmw_infoclass` VALUES ('3', '1', '2', '0,2,', '0', '关于我们摘要', '', '', '', '', '', '', '', '3', 'true');
INSERT INTO `pmw_infoclass` VALUES ('4', '1', '0', '0,', '1', '新闻动态', 'news.php', '', '', '', '', '', '', '4', 'true');
INSERT INTO `pmw_infoclass` VALUES ('5', '1', '0', '0,', '2', '产品展示', 'product.php', '', '', '', '', '', '', '5', 'true');
INSERT INTO `pmw_infoclass` VALUES ('6', '1', '5', '0,5,', '2', '笔记本电脑', 'product.php?cid=6', '', '', '', '', '', '', '6', 'true');
INSERT INTO `pmw_infoclass` VALUES ('7', '1', '5', '0,5,', '2', '智能手机', 'product.php?cid=7', '', '', '', '', '', '', '7', 'true');
INSERT INTO `pmw_infoclass` VALUES ('8', '1', '0', '0,', '2', '成功案例', 'case.php', '', '', '', '', '', '', '8', 'true');
INSERT INTO `pmw_infoclass` VALUES ('9', '1', '0', '0,', '0', '联系我们', 'contact.php', '', '', '', '', '', '', '9', 'true');
INSERT INTO `pmw_infoclass` VALUES ('10', '1', '9', '0,9,', '0', '联系我们摘要', '', '', '', '', '', '', '', '10', 'true');
INSERT INTO `pmw_infoclass` VALUES ('11', '1', '0', '0,', '3', '软件下载', 'soft.php', '', '', '', '', '', '', '11', 'true');
INSERT INTO `pmw_infoclass` VALUES ('12', '1', '0', '0,', '4', '商品展示', 'goods.php', '', '', '', '', '', '', '12', 'true');
INSERT INTO `pmw_infoclass` VALUES ('13', '1', '0', '0,', '2', '幻灯Banner', '', '', '', '', '', '', '', '13', 'false');
INSERT INTO `pmw_infoclass` VALUES ('14', '1', '0', '0,', '1', '解决方案', '', '', '', '', '', '', '', '14', 'true');
INSERT INTO `pmw_infoclass` VALUES ('16', '1', '0', '0,', '1', '关于我们', '', '', '', '', '', '', '', '15', 'true');
INSERT INTO `pmw_infoclass` VALUES ('17', '1', '0', '0,', '1', '案例展示', '', '', '', '', '', '', '', '16', 'true');
INSERT INTO `pmw_infoclass` VALUES ('18', '1', '0', '0,', '1', '关于我们1', '', '', '', '', '', '', '', '17', 'true');
INSERT INTO `pmw_infoclass` VALUES ('19', '1', '0', '0,', '1', '解决方案1', '', '', '', '', '', '', '', '18', 'true');
INSERT INTO `pmw_infoclass` VALUES ('20', '1', '0', '0,', '1', '新闻资讯', '', '', '', '', '', '', '', '19', 'true');
INSERT INTO `pmw_infoclass` VALUES ('21', '1', '0', '0,', '1', '新闻资讯图片排版', '', '', '', '', '', '', '', '20', 'true');
INSERT INTO `pmw_infoclass` VALUES ('22', '1', '0', '0,', '1', '加入奥昇', '', '', '', '', '', '', '', '21', 'true');
INSERT INTO `pmw_infoclass` VALUES ('23', '1', '0', '0,', '1', '选择我们', '', '', '', '', '', '', '', '22', 'true');
INSERT INTO `pmw_infoclass` VALUES ('24', '1', '0', '0,', '1', '荣誉资质', '', '', '', '', '', '', '', '23', 'true');
INSERT INTO `pmw_infoclass` VALUES ('26', '1', '0', '0,', '1', '详情页', '', '', '', '', '', '', '', '24', 'true');

-- ----------------------------
-- Table structure for pmw_infoflag
-- ----------------------------
DROP TABLE IF EXISTS `pmw_infoflag`;
CREATE TABLE `pmw_infoflag` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '信息标记id',
  `flag` varchar(30) NOT NULL COMMENT '标记名称',
  `flagname` varchar(30) NOT NULL COMMENT '标记标识',
  `orderid` smallint(5) unsigned NOT NULL COMMENT '排列排序',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_infoflag
-- ----------------------------
INSERT INTO `pmw_infoflag` VALUES ('1', 'h', '头条', '1');
INSERT INTO `pmw_infoflag` VALUES ('2', 'c', '推荐', '2');
INSERT INTO `pmw_infoflag` VALUES ('3', 'f', '幻灯', '3');
INSERT INTO `pmw_infoflag` VALUES ('4', 'a', '特荐', '4');
INSERT INTO `pmw_infoflag` VALUES ('5', 's', '滚动', '5');
INSERT INTO `pmw_infoflag` VALUES ('6', 'j', '跳转', '6');

-- ----------------------------
-- Table structure for pmw_infoimg
-- ----------------------------
DROP TABLE IF EXISTS `pmw_infoimg`;
CREATE TABLE `pmw_infoimg` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '图片信息id',
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '1' COMMENT '站点id',
  `classid` smallint(5) unsigned NOT NULL COMMENT '所属栏目id',
  `parentid` smallint(5) unsigned NOT NULL COMMENT '所属栏目上级id',
  `parentstr` varchar(80) NOT NULL COMMENT '所属栏目上级id字符串',
  `mainid` smallint(5) NOT NULL COMMENT '二级类别id',
  `mainpid` smallint(5) NOT NULL COMMENT '二级类别父id',
  `mainpstr` varchar(80) NOT NULL COMMENT '二级累呗父id字符串',
  `title` varchar(80) NOT NULL COMMENT '标题',
  `colorval` char(10) NOT NULL COMMENT '字体颜色',
  `boldval` char(10) NOT NULL COMMENT '字体加粗',
  `flag` varchar(30) NOT NULL COMMENT '属性',
  `source` varchar(50) NOT NULL COMMENT '文章来源',
  `author` varchar(50) NOT NULL COMMENT '作者编辑',
  `linkurl` varchar(255) NOT NULL COMMENT '跳转链接',
  `keywords` varchar(50) NOT NULL COMMENT '关键词',
  `description` varchar(255) NOT NULL COMMENT '摘要',
  `content` mediumtext NOT NULL COMMENT '详细内容',
  `picurl` varchar(100) NOT NULL COMMENT '缩略图片',
  `picarr` text NOT NULL COMMENT '组图',
  `hits` mediumint(8) unsigned NOT NULL COMMENT '点击次数',
  `orderid` int(10) unsigned NOT NULL COMMENT '排列排序',
  `posttime` int(10) NOT NULL COMMENT '更新时间',
  `checkinfo` enum('true','false') NOT NULL COMMENT '审核状态',
  `delstate` set('true') NOT NULL COMMENT '删除状态',
  `deltime` int(10) unsigned NOT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_infoimg
-- ----------------------------
INSERT INTO `pmw_infoimg` VALUES ('1', '1', '7', '5', '0,5,', '-1', '-1', '', '苹果iPhone 4S 白色版', '', '', '', '', 'admin', '', '白色版', '', '', 'templates/default/images/imgdata/iphone4s_w.jpg', '', '57', '1', '1326770071', 'true', '', '0');
INSERT INTO `pmw_infoimg` VALUES ('2', '1', '7', '5', '0,5,', '-1', '-1', '', '苹果iphone 4s', '', '', '', '', 'admin', '', '黑色版', '', '', 'templates/default/images/imgdata/iphone4s.jpg', '', '118', '2', '1326770089', 'true', '', '0');
INSERT INTO `pmw_infoimg` VALUES ('3', '1', '6', '5', '0,5,', '-1', '-1', '', '苹果iPad 2 16GB/WIFI版', '', '', '', '', 'admin', '', '16GB/WIFI版', '', '', 'templates/default/images/imgdata/ipad2.jpg', '', '85', '3', '1326770110', 'true', '', '0');
INSERT INTO `pmw_infoimg` VALUES ('4', '1', '6', '5', '0,5,', '-1', '-1', '', '苹果iPod touch 4', '', '', '', '', 'admin', '', '白色', '', '', 'templates/default/images/imgdata/iPod.jpg', '', '159', '4', '1326770133', 'true', '', '0');
INSERT INTO `pmw_infoimg` VALUES ('5', '1', '6', '5', '0,5,', '-1', '-1', '', '苹果MacBook Pro', '', '', '', '', 'admin', '', 'MC725CH/A', '', '', 'templates/default/images/imgdata/macbook.jpg', '', '86', '5', '1326770162', 'true', '', '0');
INSERT INTO `pmw_infoimg` VALUES ('6', '1', '6', '5', '0,5,', '-1', '-1', '', '苹果iMac', '', '', '', '', 'admin', '', 'MC814CH/A', '', '', 'templates/default/images/imgdata/iMac.jpg', '', '160', '6', '1326770178', 'true', '', '0');
INSERT INTO `pmw_infoimg` VALUES ('7', '1', '8', '0', '0,', '-1', '-1', '', '361度——腾讯大运会梦想传递', '', '', '', '', 'admin', '', '', '火炬传递将是拉开2011年深圳世界大运会全民眼帘的幕布，政府首次以官方身份举办的网络虚拟火炬传递活动。将火炬虚拟传递举办成为深圳世界大运会的一次互联网传播盛会，361度借此机遇搭载腾讯大平台，迅速使其品牌在深圳世界大运会全面曝光，从而达到361度传播品牌，提升品牌形象的目的。', '', 'templates/default/images/imgdata/361du.jpg', '', '107', '7', '1326770200', 'true', '', '0');
INSERT INTO `pmw_infoimg` VALUES ('8', '1', '8', '0', '0,', '-1', '-1', '', '中华牙膏——我的微笑闪亮未来', '', '', '', '', 'admin', '', '', '这次活动将微博与微电影进行多种结合，充分调动用户与向微电影互动，通过看电影收集微笑金币，微博好友“出演”微电影，写下“我的未来”等，将中华牙膏“我的微笑 闪亮未来”的精神精准传递给受众。', '', 'templates/default/images/imgdata/zhonghua.jpg', '', '195', '8', '1326770219', 'true', '', '0');
INSERT INTO `pmw_infoimg` VALUES ('9', '1', '8', '0', '0,', '-1', '-1', '', '中国电信天翼——三星I559 I mini I life', '', '', '', '', 'admin', '', '', '作为电信天翼的定制手机，三星Galaxy 系列手机 Galaxy Mini上市之际，电信天翼希望借助腾讯的媒体平台和互动形式，直击年轻消费群体，实现产品对目标受众的充分曝光和产品卖点的有效深化 。', '', 'templates/default/images/imgdata/I559.jpg', '', '143', '9', '1326770246', 'true', '', '0');
INSERT INTO `pmw_infoimg` VALUES ('10', '1', '8', '0', '0,', '-1', '-1', '', 'Moto——MT620两面派变身秀', '', '', '', '', 'admin', '', '', 'Tahiti是MOTO推出的第一款将“触摸屏幕”和“QWERTY Bar”相结合的智能手机 ，为快速引发青年白领关注，MOTO借腾讯大平台，打造了一场“两面派变身秀”。', '', 'templates/default/images/imgdata/moto.jpg', '', '116', '10', '1326770273', 'true', '', '0');
INSERT INTO `pmw_infoimg` VALUES ('11', '1', '13', '0', '0,', '-1', '-1', '', '三一重工86米世界最长臂架泵车下线', '', '', '', '', 'admin', '', '', '', '', 'templates/default/images/imgdata/slideimg_1.jpg', '', '64', '11', '1326770289', 'true', '', '0');
INSERT INTO `pmw_infoimg` VALUES ('12', '1', '13', '0', '0,', '-1', '-1', '', '三一产品获八项第一', '', '', '', '', 'admin', '', '', '', '', 'templates/default/images/imgdata/slideimg_2.jpg', '', '131', '12', '1326770306', 'true', '', '0');
INSERT INTO `pmw_infoimg` VALUES ('13', '1', '13', '0', '0,', '-1', '-1', '', '三一获评《财富》十大“最受赞赏中国公司”', '', '', '', '', 'admin', '', '', '', '', 'templates/default/images/imgdata/slideimg_3.jpg', '', '80', '13', '1326770336', 'true', '', '0');
INSERT INTO `pmw_infoimg` VALUES ('14', '1', '13', '0', '0,', '-1', '-1', '', '唐家璇：三一重工为国家争了光', '', '', '', '', 'admin', '', '', '', '', 'templates/default/images/imgdata/slideimg_4.jpg', '', '87', '14', '1326770383', 'true', '', '0');
INSERT INTO `pmw_infoimg` VALUES ('15', '1', '13', '0', '0,', '-1', '-1', '', '亚洲首台千吨级全地面起重机SAC12000 2.0兆风电吊装圆满成功', '', '', '', '', 'admin', '', '', '', '', 'templates/default/images/imgdata/slideimg_5.jpg', '', '53', '15', '1326770404', 'true', '', '0');
INSERT INTO `pmw_infoimg` VALUES ('16', '1', '13', '0', '0,', '-1', '-1', '', '案例展示', '', '', 'h', '', 'admin', '', '', '', '', 'uploads/image/20170703/1499091799.jpg', '', '83', '16', '1499087210', 'true', '', '0');
INSERT INTO `pmw_infoimg` VALUES ('17', '1', '13', '0', '0,', '-1', '-1', '', '关于我们图片', '', '', 's', '', 'admin', '', '', '', '', 'uploads/image/20170703/1499094291.jpg', '', '121', '17', '1499092810', 'true', '', '0');
INSERT INTO `pmw_infoimg` VALUES ('18', '1', '13', '0', '0,', '-1', '-1', '', '解决方案', '', '', 'a', '', 'admin', '', '', '', '', 'uploads/image/20170704/1499103002.jpg', '', '152', '18', '1499097762', 'true', '', '0');

-- ----------------------------
-- Table structure for pmw_infolist
-- ----------------------------
DROP TABLE IF EXISTS `pmw_infolist`;
CREATE TABLE `pmw_infolist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '列表信息id',
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '1' COMMENT '站点id',
  `classid` smallint(5) unsigned NOT NULL COMMENT '所属栏目id',
  `parentid` smallint(5) unsigned NOT NULL COMMENT '所属栏目上级id',
  `parentstr` varchar(80) NOT NULL COMMENT '所属栏目上级id字符串',
  `mainid` smallint(5) NOT NULL COMMENT '二级类别id',
  `mainpid` smallint(5) NOT NULL COMMENT '二级类别上级id',
  `mainpstr` varchar(80) NOT NULL COMMENT '二级类别上级id字符串',
  `title` varchar(80) NOT NULL COMMENT '标题',
  `colorval` char(10) NOT NULL COMMENT '字体颜色',
  `boldval` char(10) NOT NULL COMMENT '字体加粗',
  `flag` varchar(30) NOT NULL COMMENT '属性',
  `source` varchar(50) NOT NULL COMMENT '文章来源',
  `author` varchar(50) NOT NULL COMMENT '作者编辑',
  `linkurl` varchar(255) NOT NULL COMMENT '跳转链接',
  `keywords` varchar(50) NOT NULL COMMENT '关键词',
  `description` varchar(255) NOT NULL COMMENT '摘要',
  `content` mediumtext NOT NULL COMMENT '详细内容',
  `picurl` varchar(100) NOT NULL COMMENT '缩略图片',
  `picarr` text NOT NULL COMMENT '组图',
  `hits` mediumint(8) unsigned NOT NULL COMMENT '点击次数',
  `orderid` int(10) unsigned NOT NULL COMMENT '排列排序',
  `posttime` int(10) NOT NULL COMMENT '更新时间',
  `checkinfo` enum('true','false') NOT NULL COMMENT '审核状态',
  `delstate` set('true') NOT NULL COMMENT '删除状态',
  `deltime` int(10) unsigned NOT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=81 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_infolist
-- ----------------------------
INSERT INTO `pmw_infolist` VALUES ('1', '1', '4', '0', '0,', '-1', '-1', '', '百度数据报告进入全国两会引起各界代表热议广受好评', '', '', '', '', 'admin', '', '', '', '<p>\r\n	“统计显示，2010年3月以来，网民最关注的社会民生热点是住房问题，搜索占比高达34.84%，其次是金融类内容、社会保障、物价/通胀等。总体来看，与人民生活息息相关的吃住行、医疗、社保等民生问题占到了关注热点的绝大多数……”\r\n</p>\r\n<p>\r\n	百度作为全球最大的中文搜索引擎，覆盖95%以上中国网民，每天响应数十亿次搜索请求。这份两会专题报告，即是百度科学统计搜索关键词数据库，真实客观地反映一年来中国网民的关注和兴趣点，获得众多两会代表的广泛热议。\r\n</p>\r\n<p>\r\n	“可以看出，百度数据研究中心秉承专业严谨、科学客观的研究态度，用明确的数据分析，表达了网民和老百姓的心声与期待。”全国人大代表、河南省工商联副主席王刚向记者表示。他指出，根据百度数据报告可以看出，住房和消费是老百姓最关心的问题，特别是最近相继出台的“限购令”，更是让老百姓处于不知所从的状态。在王刚看来，限购只是一种手段，不应该是成为一种长久执行的政策。中国经济要保持目前的增长速度，关键是调整结构，扩展经济增长空间，让消费成为拉动经济的最重要力量。政府要加大保障房建设力度，解决了低收入家庭住房问题后，房地产限购应逐步放开，让市场真正符合市场经济发展。但未来中国消费潜能要得到真正释放，必须解决社会保障体系，人们才敢放手去消费。百度的数据报告，有理有据地传达出了普通民众的心声。<br />\r\n2011年3月5日、3月3日，第十一届全国人民代表大会第四次会议和政协第十一届全国委员会第四次会议在京正式拉开帷幕。今年的两会现场，代表们案头所翻阅的资料中，多了一份来自中国4.57亿网民的集体心声。\r\n</p>\r\n<p>\r\n	这便是来自百度数据研究中心的《2011两会专题研究数据报告》。\r\n</p>\r\n<p>\r\n	<br />\r\n全国人大代表、体操名将杨威告诉记者，“会议现场我看到了百度《2011两会专题研究数据报告》，花了几分钟读完之后，感觉报告数据真实展现了中国老百姓的关注热点，对‘两会’代表更深入了解人民呼声、参政议政有很重要参考价值，非常值得一读。”\r\n</p>\r\n<p>\r\n	“中国正处于经济转型期，如何更好地洞察民众消费需求，捕捉技术发展趋势，都是迫在眉睫的命题。百度两会数据报告，真实反映了中国四亿多网民的关注和需求所在，堪称一份\'来自互联网亿万网民的民生提案\'，对于国家经济发展意义重大！”全国人大代表周厚健表示，网络问政对经济进一步健康发展尤为重要，已渐渐成为一种趋势。\r\n</p>\r\n<p>\r\n	全国政协委员张征宇则指出“去年在网上发布《中华人民共和国车船税法(草案)》后，2万多网友近10万条意见。决策前充分论证、听取多方意见，能更好地平衡各方利益，有利于科学决策。百度《2011两会专题研究数据报告》这种形式，正是我们所需要的理性问政数据支撑。希望百度能在此基础上，不断改进数据统计方式，充分发挥网络技术优势，逐步建立和发挥网络智库的作用，为各方的决策提供更多更好的参考建议。”\r\n</p>\r\n<p>\r\n	3月3日，全国政协主席贾庆林在3日在全国政协十一届四次会议开幕会上向大会报告工作时指出，要积极探索利用互联网收集社情民意的新方式，成为党和政府舆情汇集和分析机制的重要方面。\r\n</p>\r\n<p>\r\n	而此次百度数据报告进入两会并广受好评，即是对贾庆林主席这番话语的有力支持。\r\n</p>', '', '', '67', '1', '1326769561', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('2', '1', '4', '0', '0,', '-1', '-1', '', '首届百度高校互联网产品设计大赛开幕', '', '', 'f', '', 'admin', '', '', '', '<p>\r\n	近日，由全球最大的中文搜索引擎公司百度发起的首届“2011高校互联网产品设计大赛”在北京大学正式启动，百度产品总监李健以互动演讲拉开了大赛序幕。据悉，该赛是互联网企业首次面相全日制在校大学生举办的产品设计比赛，旨在推动大学生增强互联网创新实践，为大学生提供实现自我价值的平台，同时也为互联网创新发展积蓄人才力量。\r\n</p>\r\n<p>\r\n	据了解，首届比赛仅接受北京地区的参赛选手，整个活动将从3月中旬一直持续到5月底。参赛同学可组团通过线上报名方式（<a href=\"http://pmstar.baidu.com/\">http://pmstar.baidu.com</a>）提交方案，方案可涉及网页产品、客户端产品和无线应用产品，进入复赛的团队将得到百度资深产品设计人员的一对一指导。\r\n</p>\r\n<p>\r\n	最终筛选出获奖团队6支，他们不仅可以获得金额从5000元至2万元不等的“校园产品之星”奖学金，还将获得2011百度产品部暑期实习的绿色通道，有机会在企业一线体验互联网产品设计和创新实践。\r\n</p>\r\n<p>\r\n	李健表示：“互联网行业发展一日千里，需要更多优秀而有创新精神的人才加入，而大学生正是创新的生力军的新鲜血液，百度希望能够为他们提供一个平台，发现并施展自己的价值，为推动互联网创新发掘更多新生力量。”\r\n</p>\r\n<p>\r\n	启动仪式现场，来自北大、清华、中科院、北邮、北航等多所高校的上千名学生兴致勃勃滴聆听了李健的演讲，现场掌声不断，同学们踊跃发言并提出了自己关心的各种问题，涉及最多的话题是sns社交网络和移动互联网，还有不少同学在现场立即通过大赛官网报名参赛。\r\n</p>\r\n<p>\r\n	一名来自北航的学生表示讲和宿舍同学一起组团报名，他说：“最近两年互联网发展太快，我们在学校有深切的体会，参加这样的比赛，能有机会进行实战锻炼，还有机会和专业人士一对一地切磋交流，对大学生是个难得的机会。”\r\n</p>\r\n<p>\r\n	一位身处互联网多年的人士指出，高校一直是互联网创新的发源地，不仅在国内，在国际，类似facebook这样具有代表性的互联网公司，都是诞生在大学校园，他们为全球互联网技术和形态的创新发展做出了开创性的定义。而中国目前已经拥有超过4.57亿的互联网用户，也是全球最大的互联网市场，每一项互联网创新技术应用都会在这个巨大的市场中经受考验和培育，从而影响整个市场。\r\n</p>', '', '', '55', '2', '1326769590', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('3', '1', '4', '0', '0,', '-1', '-1', '', '百度启动“应用基金奖励计划”', '', '', '', '', 'admin', '', '', '', '<p>\r\n	当下，开放平台的APP模式正席卷全球，国外的鼻祖Facebook借助开放平台力量，聚拢了5亿用户，谷歌Android系统以开放横扫手机市场，苹果App Store模式更成为行业经典。APP的开放浪潮势不可挡，中国互联网行业也开始集体行动，百度、腾讯、新浪、淘宝等纷纷逐鹿开放平台，APP商业模式日渐主流。近日，百度更是在应用开放平台领域重磅出击：宣布启动应用基金奖励计划，投入数亿元激励第三方应用开发者和运营商，为搜索用户创新更多优质应用。\r\n</p>\r\n<p>\r\n	与大多数APP开放平台不同的是，百度开创了全球第一个由平台方“自掏腰包”成立基金为优秀免费应用买单的APP平台。奖励的目标将是免费应用的资源方（开发者或运营商），按用户在网页搜索中的日有效使用量，进行奖励计费，未来还会根据资源方对用户体验的贡献程度评分划级，对于评分级别越高的资源方将给予更多奖励。\r\n</p>\r\n<p>\r\n	<strong>应用变现 让第三方有利可图</strong> \r\n</p>\r\n<p>\r\n	如今应用开放平台可谓蔚然成风，然而，产业链层面的火热却很难解决开发者自身生存状态的矛盾和挣扎。即使在最为火爆的苹果APP Store，能够真正赚钱者也还是少数，更多的人则是在陪太子读书。在国内市场，受制于民众免费观念的侵蚀，广大开发者和运营商的“钱途”更为渺茫，应用开放平台，似乎只是“看起来很美”。\r\n</p>\r\n<p>\r\n	然而，百度应用开发者基金奖励计划的隆重开启，让广大开发者和运营商看到了希望。根据这一计划，百度预计将投入数亿元，面向平台所有开发者或运营商鼓励创新应用的开发。百度开放平台相关负责人表示，百度愿意为可持续发展的行业生态的建立做出表率，除了提供各个层面的强力支持，也包括实实在在的利益回报，让应用变现，让开发者劳有所得，有利可图。百度通过“自掏腰包”的输血方式，将推动更多的开发者参与进来，创造更多的高品质应用，让免费的应用也能转化成收益。“现在我不用过多考虑赚钱的事，只要能开发出网友喜欢的作品，百度会来买单。”奖励计划出台后，有开发者兴奋的表示。\r\n</p>\r\n<p>\r\n	<strong>同步起跑&nbsp; 流量及品牌双重提升</strong> \r\n</p>\r\n<p>\r\n	在国外，成功的开放平台几乎主导了行业的发展方向，应用提供方“寄人篱下”，自主发展和品牌提升空间并不大，尤其是一些实力较小的开发者，即使有优秀的应用产品，脱颖而出的机会并不大，最终很容易形成几家APP独大的局面。\r\n</p>\r\n<p>\r\n	百度开放平台则着重开发者的长远利益，通过分享百度每日数十亿的检索流量及覆盖95%网民群体的品牌影响力，开发者可以共享高黏性、高忠诚度的平台效应，在较短的时间内获得用户的认可，争取到海量用户和自身品牌价值的提升。\r\n</p>\r\n<p>\r\n	显然，这是与单纯注重收益为主的开放平台最大的区别。通过对免费应用的支持，任何一个开发者，都站在同一条起跑线上，所面临的机遇都是平等的，这对于国内的第三方开发者来说不只是福音，更是加速创业的不竭动力。\r\n</p>\r\n<p>\r\n	<strong>扶持应用创新力量成长壮大</strong> \r\n</p>\r\n<p>\r\n	不可否认，Facebook、苹果等国外通行的分成模式，刺激了开发者的成长，催生了一大批优质的游戏、商务、娱乐等应用，但也滋生了开发者“赚一票就走”的心态，这对于第三方开发商或运营商的成长来说，并无益处。<br />\r\n百度应用基金奖励计划的设立初衷在于扶持互联网行业的创新力量，更注重开发者的成长帮助，期望通过一套透明、有效的合作机制，一个利益共享平台、以及技术和资金的有效扶持，推动互联网创新力量的崛起并逐步壮大。\r\n</p>\r\n<p>\r\n	百度也透露，此次“应用基金奖励计划”的启动仅仅是百度开放平台战略规划中的重要一步，未来百度还将会有一系列举措出台，不排除对一些有潜力的开发者和运营商尝试深入合作，为其提供后续的技术和资金上的帮助。\r\n</p>\r\n<p>\r\n	业内专家表示，APP开放平台模式将是未来互联网发展的趋势，以百度应用基金奖励计划为序曲，百度的APP开放将为用户带来更全面、便捷的应用体验，大大降低使用门槛，使用户便捷实现在线娱乐、在线游戏、在线商务等功能。同时对行业来说，更具深远意义：开放架构通过调动产业链开发者、运营方等资源，将打破传统技术壁垒，改变应用分散、使用率低、优质应用被淹没等一系列弊端，营造更为健康有序的循环生态链，这不仅是互联网架构的一次革命性升级，更是未来互联网生态系的雏形。\r\n</p>', '', '', '167', '3', '1326769617', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('4', '1', '4', '0', '0,', '-1', '-1', '', '百度开展网上“地球一小时” 践行绿色环保之路', '', '', '', '', 'admin', '', '', '', '<p>\r\n	近来，日本猝然遭遇史上最强地震海啸袭击，环境和自然灾害等问题愈发引起人们更多的关注和行动。面对这些问题，任何独立个人和企业的力量都显得单薄，需要有一个强大的联系纽带。“地球一小时”正是这样一个纽带意义的活动。3月26日20:30—21:30，2011年度的“地球一小时”活动即将启动。全球最大中文搜索引擎百度，作为世界自然基金会（WWF）“地球一小时”中国区独家搜索引擎合作伙伴，已率先于3月21日起，整合旗下地图、知道、百科、空间、新闻、身边等产品展开为期一周的百度“地球一小时”低碳环保公益行动，唤起全体国民的环保意识。\r\n</p>\r\n<p>\r\n	百度“地球一小时”专题页面向大家全面展现了“地球一小时”活动的意义及开展情况，全方位传播绿色环保、节能减排知识。百度地图开启了“标注你的位置，参与地球一小时”的线上活动，网友可以登录百度“地球一小时”专题页面（<a href=\"http://earth.baidu.com/\">http://earth.baidu.com</a>）或世界自然基金会“地球一小时”官方网站（<a href=\"http://earthhour.org.cn/\">http://earthhour.org.cn</a>），填写姓名和电子邮件后，在线承诺“熄灯一小时”和“一个环保改变”，随即在百度地图上标注自己参与“熄灯一小时”活动的位置，留下一个绿色的“足迹”。除了为官方网站提供API接口外，百度android手机地图还提供了一个全新的玩法，让网民朋友可以在熄灯后将自己的位置分享给好友，实现彼此实时关注；此外，百度地图首页专题上还专门设置了“熄灯去哪儿”板块，为广大网民提供了公园、广场、健身房等众多熄灯后的好去处，倡导“黑暗”中的健康生活方式。\r\n</p>\r\n<p>\r\n	据悉，此次活动百度进行了六大产品的公益联动。除了地图，百度知道通过知道环保问答征集以及用户环保徽章，与广大网民进行了环保话题的深度互动，而且专题页面还会抓取知道带有环保关键词的待解决问题、已解决问题展示、以及提问按钮，供网友回答、提问、浏览，让网友在“问答”中感受环保的可贵；百度百科，则借助亿万网友的力量，通过环保百科词条，对环保知识进行大力普及；而百度空间更是通过空间环保活动征文，让网友在记录中加强环保意识；此外，百度新闻还全面抓取了“地球一小时”的相关资讯，增强网民对环保新闻的关注度；覆盖全国368个城市超过百万商户的生活信息搜索和分享平台百度身边，更是通过和 “真功夫”合作于3月24日发起 “身边真功夫，聚会地球熄灯一小时”线下活动。届时其北京地区33家门店都将关闭招牌灯，网友在享受浪漫烛光晚餐的同时，还可以通过身边客户端上传店铺照片、进行现场播报，完成后就可得到真功夫给身边用户的独家优惠。\r\n</p>\r\n<p>\r\n	百度相关负责人表示，作为一个负责任的企业公民，百度在为数以亿计的网民提供便捷获取信息方式的同时，也一直关注环境保护。百度希望借助“地球一小时”活动，唤起每个人、每个企业的环保意识，每一天、每一刻从身边的小事一点一滴做起，为节能减排发挥各自的作用。百度也将继续践行绿色环保之路，与广大网民一起，为中国的环保事业贡献一己之力。\r\n</p>', '', '', '155', '4', '1326769646', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('5', '1', '4', '0', '0,', '-1', '-1', '', '百度推出“招聘会”搜索 助力学子就业', '', '', '', '', 'admin', '', '', '', '<p>\r\n	进入3月，应届毕业生又将辗转于各大火爆的招聘会现场，迎接“面霸”生活。或许今年莘莘学子们会有不一样的体验。因为日前，全球最大中文搜索引擎百度借助强大的数据开放平台上线了“招聘会”搜索功能，通过对招聘会、企业招聘职位资源的整合，为广大求职者提供海量、全面、精准的求职信息检索服务。\r\n</p>\r\n<p>\r\n	通过该功能，用户只需在百度搜索框输入“招聘会”或“某省市招聘会”等相关关键词，百度框计算系统将自动对接招聘会信息资源提供方，智能识别用户所在的城市，反馈回当地最新的招聘会相关信息，包括时间、地址等。而结合百度地图服务，求职者可以继续查询到从所在地到招聘会现场的公共交通路线，为参加招聘会提供便利，并合理安排自己的应聘计划。<br />\r\n<br />\r\n数据显示，2011年国内高校毕业生高达660万人，是本世纪初的6倍以上。进入3月之后，2011年的第一波招聘求职高峰已经到来。据各地媒体报道，数万人挤爆招聘会现场的情况已经在不断上演，“跑会一族”成为应届毕业生的普遍生存状态。而随着百度“招聘会”搜索功能上线，学子们不仅能获得全面准确的招聘信息，且“跑会”也将更加具有针对性和条理性。\r\n</p>\r\n<p>\r\n	“很多时候参加招聘会都很盲目，不知道取舍，常常是去了招聘会现场才发现根本没有去的必要，却错过了真正应该参与的场次。百度的招聘会搜索，极大方便了我对于招聘会的筛选和面试计划，而且连地图、公交地铁线路都有考虑到，非常贴心。”很多大学生对记者纷纷表示道。\r\n</p>\r\n<p>\r\n	业内人士分析，除了毕业生，百度“招聘会”搜索是一个让招聘企业、招聘会主办方、第三方招聘会发布平台多方共赢的合作模式。通过百度数据开放平台，招聘企业可以更好地安排招聘计划，招聘会主办方可以更好地带动人气和整体运营。而对于第三方招聘会发布平台，目前与百度合作的“应届生”、“应届生毕业生”等多家资源方表示，“通过百度招聘会搜索，不但借助百度海量用户优势将招聘会信息最大化进行有效传递。同时，通过与百度平台的对接获得每天数十亿次检索的机会，在流量、用户和品牌等诸多方面都将获得立竿见影的提升。”\r\n</p>\r\n<p>\r\n	据悉，在招聘会之外，包括智联招聘、中华英才、赶集网、同城58、百姓网等全国一百多家主流招聘网站，也已经悉数加入百度开放平台，通过百度这个中文上网第一入口为亿万求职、跳槽者带来便利。据统计，目前每天有数百多万人通过这种搜索方式找工作。\r\n</p>\r\n<p>\r\n	从百度提出“框计算”以来，一直致力于通过搜索让人们最便捷、最全面、最及时地获得信息，从“客服电话”直接显示、邮箱实现搜索页面直接登录、股票信息实时查询，到高考信息查询、招聘信息查询等等一系列搜索新功能，搜索请求结果正在越来越多的直接呈现在搜索页面上，网民的搜索一站式体验正在一步步得到提升。“框计算”及百度开放平台，正以其强大的技术创新能力为依托，为数亿用户带来一次次全新的搜索体验。\r\n</p>', '', '', '120', '5', '1326769660', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('6', '1', '4', '0', '0,', '-1', '-1', '', '百度市值超腾讯成为中国互联网企业第一', '', '', 'h,a', '', 'admin', '', '', '', '<p>\r\n	3月24日消息 百度（NASDAQ：BIDU）周三报收于132.58美元，其市值也达到了460.7亿美元，超过了腾讯控股（HKG：0700）昨日收盘时的市值，成为中国互联网企业第一。这也是5年来，第一头衔的首次易主。腾讯昨日报收于189.4港元，市值约为446亿美元。\r\n</p>\r\n<p>\r\n	周三开盘后一路上扬，截至收盘报收于132.58美元，涨幅达4.32%。股价创业近52周的新高，市值达到460.7亿美元。而在2005年百度上市时市值仅8.7亿美元，迄今已经增长近53倍。\r\n</p>\r\n<p>\r\n	百度于今年2月1日公布了第四季度财务报告，数据显示该季度百度总营收24.5亿元，同比增长94%；净利润为11.6亿元，同比增长 171.3%。在线广告业务仍然是百度的最主要收入来源。而百度官方新闻稿中则称同比接近翻番的增长速度，标志着百度在第二个十年发展的起跑阶段又开始重新加速。\r\n</p>\r\n<p>\r\n	腾讯则是在3月16日公布了第四季度财务报告，数据显示第四季度总营收55亿元，同比增长49.8%，环比增长5.7%，净利润22亿元，环比增2.1%，同比增45.9%。总营收和净利润增速均出现下滑，其净利润增速创三年来最低。\r\n</p>\r\n<p>\r\n	或受财报不利的消息影响，腾讯股价已连续多日下挫，从220港元跌至昨日的189港元，创下一个月来的新低。\r\n</p>', '', '', '95', '6', '1326769687', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('7', '1', '4', '0', '0,', '-1', '-1', '', '百度文库版权合作平台上线 诚意探索多方共赢', '', '', '', '', 'admin', '', '', '', '<p>\r\n	目前，百度文库版权合作平台正式上线（wenku.baidu.com/hezuo），该平台包括与版权方的具体合作形式，以及对版权合作方的宣传支持等几大板块内容。显而易见，百度此举在表现出其诚意态度的同时，更以迅速行动力和执行力，寻求与版权方的合作共赢。<br />\r\n<br />\r\n<strong>多种合作形式可供选择</strong> \r\n</p>\r\n<p>\r\n	在该平台页面上，可以详细了解百度文库对付费分成模式、广告分成模式的相关介绍。配合这两种合作模式，百度文库将通过多个宣传渠道对合作的正版资源进行宣传推广。其中，付费分成模式将允许用户免费阅读作品部分章节，在此基础上，如果读者希望阅读全本内容，则需要通过网络支付通道支付一定费用，即可将该电子作品存储至自己的个人文库并进行在线全本内容阅读。而经由百度文库收取的费用大部分比例将划拨给版权方所有，从而在确保正版阅读的同时，为版权方带去丰厚的收益回报。\r\n</p>\r\n<p>\r\n	相比之下，广告分成形式则允许读者免费阅读整部作品，但百度文库会在确保用户的优质阅读体验前提下，在作品阅读页面适当位置开发和放置相应广告内容，使作者或版权方获取相应收入。这也意味着作品的吸引力和关注度将会与版权方的收益成正比，作品的浏览量越高，版权方所获得的回报也就越多。\r\n</p>\r\n<p>\r\n	与此同时，针对一些目前暂时尚无法提供全本合作的版权方，百度文库同样给予了足够的关注。版权方可以提供部分新书介绍和免费章节内容，通过文库书店平台，进行新书推广，宣传新书信息，帮助版权方带动实体图书销量。\r\n</p>\r\n<p>\r\n	<strong>强大资源力推正版</strong> \r\n</p>\r\n<p>\r\n	除了提供多种合作形式外，百度文库还利用用户对文学作品、各类文档的巨大搜索量，为版权合作方提供了众多宣传资源来推广正版图书。百度文库将会在文档分享页面、文库书店页面对正版图书进行推荐；在百度搜索结果页增加正版内容展示；还会在文库搜索结果页明显位置对正版作品进行特型展示。此外，还将对版权方旗下的优秀作品、签约作者进行集中宣传，通过专题、活动等形式使版权方和用户互动起来，让版权方的优秀作品、签约作者被更多的读者所知晓、熟悉、喜爱。\r\n</p>\r\n<p>\r\n	为保护作者版权，百度文库最近实行了一系列积极的举措，包括加速文库中可能侵犯他人著作权的文档清理，以及开设绿色举报通道等。除此之外，一项名为 “版权作品DNA比对识别”的技术应用预计将于4月11日上线试运行，该技术将鼓励合作方提供全文正版资源，通过后台识别技术，进行网友上传文档与正版资源的对比审核，从而加速文库识别系统更精准、全面的删除盗版，从源头上阻止侵权文档的上传。\r\n</p>\r\n<p>\r\n	有业内专家指出，互联网已经成为知识普及的重要途径之一。不可否认百度文库在保护版权方面还有一些需要改进和提升的地方，但是我们也欣喜的看到百度主动沟通的意愿、开诚布公的态度以及因此而进行的对版权资源合作模式的积极探索。百度提出来的合作模式，一方面给广大网民带来高质量的作品；另一方面也给出版方和作者提供了一个推广及变现的渠道；同时也让百度文库在打击盗版上，迈出了坚实的一步，可谓多方共赢。\r\n</p>\r\n<p>\r\n	百度文库相关负责人表示，百度非常重视版权的保护问题，同时也希望与版权方建立长期的合作关系，引入丰富的内容，为广大网友提供一个正版内容的阅读平台，同时为版权方构建一个宣传、获益的营销阵地。刚刚一年半左右的百度文库正以其诚意和实际行动向业界表明：在版权保护方面，百度文库一直在努力。百度的心态是开放的，乐于听取来自社会各界的建议和意见，寻求多方的合作共赢。在保护版权方利益的基础上，将更优质的资源、更好的产品、更体贴的服务奉献给广大用户。\r\n</p>', '', '', '92', '7', '1326769711', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('8', '1', '4', '0', '0,', '-1', '-1', '', '百度与音著协达成合作 与音乐人分享著作权收益', '', '', 'c,f', '', 'admin', '', '', '', '3月31日下午消息，百度公司与中国音乐著作权协会(简称音著协)宣布达成合作，双方将共同建立音乐词曲著作权合作主渠道，这意味着音乐词曲权利人可以通过音著协这个主渠道，获得相关著作权收益。<br />\r\n<br />\r\n在互联网上，各类音乐著作权人分布非常广泛，如何找到一个有效的授权方式是数字音乐正版化的一个巨大挑战。百度是第一家与音著协共建著作权合作主渠道的互联网企业。<br />\r\n<br />\r\n据透露，从2008年开始，百度就开始通过与滚石、索亚、EMI等词曲权利人直接合作，获得了相关词曲作品在百度上的使用权。基于此次百度与音著协的合作，进一步建立了音乐作品数字化环境下的授权主渠道，相关音乐作品的许可使用费由百度支付给音著协，并由音著协按照有关规定转交相关权利人。<br />\r\n<br />\r\n百度市场与公关副总裁朱光表示，百度一贯重视知识产权保护工作，并将通过自身努力，积极与相关机构合作，主动探索回馈音乐著作权人的新模式。网络音乐是中国 4亿网民非常喜爱的一项网络应用，百度音乐平台一方面将用更好的产品和技术，免费为网民提供更加优质的音乐体验；另一方面，我们始终认为词曲作者是数字音乐产业繁荣的根本推 动力量，此次和音著协达成的合作，是我们长期坚持数字音乐正版化和回馈版权方的一个重大里程碑。<br />\r\n<br />\r\n中国音乐著作权协会副总干事刘平表示，音著协是中国唯一的音乐著作权集体管理组织，代表着国内国际最广泛的音乐词曲著作权人权益，而百度是中国最大的数字音乐分享平台，上面汇聚了4亿多网民的需求。双方发挥各自的优势，以实际行动解决行业内多年以来悬而未决的数字音乐版权授权难题，这对中国整个数字音乐产业来说，具有开天辟地的历史意义。<br />\r\n<br />\r\n百度音乐事业部总经理梁康妮透露，从去年11月开始，百度就与音著协积极探讨保护词曲权利人权益的有效方式，并根据百度音乐平台的整体使用情况对分成方案进行认真细致的制定和评估，百度将定期向音著协提供每一首歌曲的播放和下载数据报表，这种计算方式此前已经运作超过一年，并获得合作机构认可。而为了保证该项合作能真正向词曲版权方做到公正和透明，百度也在开发新的系统，将支持所有词曲作品版权方获取自身作品在百度音乐平台上播放下载次数统计。<br />\r\n<br />\r\n梁康妮同时介绍，目前音乐著作权主要包括词曲著作权和邻接权，前者的权益主体主要是词曲作者和词曲著作权机构，后者的权益主体主要是艺人和唱片公司。除了词曲著作权方面的合作，目前百度也已经与全球范围内80多家唱片机构就邻接权签订了分成合作协议，目前还在进一步与其他唱片机构展开合作谈判。', '', '', '140', '8', '1326769736', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('9', '1', '4', '0', '0,', '-1', '-1', '', '中影集团携《建党伟业》影片资源 登录百度开放平台', '', '', '', '', 'admin', '', '', '', '近日，建党90周年献礼影片《建党伟业》宣布该片将于6月15日上映，在海报揭幕仪式上，影片出品人兼导演韩三平携导演黄建新及众多主演一同助阵。同时，记者发现，在全球最大中文搜索引擎百度上搜索“建党伟业”，搜索结果以图文并茂的整合方式呈现《建党伟业》影片的相关资料，包括影片介绍、电影片花、明星采访视频、剧照图片、新闻专题、演职员表等。记者联系到中影集团相关负责人，该负责人确认已将《建党伟业》相关影片资源通过百度开放平台发布，提前和观众见面，希望能够直接面向网民发布正版的优质影片资源。<br />\r\n<br />\r\n据了解，百度自2010年9月推出框计算应用开放平台，“即搜即用”理念极大地提升了网民的搜索体验，受到用户的好评。2010年底，中影集团及旗下中国电影网便开始和百度秘密接触，洽谈双方在百度开放平台上的联袂合作。此次，中影集团将2011年最受关注的年度大戏官方资源通过百度开放平台与观众提前见面，无疑可见中影已经嗅到来自百度开放平台的巨大发展机会。<br />\r\n<br />\r\n中国电影网CEO王国伟表示：“中国电影网宗旨是依托中影集团优良的产业资源和品牌优势来服务大众。我们已经看到，百度作为互联网最有影响力的入口，每天服务全中国数亿网民的生活和娱乐，而百度开放平台以创新的方式为资源提供方、用户架起了一座桥梁。我们希望借助百度开放平台，让中影旗下的优质影视资源能够直接面向数亿互联网观众，进而共同探索电影在互联网市场的营销新模式。”<br />\r\n<br />\r\n据了解，百度应用开放是百度“框计算”技术理念的重要实践成果，“框计算”理念由百度总裁兼CEO李彦宏于2009年8月提出，是一种基于需求分析和网络资源调用的高度智能的互联网需求交互模式。理念提出后，百度先后推出数据开放平台和应用开放平台，网民只需要在搜索框中输入相关关键字，便可以直接调用相关正版优质网络资源，实现“即搜即用”，极大提升了网民的搜索体验。<br />\r\n<br />\r\n有评论人士指出，互联网的深度普及已经让人们在电影领域的消费习惯和观影方式都发生了巨大变化，除了院线播映，越来越多电影需要通过多元化的渠道来解除用户。而这次中影与百度两大行业巨头的试水合作也为影视内容出版与互联网渠道的深度融合催生出更多想象空间。<br />\r\n<br />\r\n王国伟表示，“中影的优质正版资源与百度的开放平台相结合，不仅给亿万网友提供了更好的阅读和观赏体验，同时也对《建党伟业》这样的影片起到了非常好的品牌宣传作用。互联网的快速发展，对于影视内容及其他传统文化出版行业来说是一个需要把握好的新机遇。长远来看，我们相信这种合作模式无论对于传统内容出版发行方、互联网，还是广大网友来说，都将是共赢和利好的结果。”<br />\r\n<br />\r\n据悉，近期中影在影片资源推介会公布了2011-2012重点项目，其中包括已经开拍的陆川作品《王的盛宴》、冯小宁作品《1894甲午大海战》、王晶作品《无价之宝》；正在后期制作中的吴宇森作品《飞虎群英》等悉数在列。若《建党伟业》在百度开放平台上试水成功，我们或将看到中影旗下更多优质影视资源登录百度开放平台，届时也无疑将令网民大饱眼福。', '', '', '116', '9', '1326769760', 'false', '', '0');
INSERT INTO `pmw_infolist` VALUES ('10', '1', '4', '0', '0,', '-1', '-1', '', '权威核辐射监测数据登录百度开放平台 消除公众恐慌', '', '', '', '', 'admin', '', '', '', '4月2日，据新华社发布最新消息：我国除西藏外的省份部分地区均监测到极微量放射性物质，不会对我国环境和公众健康造成危害，无需采取任何防护措施。近日，由于日本地震引起的核泄漏事件不断发展，有关核辐射的最新动态也成为我国民众时下最受关注的话题。<br />\r\n<br />\r\n今天中午，记者发现，在全球最大中文搜索引擎百度中搜索“辐射监测”“中国核辐射”等词，在结果页可直接看到来自国家环境保护部官网的中国境内核辐射的最新监测数据，网民可随时关注其所在城市的核辐射数据动态。<br />\r\n<br />\r\n记者致电百度相关负责人了解到，数据上线短短几小时内，登录百度开放平台查询核辐射监测结果的相关搜索量已突破一万次。百度开放平台负责人表示，这些信息均为来自于国家环保部的官方信息，供网民第一时间了解到权威性、准确的信息。除此以外，百度还将环保部网站中放射性核素钚简介、正确看待核辐射等科普知识的链接一并呈现，便于公众了解和正确认识核辐射现状，消除恐慌。<br />\r\n<br />\r\n据了解，在之前的“抢购食盐”风波中，百度通过“框计算”开放平台，及时将政府信息传递给公众，让谣言仅仅“存活”了2天时间即恢复平静。作为全球最大的中文搜索引擎，百度覆盖全中国超过4亿网民群体，每日响应近数十亿次的搜索请求，已经成为互联网最有影响力的信息获取入口。<br />\r\n<br />\r\n业内人士表示，在互联网信息传播空前复杂的时代，由于信息传播的不对称和互联网上无权威的现状，一些不准确的信息很容易引起民众恐慌。百度开放平台在第一时间联合政府相关部门，利用搜索引擎技术及百度作为互联网平台的影响力，将权威监测数据及时送达网民，极大地帮助消除民众因无法及时获得正确信息而引起的恐慌。', '', '', '98', '10', '1326769776', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('11', '1', '4', '0', '0,', '-1', '-1', '', '云起龙骧 共赢未来——“第六届百度联盟峰会”布局开放新时代', '', '', 's', '', 'admin', '', '', '', '<p>\r\n	4月12日，主题为“云起龙骧，共赢未来”的“第六届百度联盟峰会”在云南丽江盛大开幕。来自全国各地的数百家合作伙伴齐聚一堂，与百度董事长兼首席执行官李彦宏，百度高级副总裁沈皓瑜等百度高层，共同就开放创新、互联网未来发展趋势进行深度交流和探讨，此次盛会也受到了百度50余万家联盟合作伙伴以及整个互联网业界瞩目。\r\n</p>\r\n<p>\r\n	与往届联盟峰会不同的是，在本届大会现场，活跃着众多中小网站站长及个人开发者的身影，形成了一道独特的风景。这也契合了本届百度联盟峰会的最大重头戏——百度APP平台全面开放，为众多中小网站及第三方开放者提供一个广阔的创新发展平台，帮助他们实现创业梦想。\r\n</p>\r\n<p>\r\n	据悉，从2002年成立至今，百度联盟经历了九年的发展，从基于流量的搜索时代，到基于受众注意力的全网时代，而今迈进了跨越式的“开放时代”。在这个崭新的阶段，不仅用户的互联网应用需求变得愈发个性和多样，同时互联网产业链之中的各个角色之间的合作也更加扁平。作为全球最大的中文搜索引擎，百度将借助APP平台全面开放的力量构建一种全新的协同体系，在开放、分享和共赢的理念之下，与合作伙伴一起携手，推动我国互联网产业的开放特质和创新氛围，打造一个生机勃勃的互联网生态圈。“百度每年将斥资数千万鼓励创新，为合作伙伴在品牌、流量、收益等多方面带来有效的提升，助力产业发展。”百度高级副总裁沈皓瑜透露。\r\n</p>\r\n<p>\r\n	一路走来，百度联盟的影响力与日俱增，目前已经累计有50余万家合作伙伴加入百度联盟并迅速成长，其中既有成功上市的顺网科技等知名企业，也不乏刚刚毕业的大学生创业者。在沈皓瑜看来，在搜索时代，百度联盟的工作重心是如何基于搜索为伙伴们带来更多收益和快速成长；在全网时代，百度在搜索服务的基础上推出的网盟业务覆盖面更广，不断提高合作伙伴分成奖励的同时，还帮助伙伴优化用户体验、提高流量向收益的转化率；而在开放时代，百度除了将继续加大对搜索和网盟业务的投入，还将通过APP平台的全面开放，为用户提供更便捷优质的使用体验，为合作伙伴提供巨大的成长空间及品牌价值收益。可以预见，基于百度应用开放平台的合作，未来年收入几万级、几十万级和数百万级的应用将会涌现，开发者将获得更透明、公平的竞争机会，成为推动中国互联网繁荣、健康、持续发展的关键力量。\r\n</p>\r\n<p>\r\n	在本届峰会上，百度不仅宣布全面开放APP平台，还明确了普通开发者加入APP平台及获益的方式。百度将通过实施“百度应用成长基金”计划等一系列措施，力求使开发者们可以基于百度开放平台实现分享合作的收益回报，为他们的持续创新注入动力。百度方面表示，希望以基于框计算架构的开放平台为核心，在为亿万网民奉上优质应用体验的同时，为第三方应用开发商、运营商构建一个鼓励创新、促进成长、赢得回报的巨大舞台，真正形成一种有助于产业链中各种角色成长的良性健康机制。\r\n</p>\r\n<p>\r\n	除此之外，百度还详细介绍了一系列旨在帮助伙伴们获得成长，加速良性互联网生态圈形成的利好举措，包括鸿媒体业务、提高分成比例等，力求从技术、品牌、资金、收益、服务等多个角度全方位地帮助合作伙伴获得成长。百度联盟总经理褚达晨介绍称，去年的百度联盟峰会上，百度发布了三大举措来助力联盟伙伴发展，涵盖收益、服务、成长三方面。而今年，“百度将继续加大对网盟业务的技术和资源的投入；不断丰富和优化联盟产品，匹配媒体和推广客户需求；继续针对网盟优质流量、优质广告位提高分成比例，使伙伴分享更大收益。”褚达晨表示，百度希望立足于全面开放的战略，与伙伴们合作共赢、相互促进，最终促进整个产业的升级。“而这也正是百度联盟下一阶段努力的方向。”\r\n</p>\r\n<p>\r\n	百度的这一系列新举措和表态，得到了广大合作伙伴及开发者的极大关注。业内人士评价指出，依托于百度强大的品牌号召力和成熟的推广模式，百度联盟经过多年精心运营，已发展成为国内最大和最具实力的网络推广联盟。百度对于合作伙伴的持续大力扶持，加之全面开放的战略，将帮助更多网站和网络开发者、创业者们更好地成长和成功，并带动整个产业进一步发展和繁荣，迎来一个全新的互联网开放时代。\r\n</p>', '', '', '153', '11', '1326769798', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('12', '1', '4', '0', '0,', '-1', '-1', '', '百度开放知道携手金山WPS 共建办公软件网络帮助平台', '', '', '', '', 'admin', '', '', '', '<p>\r\n	一个是风靡的互联网产品，一个是深得人心的客户端办公软件，这两者相遇会发生什么样的化学反应？近日，百度知道开放平台（http://www.baidu.com/search/openiknow/）与知名办公软件金山WPS展开了深度合作，金山WPS官网创建“知道频道”（http://zhidao.wps.cn/），同步百度知道相关office、WPS等软件使用帮助问答内容；同时双方共建的“知道频道”已嵌入新版WPS Office办公软件中，带来客户端帮助服务的一次革命。嵌入开放知道的最新版WPS Office已于4月12日正式发布（下载地址：http://www.wps.cn/）。百度知道与金山WPS携手开创了互联网产品与客户端软件合作的先河，为用户带来全新的应用和服务体验，是一次双赢的创举。\r\n</p>\r\n<p>\r\n	此次与金山WPS的合作，更是树立了百度知道开放平台一个新的里程碑。具体合作方式上，开放知道与金山WPS共建的“知道频道”嵌入了WPS客户端，用户在工具栏点击“WPS知道”按钮即可在软件内直接提问、搜索、回答。同时金山WPS在官网开通“知道频道”并与百度知道打通，百度知道中的 Office、WPS等软件使用问题会同步到双方共建的“知道频道”。随着新版WPS Office完成全面升级，5000万用户将使用到嵌入“WPS知道”的新版软件服务。百度与金山共建的“知道频道”，将成为网络第一的办公软件问答平台，为网友提供更加聚焦、更加专业且全面的软件知识帮助。从此，每当用户遇到软件使用问题时，面对的将不再是冷冰冰的帮助文档，而是千万有着同样使用经历的知道网友提供的定制化解决办法，极大提升了解决问题的速度与专业度。\r\n</p>\r\n<p>\r\n	有业内分析指出，此次合作无论对知道开放平台，还是对金山WPS，都是一个重大利好。对百度知道开放平台来说，不仅覆盖了众多新鲜的潜在用户，而且把开放知道从Web端向桌面端推进了一大步，提升了用户的使用体验和黏性；对金山WPS来说，携手开放知道既丰富了WPS Office的应用功能，又可以借助百度知道庞大、优质的用户数量与流量，为WPS Office用户提供更好的服务与问题解答。\r\n</p>\r\n<p>\r\n	业内人士的分析也得到了市场的印证，此前金山办公软件开展了“Office的问题 WPS全知道”的主题活动，活动上线仅仅10天，就得到了超过2000名知道网友的追捧，他们纷纷加入到Office专家团，为WPS用户提供图文并茂的专业指导。“对于办公软件，用户经常会发现总是有功能选项、函数、图表不会用。联手开放知道后，WPS的新一代互联网开放式服务平台已正式上线，借助知道网友的力量，掀起一场客户端客服系统的全新革命。”金山软件相关负责人说道。\r\n</p>\r\n<p>\r\n	百度知道相关负责人表示，百度知道一直坚持走开放路线，并取得了巨大的成果。和金山WPS的合作，是百度知道开放平台的又一成功案例和重要里程碑。今后百度还将继续践行开放之道，同时加强同各类客户端软件的深度合作，充分挖掘各自产品的资源优势，打造互联网产品、合作伙伴、客户端软件以及广大网民共赢的产业链和生态圈，推动各方的共同发展与进步。\r\n</p>\r\n<p>\r\n	据了解，百度知道自2005年上线以来，已经累计为广大网民成功解决超过一亿个问题，相当于全体网民共同编纂了超过1000本《十万个为什么》。不仅如此，百度知道还引领潮流，实行开放战略，积极搭建知识需求者和知识提供者之间的桥梁。如今已经有近2000家的合作伙伴与开放知道展开了频道合作模式、数据合作模式等多种形式的合作，为用户带来及时、便捷、准确的问答体验，极大的发挥了知识的价值。\r\n</p>', '', '', '118', '12', '1326769820', 'false', '', '0');
INSERT INTO `pmw_infolist` VALUES ('13', '1', '4', '0', '0,', '-1', '-1', '', '百度：先驱者的探索', '', '', 'f,s', '', 'admin', '', '', '', '<p>\r\n	4•26世界知识产权日临近，回顾过去，很多关于网络知识产权问题依旧无解；不过今年，在百度带动下，中国互联网版权问题迎来了一个可喜的拐点。\r\n</p>\r\n<p>\r\n	多年来，互联网版权争端层出不穷，内容创作者对互联网上盗版泛滥可谓五味俱杂。一方面享受到互联网传播带来的名利双收，另一方面则对侵权行为深恶痛绝。而互联网企业限于诸多原因，根本无暇顾及根除侵权内容或是思考提供长久解决之道。但不久前，百度通过与作家群体、音乐人群体的合作探索，以全新的思路为产业的健康良性发展开辟出一条道路。\r\n</p>\r\n<p>\r\n	<strong>能力越大，责任越大</strong> \r\n</p>\r\n<p>\r\n	每一次新技术的深入发展都会带来了新问题的涌现。当广播出现的时候，音乐界曾经奋起抗争坚决抵制广播中出现他们的原创音乐；电视剧、电影也在与新媒介就分享问题几经斗争。百度文库、音乐如今面临挑战也是行业必然。不过，百度在设立这些服务之初，就纳入了深深的责任思考。\r\n</p>\r\n<p>\r\n	百度文库立足于为教育行业提供丰富的文档资源。为大中小学教育、外语学习、资格考试等领域提供的文档占据了八成，为广大师生借助互联网拓展自身视野，提高自主学习能力提供舞台。\r\n</p>\r\n<p>\r\n	作为国内最早提出与音乐权利人分利机制的互联网平台，百度一直努力推动音乐正版化进程。从2007年开始，百度陆续与全球范围内近百家唱片公司签约，保障音乐著作权所有者的合法权益，其中包括滚石唱片、EMI、英皇唱片等著名音乐公司，艺人及歌曲资源比较优秀的本土唱片公司每年能通过与百度合作获得数千万的收入。\r\n</p>\r\n<p>\r\n	在面对各方权利人版权问题非议时，互联网领域知名律师于国富曾指出，百度文库有非侵权的合理用途，适用于国家《信息网络传播权保护条例》（亦称避风港原则）。2010年北京市海淀区人民法院审理百度文库案件时，认为百度文库符合该条例，驳回了原告的全部诉讼请求。\r\n</p>\r\n<p>\r\n	不过，百度并没有借助 “避风港原则”对众多权利人的声音充耳不闻，而是义不容辞地承担起了保护网络知识版权的责任。同作家拓展及实践分成模式、与音乐人委托机构建立合作主渠道、斥巨资投身音乐正版化平台社区建设……其所有行动无一不昭示着大企业的责任观。\r\n</p>\r\n<p>\r\n	<strong>能力越大，作用越大</strong> \r\n</p>\r\n<p>\r\n	无论是通过用户付费、广告分成、还是平台优先展现再经由多种形式变现，赋予作家等权利人前景；还是尝试与音乐权利方共建合作主渠道，对用户按使用付费，百度都在现实层面上简化了版权保护操作，为通过技术创新与制度完善规范正版资源提供了范本。\r\n</p>\r\n<p>\r\n	在百度与音著协就网络音乐作品授权使用问题达成战略合作后。根据双方的协议，对于百度MP3搜索到的音乐，无论授权作品还是非授权作品链接，百度都将根据用户在线播放和下载次数，委托音著协与词曲作者进行分成。有媒体评价称，百度作为第一家与音著协共建著作权主渠道的互联网企业，让数字音乐的版权尤其是音乐词曲著作权收益题开始“破冰”，成为以公开、透明化机制促进数字音乐公平有序发展的典范。\r\n</p>\r\n<p>\r\n	资深互联网专家胡延平曾表示，今天的百度应该被肯定，至少它是中国互联网企业中做出最多努力的一员。数字版权保护一时还没有理想终极的解决方案，但我们欢迎这种建设性的、有助于多方合作共赢的做法出现。\r\n</p>\r\n<p>\r\n	从某种程度上，百度成为了践行诉求数字时代版权合法化的先驱者。在百度出台一系列致力于保护互联网知识版权的举措后，中国广播电视协会旗下相继诞生了广播、电视的版权专项委员会；各类版权维权平台也推出了自己的大型版权方案，一些编剧群体甚至成立了兼具经纪和权利委托性质的专业公司。一些人士预测，百度身后，信息商业价值开始将被更集中地审视和重估。\r\n</p>\r\n<p>\r\n	在一个变革的时代，新生事物与旧有体系的矛盾与冲突在所难免，但这些冲突也推动着利益相关群体去思考问题的症结所在，通过各方的携手努力实现新秩序的建立和产业的发展。也许，这就是百度作为先驱者探索的价值。\r\n</p>', '', '', '156', '13', '1326769836', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('14', '1', '4', '0', '0,', '-1', '-1', '', 'CBSI全面牵手百度联盟蜜月吸金', '', '', '', '', 'admin', '', '', '', '“CBSI旗下所有媒体都跟百度有全面而深入的合作，我希望‘蜜月期’能一直持续下去。” CBSI(中国)高级副总裁刘小东在2011年百度联盟峰会上对记者说。\r\n作为全球最大的专业互动内容网络，2007年，CBSI中国的互联网业务翻开了全新一页，成为百度联盟中众多联盟伙伴的一员。这绝不是CBSI高层一拍脑袋所做出的行为，事实上，2007年时百度已覆盖全中国95%的网民，CBSI(中国)高级副总裁刘小东对此很有感触，“而且，百度的联盟合作伙伴在过去几年发展非常快”，这两点最终促成了CBSI与百度的牵手。\r\n蜜月“吸金”\r\n“达成3000万人民币是我们跟百度联盟合作的一个目标。”刘小东说。真正达成这个目标却比他预想的要快，“我们在2007年脱离Google系统，进入到百度系统，2008年比2007年我们的收入翻了10倍，当然也是因为2007年基数比较小的原因”。\r\nCBSI的追求不止于此。随后，无论是旗下1.0的媒体，还是2.0的社区，CBSI都将其纳入百度联盟系统。至此，CBSI开始了与百度的“蜜月期”，与百度进行全面合作。甚至2010年新收购的闺蜜网和周公解梦也被其迅速纳入百度联盟系统。“通过收入分成模式，百度的收益已经慢慢成为我们的一个重要收入来源。”刘小东坦言。\r\n除带来实实在在的收益外，百度还帮联盟伙伴节省了大量经费。刘小东以55BBS举例说，“作为一家2.0的社区网站，55BBS通过与百度联盟的合作，像百度统计、百度广告管家，都可以使用百度免费提供的，不用浪费资源自己再建一个强大的团队来做。”\r\n据百度财报数据，2004年百度联盟给伙伴分成达到1090万元，2010年百度联盟的分成收入达到了7.6亿，6年来，百度给联盟合作伙伴带来的收益增长了70倍，甚至超过自己的增长速度。2011年，百度将分给联盟合作伙伴多少？“突破10亿”，百度联盟总经理褚达晨很有信心。\r\n流量品牌双助益\r\n对于百度这些联盟伙伴来说，网站导流和品牌宣传也很关键。百度能否在这两方面交给联盟伙伴一份完美的答卷？刘小东给出的答案是肯定的。他还以 55BBS为例，这个女性的城市社区，涉及婚假、购物等众多领域，如果再建一个庞大销售团队的话，对资金链压力也颇大。“透过百度联盟的合作，包括鸿媒体，百度TV的合作，可以带给网站更多高质量内容的用户、客户。”他说。\r\n据悉，目前百度联盟注册会员近50万，针对他们在互联网创业生命周期中不同阶段的诉求，百度联盟从服务平台、成长计划、站长工具、沟通平台四个方面为会员提供着全方位的运营支持。\r\n刘小东对此深有体会，“包括常青藤、包括先锋论坛，可以给我们很多，让我们认识到国内更多的优秀的战略，优秀的互联网专家，让大家的知识汇聚在一起，让我们整个联盟伙伴对于互联网的应用能力包括技术开发能力都有所提高。”他认为，这些对增加网站管理人员的专业水平具有积极意义。\r\n2010年8月，百度联盟还推出“互联网创业者俱乐部”。成立以来，它开展了9场互联网培训活动，活动辐射全国数百万互联网创业者，其中，互联网的站长超过了1万名。从沟通、收益、成长、融资方面给予创业者支持。\r\n业内人士认为，百度对于合作伙伴的持续大力扶持，加之全面开放的战略，将帮助更多网站和网络开发者、创业者们更好地成长和成功，并带动整个产业进一步发展和繁荣，迎来一个全新的互联网开放时代。', '', '', '162', '14', '1326769846', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('15', '1', '4', '0', '0,', '-1', '-1', '', '2011中国慈善排行榜出炉 百度入选年度十大慈善企业', '', '', '', '', 'admin', '', '', '', '<p>\r\n	2011年4月26日，由民政部指导发布的第八届中国慈善排行榜在国家会议中心正式揭晓。百度作为唯一入围的互联网企业，获评年度十大慈善企业称号。\r\n</p>\r\n<p>\r\n	“在刚刚过去的2010年，百度用自己的努力和坚持，积极践行公益事业、回馈社会，这也是其此次获奖的原因所在。”大会主办方评价称，无论是成立百度公益基金会，用更专业的管理践行公益；还是推行“阳光行动”，荡涤互联网不良信息；或是积极投身教育，为乡村教师送到最新的资讯和最先进的课件；以及扶贫基金会联合启动“爱心包裹”，为孩子们送去欢笑，百度公益像七色阳光一样，看似平淡朴实，却有着阳光般的温暖和力量。\r\n</p>\r\n<p>\r\n	在颁奖仪式上，百度总裁助理张东晨表示，互联网时代的新公益已经成为媒体和社会普遍关注的热点话题，而互联网也已经成为社会了解公益信息、参与公益活动的主要渠道。“百度希望能以技术创新推动公益创新，充分利用互联网平台的影响力，在互联网推动公益事业方面有更大突破。”\r\n</p>\r\n<p>\r\n	近年来，百度先后参与并发起了一系列公益活动，今年初还特别成立了百度基金会，围绕知识教育、环境保护、灾难救助等领域，更加系统规范地管理和践行公益事业。就在几天前，百度一手打造的全国首个互联网公益开放平台也正式上线试运行，旨在为全国公益组织提供免费推广。目前，包括中国扶贫基金会、中国红十字会基金会、中国宋庆龄基金会在内的多家5A级公益机构已经成为这一公益平台的首批受益者，而其他有意向的公益机构目前也已经可以通过百度公益官方网站（gongyi.baidu.com）报名申请加入公益开放平台，经百度后台审核通过之后，公益组织即可获得百度的免费推广服务。预计未来几年，全国两千多家基金会也将陆续加入，从而形成透明度最高、参与规模最大、门槛最低的公益生态网络。\r\n</p>\r\n<p>\r\n	中国基金会中心网首席执行官程刚表示：“全民公益是公益发展的必然趋势。百度通过自身巨大的平台影响力和网络资源，为公益信息的公开和透明做出了巨大贡献。未来，希望有更多基金会和企业共同携手，更好地利用互联网来践行网络公益。”在他看来，百度在公益方面的系列举措，将充分调动和释放互联网平台在社会公益层面的影响力，为公众获取公益信息、参与公益行动提供更便捷畅通的渠道，进一步推动整个社会全民公益目标的实现。\r\n</p>\r\n<p>\r\n	就在此次入围民政部“年度十大慈善企业”榜单之前，百度刚刚荣获了中国扶贫基金会颁发的“中国全民公益突出贡献奖”。而历年来，“2010地球一小时企业最佳创意奖”、“中国企业社会责任特别大奖”等一连串沉甸甸的慈善及社会责任奖项，不仅是对百度在践行公益方面的认可，也意味着百度在公益创新发展的道路上，已经成为互联网行业的先锋力量。\r\n</p>', '', '', '101', '15', '1326769867', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('16', '1', '4', '0', '0,', '-1', '-1', '', '百度：构筑信息时代的全民公益', '', '', 'c,f', '', 'admin', '', '', '', '<p>\r\n	红十字基金会、青少年基金会、扶贫基金会……这些公益机构的名称都是当下大多数人耳熟能详的，但是，如果要问这些机构的具体信息，旗下都有哪些具体的公益项目正在开展等，恐怕就不是所有人都清楚的了。一面是不断扩大的公益组织规模和民众热情，一面却因为信息传播不足，民众难以及时参与其中。如今，这一尴尬局面有望打破——近日，笔者上网时发现，在搜索引擎百度检索“中国扶贫基金会”等词语，在搜索结果页面最显著位置，能够直接看到该基金会的背景、账户等信息，基金会下的各种具体项目也都一目了然。笔者得知，这一功能的实现，源于百度打造的全国首个互联网公益开放平台的上线试运行。\r\n</p>\r\n<p>\r\n	除中国扶贫基金会外，目前，已经有包括中国红十字基金会、中国青少年基金会在内的近100家基金会或标杆公益项目加入了百度公益开放平台，并获得百度所提供的免费推广宣传资源。百度公益开放平台一期面向国内2000多家基金会开放测试，二期将辐射中国近百万注册NGO，从而覆盖整个中国公益圈，让公益信息在百度上触手可及。\r\n</p>\r\n<p>\r\n	<strong>信息时代的新公益</strong> \r\n</p>\r\n<p>\r\n	自成立之日起，百度就一直坚持 “让人们最便捷地获取信息，找到所求”的企业使命，充分利用自己的互联网及技术优势，来帮助人们平等地获取信息，并秉持责任承诺，在教育、环保、扶贫、赈灾等领域践行着自己弥合信息鸿沟、共享知识社会的企业公民理想，广受业界好评。\r\n</p>\r\n<p>\r\n	2008年12月，百度充分调动公司内部各种资源，帮助湖北秭归脐橙通过网络推广宣传、开拓销售渠道，短时间内卖出7万多吨脐橙；在汶川、玉树地震中，百度公司共捐助约1500多万元；此外，百度持续三年参与“爱心包裹”公益行动，2010年10月，百度打造了首款公益类优质资源应用——“保益悦听掌上盲道”网络平台，将百度为盲人获取信息的触角延伸到了手机之上，让数以万计的盲人用户可以通过手机来发短信、上网，让更多的弱势群体都能通过百度的平台领略互联网的科技魅力。\r\n</p>\r\n<p>\r\n	2011年1月，百度更是正式获批成立了百度公益基金会，目前正在搭建专业的管理团队，制定基金会的公益战略规划，基金会的关注方向将主要集中在资助青少年、弱势群体、贫困地区与公益机构提高信息技术应用水平，推动建立公益信息平台，资助救灾、教育、环保等公益项目。\r\n</p>\r\n<p>\r\n	<strong>构筑全民公益平台</strong> \r\n</p>\r\n<p>\r\n	在公益事业的践行上，百度早已走在产业前列，然而，百度的步伐不仅仅停留于此。\r\n</p>\r\n<p>\r\n	作为中国市值最大的互联网公司，近年来，百度更加重视的，是如何进一步发挥出核心的技术优势，以技术力量驱动公益创新，为更多企业、个人、公益组织、慈善机构提供更加广阔的互联网平台。\r\n</p>\r\n<p>\r\n	而此次百度公益开放平台破茧而出，面向全国公益组织，免费为其在互联网上做推广时，解决的则是目前公益界最为突出的问题——公益信息的集结、公开和透明。\r\n</p>\r\n<p>\r\n	正如Robin所说，“我们期待，通过网络的力量，公益的善举与精神能够与公众零距离接触。推动全社会公益氛围形成，使公益与空气和阳光一样触手可及。”未来，百度会立足核心科技、创新优势，驱动公益体系变革、创新、蓬勃发展。而在百度的榜样效应下，一个更开放、透明、规模更大的中国互联网公益生态圈正在形成，让网络改变公益，让公益触手可及。\r\n</p>', '', '', '161', '16', '1326769881', 'false', '', '0');
INSERT INTO `pmw_infolist` VALUES ('17', '1', '4', '0', '0,', '-1', '-1', '', '百度与Facebook成为全球成长最快品牌', '', '', '', '', 'admin', '', '', '', '<p>\r\n	2011年5月9日，世界顶级品牌沟通服务集团WPP旗下权威调研公司华通明略发布第六届年度“BrandZ 全球最具价值品牌100强 (BrandZ Top 100 Most Valuable Global Brands)”排行榜。其中，中国最大搜索引擎百度品牌价值排名全球第29位，与Facebook共同成为全球价值增长最快的品牌，并在科技类细分榜单中，成为跻身全球科技品牌10强的唯一中国公司。\r\n</p>\r\n<p>\r\n	据悉，“BrandZ 全球最具价值品牌100强”研究根据财务数据，结合品牌资产的消费者指标，分析得出品牌价值，并以此评出全球最具价值100个品牌。目前，该榜单已成为国际公认的最权威的品牌排行榜之一。在今年的百强榜中，百度由2010年的第75位跃升至第29位，品牌价值增长达141%，仅次于今年刚上榜排名第35位的Facebook，后者的品牌价值增长为246%。\r\n</p>\r\n<p>\r\n	2011年BrandZ报告指出，“随着中国13亿公民中越来越多的人开始使用互联网搜索，他们更多地倾向于使用百度。因为他们相信，百度能够更深入地理解中国的多元文化和语言中的细微差别。”\r\n</p>\r\n<p>\r\n	事实上，以“让人们最便捷地获取信息，找到所求”为使命的百度一直致力于为用户提供最优质的搜索体验。除了不断致力于技术、产品及服务创新，为网民提供了60余款与搜索相关的产品和服务外，加强在移动、SNS等新兴领域的战略部署外，百度CEO李彦宏还在2009年，创造性地提出了“框计算”理念，并相继推出数据及应用两大开放平台，推动更多优质的数据及应用资源与网民的需求直接对接，以实现“即搜即得”、“即搜即用”。目前，框计算已经影响了 63%以上的搜索结果，深受网民好评。而优质的用户体验，也使得百度以市场份额80%左右的绝对优势，持续领跑中国搜索引擎市场。\r\n</p>\r\n<p>\r\n	更值得关注的是，通过框计算及百度开放平台，百度为众多创业者和开发者提供了广阔的创业及创新平台，并帮助其从创新中受益和发展，百度对于互联网产业链发展及创新的影响力也正在逐渐释放。\r\n</p>\r\n<p>\r\n	百度品牌的快速增长，也得益于其在公益领域的突出贡献。自成立来，百度就一直致力于充分利用自己的互联网及技术优势，在教育、环保、扶贫、赈灾等领域践行着自己弥合信息鸿沟、共享知识社会的企业公民理想，广受业界好评。从帮助湖北秭归农民利用网络推广滞销脐橙,到捐资1500多万元、用于汶川及玉树等震区进行应急救灾和灾区重建工作；从打击互联网不良信息、净化产业环境的“阳光行动”，到帮助盲人创业者打造“掌上盲道”网络平台，让数以万计的盲人用户可以通过手机来发短信、上网；从成立百度公益基金会、用更加专业的管理专注于救灾、教育、环保等公益项目，到推出全国首个互联网公益开放平台、为全国公益组织提供免费推广，百度在积极践行公益事业、回馈社会的同时，也正使得公益的门槛不断降低，推动着互联网时代全民公益理想的实现。\r\n</p>\r\n<p>\r\n	分析人士认为，作为中国技术创新企业的杰出代表，百度公司成为全球成长最快的品牌之一并跻身全球科技品牌10强，体现了中国高科技企业蓬勃的生命力和巨大的发展潜力，也将激励更多中国品牌、尤其是中国科技品牌在世界的崛起。\r\n</p>', '', '', '156', '17', '1326769895', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('18', '1', '4', '0', '0,', '-1', '-1', '', '百度“发微” 一键群发催生“框微控”', '', '', '', '', 'admin', '', '', '', '<p>\r\n	计世网消息：网民“善变之图”曾是个地地道道的“状态控”，哪有好吃、好玩的，“善变之图”总是第一时间在即时聊天工具或社交网站的状态栏里同时更新。但当她开始发觉自己的状态总被各种日志、照片等社交信息淹没后，“善变之图”又成了彻头彻尾的“围脖控”，然而很快又有了新烦恼：为了兼顾几个微博帐户的粉丝，一条微博，要多次登录发好几遍。直到最近，她发现百度上竟然可以实现“微博群发”了，于是她又成为一个新“控”——“框微控”。\r\n</p>\r\n<p>\r\n	“框微”即“框发微博”，用户可直接通过这一应用，将微博内容同步发布到搜狐、腾讯、网易微博中。只要在百度搜索框中键入“发微博”，即可触发百度框计算的“微博在线群发”应用（如下图）。同时，选择并登录相应微博发布入口，即可一键群发一条微博内容到多个微博帐户。\r\n</p>\r\n<p>\r\n	笔者使用发现，除了通过“微博在线群发”实现框发微博，还可直接通过百度搜索框实现微博发布。当网友的搜索内容被百度自然语言识别为微博需求时，即会触发“框发微博”应用提示。如，输入“期待明天能有好天气”这类形同微博内容的语句，用户便可选择是否将内容发布到微博中，并点击实现。\r\n</p>\r\n<p>\r\n	据悉，自“框发微博”低调上线以来，该应用已在网友中日益风行起来，其新奇、简单、高效的微博体验也引发了广大用户的口碑相传。网友 “Harolden-霍大爷”便说：“百度推框发微博，感觉还真的蛮不错”。网友“烟雨画浓”也表示，在全国微博用户达到一亿之际，百度推出“框发微博” ，开启了一个全民微博时代。网友李元则更为宏观地评论到：“百度的发展速度真是快的让人无法想象，尤其是框计算提出以来，让你想不到的东西，一下就会出现在你的眼前。前面是哼唱搜索、百度识图，这不又来了，在百度就可发微博了，看来创新真的可以改变一切。”\r\n</p>\r\n<p>\r\n	百度相关负责人告诉记者：“由百度官方开发的‘框发微博’应用，目前仍处于成长期，尚只支持140字以内的文字内容和网址发布。未来，‘框发微博’ 还将基于用户的实际需求，增加对图片、视频等内容的发布，完善交互功能，扩展合作平台，以更好地实现一键群发微博的创新应用，降低用户的微博发布门槛，提升用户的微博体验。”在源源不绝的创新驱动和技术支持之下，也许我们可以预言，百度这个框除了“发微”，还要发威。\r\n</p>', '', '', '60', '18', '1326769910', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('19', '1', '4', '0', '0,', '-1', '-1', '', '爱佑华夏联合百度在京举办“爱由心生”慈善晚宴', '', '', 'h', '', 'admin', '', '', '2011年5月14日晚，国内首家非公募基金会爱佑华夏慈善基金会（简称爱佑华夏）联合百度公司在北京盘古酒店4层大宴会厅举办了以2011“爱由心生”为主题的慈善晚宴。', '<p>\r\n	2011年5月14日晚，国内首家非公募基金会爱佑华夏慈善基金会（简称爱佑华夏）联合百度公司在北京盘古酒店4层大宴会厅举办了以2011“爱由心生”为主题的慈善晚宴。出席此次晚宴的嘉宾有爱佑华夏慈善基金会理事长王兵、百度公司董事长兼CEO李彦宏、新浪网CEO曹国伟、腾讯公司董事长马化腾、北京万通实业股份有限公司董事长冯仑、上海巨人网络科技有限公司董事长史玉柱、恒基兆业地产集团副主席李家杰等众多中国知名企业家，此次晚宴旨在向基金会的发起人、捐赠人和社会各界展示基金会7年多的发展历程和极致透明的特点，探讨爱佑华夏以及中国慈善基金会未来的发展前景。\r\n</p>\r\n<p>\r\n	目前，爱佑华夏慈善基金会已完成1万名先天心脏病儿童的救助工作，下一阶段将重点关注白血病儿童的救治和援助。今年是爱佑华夏基金成立七周年，百度公司董事长兼CEO李彦宏、新浪网CEO曹国伟受邀正式加入爱佑华夏慈善基金会并成为新的理事。爱佑华夏基金会理事、恒基兆业副主席李家杰宣布向基金会捐款1000万。\r\n</p>\r\n<p>\r\n	爱佑华夏慈善基金会理事长王兵表示，爱佑华夏已经成长为产品型基金会，随着基金会的发展规模和法律法规的完善，爱佑华夏也会出现新的变化。在未来5 到10年，爱佑华夏致力于发展为平台型的基金会，让更多的慈善组织都能通过这个平台找到合适的公益项目。把爱佑华夏打造为社区型的基金会，为慈善基金会的发展提供一个新的视角。愿意始终坚持以企业家的精神，让每一份捐赠不留遗憾的使命，以热忱、正直、高效、创新的价值观不断提醒每一位热心公益的爱心人士，给生命一次机会，给孩子一个未来，推动中国慈善事业的发展。\r\n</p>\r\n<hr style=\"page-break-after:always;\" class=\"ke-pagebreak\" /><p>\r\n	较早前，爱佑华夏基金也加入了百度公益开放平台，通过互联网的开放平台，为基金会及其下爱佑童心等公益项目在全国范围进行免费推广，集结全社会的爱心力量，让更多需要帮助的孩子通过网络平台得到救助。据悉，百度公益开放平台旨在为全国公益组织提供免费推广，将公益组织的官方权威信息及资源与公众直接对接，为公众了解公益信息提供便利；目前已有包括中国扶贫基金会、红十字会基金会、宋庆龄基金会等5A级基金会在内的首批公益机构加入。百度公益基金会秘书长张东晨表示：“百度公益基金会还将持续关注并支持爱佑华夏基金会各类慈善项目，在资助青少年、弱势群体、贫困地区与公益机构提高信息技术应用水平方面做更多贡献。”\r\n</p>', 'templates/default/images/imgdata/newsimg.png', '', '165', '19', '1326769925', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('20', '1', '4', '0', '0,', '-1', '-1', '', '湖南奥昇信息网+监督 项目介绍', '', '', 'c', '', 'admin', '', '', '', '', 'uploads/image/20170702/1498994447.jpg', '', '112', '20', '1498987050', 'true', 'true', '1499068873');
INSERT INTO `pmw_infolist` VALUES ('21', '1', '4', '0', '0,', '-1', '-1', '', '区域卫计生管理', '', '', 'c', '', 'admin', '', '', '', '', 'uploads/image/20170702/1498994664.jpg', '', '51', '21', '1498987268', 'true', 'true', '1499068868');
INSERT INTO `pmw_infolist` VALUES ('22', '1', '4', '0', '0,', '-1', '-1', '', '智慧教育', '', '', 'c', '', 'admin', '', '', '', '', 'uploads/image/20170702/1498995818.jpg', '', '53', '22', '1498987335', 'true', 'true', '1499068865');
INSERT INTO `pmw_infolist` VALUES ('23', '1', '14', '0', '0,', '-1', '-1', '', '湖南奥昇信息网+监督 项目介绍', '', '', 'h', '', 'admin', '', '', '', '', 'uploads/image/20170703/1499078872.jpg', '', '189', '23', '1499069218', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('24', '1', '14', '0', '0,', '-1', '-1', '', '区域卫计生管理', '', '', 'h', '', 'admin', '', '', '', '', 'uploads/image/20170703/1499074524.jpg', '', '123', '24', '1499069272', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('25', '1', '14', '0', '0,', '-1', '-1', '', '智慧教育', '', '', 'h', '', 'admin', '', '', '', '', 'uploads/image/20170703/1499073099.jpg', '', '176', '25', '1499069317', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('26', '1', '16', '0', '0,', '-1', '-1', '', '公司简介', '', '', 'a', '', 'admin', '', '', '', '', 'uploads/image/20170703/1499073473.png', '', '183', '26', '1499072837', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('27', '1', '16', '0', '0,', '-1', '-1', '', '荣誉资质', '', '', 'a', '', 'admin', '', '', '', '', 'uploads/image/20170703/1499074532.png', '', '91', '27', '1499072935', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('28', '1', '16', '0', '0,', '-1', '-1', '', '董事长致辞', '', '', 'a', '', 'admin', '', '', '', '', 'uploads/image/20170703/1499080433.png', '', '154', '28', '1499072987', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('29', '1', '16', '0', '0,', '-1', '-1', '', '企业文化', '', '', 'a', '', 'admin', '', '', '', '', 'uploads/image/20170703/1499077572.png', '', '79', '29', '1499073047', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('30', '1', '4', '0', '0,', '-1', '-1', '', '新闻动态的图片', '', '', 'c', '', 'admin', '', '', '', 'TML标准自1999年12月发布的HTML4.01后,后继的HTML5和其它标准被束之高阁,为了推动Web标准化运动的发展,一些公司联合起来,成立了一个叫做 Web Hypertext Application Technology Working Group （Web超文本应用技术工作组WHATWG的组织。WHATWG致力于Web表单和应用程序，专注于XHTML2.0在 2006年,双方决定进行合作,来创建一个新版本的HTML。', 'uploads/image/20170703/1499086828.png', '', '180', '30', '1499080444', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('31', '1', '4', '0', '0,', '-1', '-1', '', '列表', '', '', 'j', '', 'admin', '', '', '智慧溆浦介绍', '', '', '', '194', '31', '1499081448', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('32', '1', '4', '0', '0,', '-1', '-1', '', '列表', '', '', 'j', '', 'admin', '', '', '教师的“铁饭碗”将不保？各省份将破除教师资格“终身制”？', '', '', '', '189', '32', '1499083756', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('33', '1', '4', '0', '0,', '-1', '-1', '', '列表', '', '', 'j', '', 'admin', '', '', '互联网+监督项目介绍', '', '', '', '106', '33', '1499084417', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('34', '1', '4', '0', '0,', '-1', '-1', '', '列表', '', '', 'j', '', 'admin', '', '', '2016年教育信息化工作要点', '', '', '', '193', '34', '1499084475', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('35', '1', '4', '0', '0,', '-1', '-1', '', '列表', '', '', 'j', '', 'admin', '', '', '互联网巨头涉足医疗产业助力解决“看病难”', '', '', '', '162', '35', '1499084518', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('36', '1', '4', '0', '0,', '-1', '-1', '', '列表', '', '', 'j', '', 'admin', '', '', '可穿戴医疗将在2016年呈爆发式增长', '', '', '', '154', '36', '1499084598', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('37', '1', '4', '0', '0,', '-1', '-1', '', '列表', '', '', 'j', '', 'admin', '', '', '公司与同方合作承建的“互联网+”项目调试成功', '', '', '', '51', '37', '1499084630', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('38', '1', '4', '0', '0,', '-1', '-1', '', '列表', '', '', 'j', '', 'admin', '', '', '《2017年教育信息化工作要点》', '', '', '', '150', '38', '1499084681', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('39', '1', '14', '0', '0,', '-1', '-1', '', '案例展示图片', '', '', 'c', '', 'admin', '', '', '', '', 'uploads/image/20170703/1499092139.jpg', '', '130', '39', '1499086674', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('40', '1', '17', '0', '0,', '-1', '-1', '', '溆浦县智慧教育平台', '', '', 'a', '', 'admin', '', '', '', '', 'uploads/image/20170703/1499090401.jpg', '', '148', '40', '1499089875', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('41', '1', '17', '0', '0,', '-1', '-1', '', '怀化市人民艾默生机房', '', '', 'a', '', 'admin', '', '', '', '', 'uploads/image/20170703/1499094112.jpg', '', '116', '41', '1499089959', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('42', '1', '17', '0', '0,', '-1', '-1', '', '湖南奥昇观摩室基地', '', '', 'a', '', 'admin', '', '', '', '', 'uploads/image/20170703/1499098642.jpg', '', '171', '42', '1499090033', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('43', '1', '17', '0', '0,', '-1', '-1', '', '奥昇自建的机房', '', '', 'a', '', 'admin', '', '', '', '', 'uploads/image/20170703/1499091715.png', '', '125', '43', '1499091317', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('44', '1', '17', '0', '0,', '-1', '-1', '', '奥昇精品录播室', '', '', 'a', '', 'admin', '', '', '', '', 'uploads/image/20170703/1499095329.jpg', '', '74', '44', '1499091412', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('45', '1', '17', '0', '0,', '-1', '-1', '', '多媒体机房放映厅', '', '', 'a', '', 'admin', '', '', '', '', 'uploads/image/20170703/1499092099.jpg', '', '98', '45', '1499091458', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('46', '1', '18', '0', '0,', '-1', '-1', '', '公司简介', '', '', '', '', 'admin', '', '', '', '', '', '', '63', '46', '1499094477', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('47', '1', '18', '0', '0,', '-1', '-1', '', '荣誉资质', '', '', '', '', 'admin', '', '', '', '', '', '', '173', '47', '1499094554', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('48', '1', '18', '0', '0,', '-1', '-1', '', '企业文化', '', '', '', '', 'admin', '', '', '', '', '', '', '160', '48', '1499094578', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('49', '1', '18', '0', '0,', '-1', '-1', '', '董事长致辞', '', '', '', '', 'admin', '', '', '', '', '', '', '51', '49', '1499094603', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('50', '1', '18', '0', '0,', '-1', '-1', '', '公司风采', '', '', '', '', 'admin', '', '', '', '', '', '', '112', '50', '1499094628', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('51', '1', '18', '0', '0,', '-1', '-1', '', '合作伙伴', '', '', '', '', 'admin', '', '', '', '', '', '', '190', '51', '1499094663', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('52', '1', '18', '0', '0,', '-1', '-1', '', '公司地址', '', '', '', '', 'admin', '', '', '', '', '', '', '59', '52', '1499094684', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('53', '1', '18', '0', '0,', '-1', '-1', '', '关于我们', '', '', 'a', '', 'admin', '', '', '', '2015年，优美成立全资子公司湖南奥昇信息技术有限公司，专注于智慧教育、智慧医疗卫生管理等领域的软硬件开发、生产、销售、运营服务及相关大数据开发应用，为客户提供“软件+硬件+运营服务+资金”的专业综合性解决方案。<br />\r\n目前，公司已拥有几十项相关软件著作权，现又与多所高校及企事业单位形成产、学、研深度合作模式，助力创新研发生产、 实践创新运营服务，旨在为教育、医疗卫生等领域提供一流的产品和服务！ 计算机软硬件、互联网技术及应用产品的开发、生产、销售、技术转让及技术服务、培训；信息化项目运营；计算机网络工程；计算机应用工程；电子数据系统租赁及服务；电子商务平台建设；信息科技领域内的技术开发与服务（依法须经批准的项目，经相关部门批准后方可开展经营活动）.目前，公司已拥有几十项相关软件著作权，现又与多所高校及企事业单位形成产、学、研深度合作模式，助力创新研发生产、实践创新运营服务，旨在为教育.', '', '', '83', '53', '1499096564', 'true', 'true', '1499135853');
INSERT INTO `pmw_infolist` VALUES ('54', '1', '14', '0', '0,', '-1', '-1', '', '解决', '', '', 'a', '', 'admin', '', '', '', '', 'uploads/image/20170704/1499100269.jpg', '', '176', '54', '1499098463', 'true', 'true', '1499135865');
INSERT INTO `pmw_infolist` VALUES ('55', '1', '14', '0', '0,', '-1', '-1', '', '解决', '', '', 'a', '', 'admin', '', '', '', '', 'uploads/image/20170704/1499099221.jpg', '', '180', '55', '1499098543', 'true', 'true', '1499135850');
INSERT INTO `pmw_infolist` VALUES ('56', '1', '14', '0', '0,', '-1', '-1', '', '解决', '', '', 'a', '', 'admin', '', '', '', '', 'uploads/image/20170704/1499105595.jpg', '', '120', '56', '1499098594', 'true', 'true', '1499135846');
INSERT INTO `pmw_infolist` VALUES ('57', '1', '14', '0', '0,', '-1', '-1', '', '解决', '', '', 'c', '', 'admin', '', '', '', '', 'uploads/image/20170704/1499100681.jpg', '', '167', '57', '1499099549', 'true', 'true', '1499135841');
INSERT INTO `pmw_infolist` VALUES ('58', '1', '19', '0', '0,', '-1', '-1', '', '湖南奥昇信息互联网+监督 项目....', '', '', 'a', '', 'admin', '', '', '全国政协十二届五次会议提案0001号题目是<<关于将学期三年教育纳入义务教育的提案>>(以下简称提案),第一提案人是全国政协委员,中央财经大学校长王广谦,该提案提出,与九年义务教育相比,学前教育乃是教育体系薄弱环节,学前教育的投资少,资源总量不足,师资短缺,办园水平岑差不齐.............', '', '', '', '128', '58', '1499130457', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('59', '1', '19', '0', '0,', '-1', '-1', '', '区域卫生计管理', '', '', 'a', '', 'admin', '', '', '全国政协十二届五次会议提案0001号题目是<<关于将学期三年教育纳入义务教育的提案>>(以下简称提案),第一提案人是全国政协委员,中央财经大学校长王广谦,该提案提出,与九年义务教育相比,学前教育乃是教育体系薄弱环节,学前教育的投资少,资源总量不足,师资短缺,办园水平岑差不齐.............', '', '', '', '192', '59', '1499130880', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('60', '1', '19', '0', '0,', '-1', '-1', '', '智慧教育', '', '', 'a', '', 'admin', '', '', '全国政协十二届五次会议提案0001号题目是<<关于将学期三年教育纳入义务教育的提案>>(以下简称提案),第一提案人是全国政协委员,中央财经大学校长王广谦,该提案提出,与九年义务教育相比,学前教育乃是教育体系薄弱环节,学前教育的投资少,资源总量不足,师资短缺,办园水平岑差不齐.............', '', '', '', '153', '60', '1499131023', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('61', '1', '14', '0', '0,', '-1', '-1', '', '湖南奥昇信息互联网+监督 项目....', '', '', 'a', '', 'admin', '', '', '全国政协十二届五次会议提案0001号题目是<<关于将学期三年教育纳入义务教育的提案>>(以下简称提案),第一提案人是全国政协委员,中央财经大学校长王广谦,该提案提出,与九年义务教育相比,学前教育乃是教育体系薄弱环节,学前教育的投资少,资源总量不足,师资短缺,办园水平岑差不齐.............', '', 'uploads/image/20170704/1499141634.jpg', '', '147', '61', '1499135990', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('62', '1', '14', '0', '0,', '-1', '-1', '', '区域卫生计管理', '', '', 'a', '', 'admin', '', '', '全国政协十二届五次会议提案0001号题目是<<关于将学期三年教育纳入义务教育的提案>>(以下简称提案),第一提案人是全国政协委员,中央财经大学校长王广谦,该提案提出,与九年义务教育相比,学前教育乃是教育体系薄弱环节,\r\n学前教育的投资少,资源总量不足,师资短缺,办园水平岑差不齐', '', 'uploads/image/20170704/1499137675.jpg', '', '143', '62', '1499136082', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('63', '1', '14', '0', '0,', '-1', '-1', '', '智慧教育', '', '', 'a', '', 'admin', '', '', '全国政协十二届五次会议提案0001号题目是<<关于将学期三年教育纳入义务教育的提案>>(以下简称提案),第一提案人是全国政协委员,中央财经大学校长王广谦,该提案提出,与九年义务教育相比,学前教育乃是教育体系薄弱环节,学前教育的投资少,资源总量不足,师资短缺,办园水平岑差不齐.............', '', 'uploads/image/20170704/1499146122.jpg', '', '122', '63', '1499136365', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('64', '1', '20', '0', '0,', '-1', '-1', '', '新闻资讯图片', '', '', 'a', '', 'admin', '', '', '', '', 'uploads/image/20170704/1499150243.jpg', '', '113', '64', '1499149299', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('65', '1', '21', '0', '0,', '-1', '-1', '', '教育强音 跟你有关!两会这些教....', '', '', 'a', '', 'admin', '', '', '全国政协十二届五次会议提案0001号题目是《关于将学前三年教育纳入义务教育的提案》(以下简称《提案》)，第一提案人是全国政协委员、中央财经大学校长王广谦。 　　该提案指出，与九年义务教育相比，学前教育仍是教育体系中的薄弱环节。学前教育的投资少、资源总量不足、师资短缺、办园水平参差不起、“入.', '', 'uploads/image/20170704/1499159160.png', '', '187', '65', '1499149967', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('66', '1', '21', '0', '0,', '-1', '-1', '', '教师的铁饭碗保不住？各省...', '', '', 'a', '', 'admin', '', '', '近日有媒体报道，温州市教育局发布《温州市中小学教师资格定期注册工作实施方案（试行）》（下简称“方案”）。 该方案规定：定期注册不合格或逾期不注册的人员，不得从事教育教学工作。该方案自2017年3月8日起施行。 从2012年起，包括上海、北京在内的多个省份都开始废除教师资格“终身制”： 每.', '', 'uploads/image/20170704/1499153188.png', '', '98', '66', '1499150195', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('67', '1', '21', '0', '0,', '-1', '-1', '', '《2017年教育信息工作要点》', '', '', 'a', '', 'admin', '', '', '教育部日前发布《2017年教育信息化工作要点》，核心目标是基本实现具备条件的学校互联网全覆盖，多媒体教室占普通教室比例达到80%，基本形成国家教育资源公共服务体系框架。 《要点》强调，要完善教育信息化基础环境建设，加快推进中小学“宽带网络校校通”。结合精准扶贫、宽带中国和贫困.', '', 'uploads/image/20170704/1499158460.png', '', '186', '67', '1499150449', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('68', '1', '16', '0', '0,', '-1', '-1', '', '文字排版', '', '', 'j', '', 'admin', '', '', '2015年，优美成立全资子公司湖南奥昇信息技术有限公司，专注于智慧教育、智慧医疗卫生管理等领域的软硬件开发、生产、销售、运营服务及相关大数据开发应用，为客户提供“软件+硬件+运营服务+资金”的专业综合性解决方案。\r\n目前，公司已拥有几十项相关软件著作权，现又与多所高校及企事业单位形成产、学、研深度合作模式，助力创新研发生产、 实践创新运营服务，旨在为教育、医疗卫生等领域提供一流的产品和服务！ 计算机软硬件、互联网技术及应用产品的开发、生产、销售、技术转让及技术服务、培训；信息化项目运营；计算机网络工程；计', '2015年，优美成立全资子公司湖南奥昇信息技术有限公司，专注于智慧教育、智慧医疗卫生管理等领域的软硬件开发、生产、销售、运营服务及相关大数据开发应用，为客户提供“软件+硬件+运营服务+资金”的专业综合性解决方案。<br />\r\n目前，公司已拥有几十项相关软件著作权，现又与多所高校及企事业单位形成产、学、研深度合作模式，助力创新研发生产、 实践创新运营服务，旨在为教育、医疗卫生等领域提供一流的产品和服务！ 计算机软硬件、互联网技术及应用产品的开发、生产、销售、技术转让及技术服务、培训；信息化项目运营；计算机网络工程；计算机应用工程；电子数据系统租赁及服务；电子商务平台建设；信息科技领域内的技术开发与服务（依法须经批准的项目，经相关部门批准后方可开展经营活动）.目前，公司已拥有几十项相关软件著作权，现又与多所高校及企事业单位形成产、学、研深度合作模式，助力创新研发生产、实践创新运营服务，旨在为教育.', '', '', '97', '68', '1499152047', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('69', '1', '22', '0', '0,', '-1', '-1', '', '加入我们图片', '', '', 'a', '', 'admin', '', '', '', '', 'uploads/image/20170704/1499161818.jpg', '', '52', '69', '1499152639', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('70', '1', '22', '0', '0,', '-1', '-1', '', '前言', '', '', 'h', '', 'admin', '', '', '', '<span style=\"white-space:normal;word-spacing:0px;text-transform:none;float:none;color:#000000;font:13px/20px \'Helvetica Neue\', Helvetica, Arial, sans-serif;widows:1;display:inline !important;letter-spacing:normal;background-color:#dcd9d9;text-indent:0px;-webkit-text-stroke-width:0px;\">湖南奥昇信息技术有限公司专注于教育、医疗卫生等领域的软硬件开发、生产、销售、运营服务及相关大数据开发应用，为客户提供“软件+硬件+运营服务+资金”的专业综合性解决方案。 目前，公司已拥有几十项相关软件著作权，现又与多所高校及企事业单位形成产、学、研深度合作模式，助力创新研发生产、实践创新运营服务，旨在为教育、医疗卫生等领域提供一流的产品和服务.</span>', '', '', '65', '70', '1499153781', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('71', '1', '23', '0', '0,', '-1', '-1', '', '软件研发部经理/高级软件工程师', '', '', 'a', '', 'admin', '', '', '', '<span style=\"white-space:normal;word-spacing:0px;text-transform:none;float:none;color:#000000;font:13px/20px \'Helvetica Neue\', Helvetica, Arial, sans-serif;widows:1;display:inline !important;letter-spacing:normal;background-color:#ffffff;text-indent:0px;-webkit-text-stroke-width:0px;\">1、5年以上开发经验、3年以上带团队经验、曾任研发部部门经理优先；2、3年以上监控、流媒体行业经验，有流媒体或者监控成功项目优先； 3、擅长软件架构，系统分析；4、清楚项目管理流程，具备多个项目全线参与的经验；5、理解软件行业产品、具备产品管理基础理念，懂得产品分析，产品规划；6、具备较强的创新能力、沟通能力、洞察能力、抗压能力；7、具备技术人力管理能力，有丰富的面试软件开发人员经验，擅长人力分配；8、在工作中以身作责，能树立威信，能带动士气。.</span>', '', '', '124', '71', '1499155129', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('72', '1', '23', '0', '0,', '-1', '-1', '', '互联网软件开发工程师', '', '', 'a', '', 'admin', '', '', '', '1、负责公司内部信息系统的搭建与维护，解决硬件、网络、软件与管理等的综合问题； 2、负责电子商务平台的开发、搭建与维护，确保各项目的顺利实施及安全与稳定地运行', '', '', '125', '72', '1499156191', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('73', '1', '23', '0', '0,', '-1', '-1', '', '高级软件工程师(Java)', '', '', 'a', '', 'admin', '', '', '', '1）承担商业产品业务系统功能模块的设计开发工作 ； 2）开展Java相关技术的调研工作 ； 3）采用敏捷的软件流程方法推进项目实施； 4）承担商业产品业务系统功能模块的设计开发工作 ； 5）开展Java相关技术的调研工作 ； 6）采用敏捷的软件流程方法推进项目实施。', '', '', '138', '73', '1499156264', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('74', '1', '23', '0', '0,', '-1', '-1', '', '项目经理（数字教育-三通两平台）', '', '', 'a', '', 'admin', '', '', '', '1、负责项目施工期间与客户的沟通协调，建立良好的客户关系。 2、负责项目团队的建设和日常管理工作；包括制定计划，组织带领项目团队完成工作目标。 3、负责项目技术交流，现场考察及方案制作。 4、根据方案文件指导监督工程实施。 5、负责项目实施计划制定、进度控制、成本控制、质量控制，确保项目实施在时间和成本范围内满足客户需求。 6、对客户进行系统使用和维护的现场培训。 7、负责管理和执行项目实施，以及项目验收，确保项目按计划完成并通过客户验收。 8、负责合作伙伴及第三方的沟通协调、组织管理、实施管控等工作。 9、擅长客户协调、需求分析、项目计划的分析撰写及项目的进度掌控。 10、负责指导、处理、协调和解决项目中出现的技术和管理问题，保证项目的正常进行。', '', '', '83', '74', '1499156314', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('75', '1', '23', '0', '0,', '-1', '-1', '', '项目经理（数字医疗方向）', '', '', 'a', '', 'admin', '', '', '', '1、负责项目施工期间与客户的沟通协调，建立良好的客户关系。 2、负责项目团队的建设和日常管理工作；包括制定计划，组织带领项目团队完成工作目标。 3、负责项目技术交流，现场考察及方案制作。 4、根据方案文件指导监督工程实施。 5、负责项目实施计划制定、进度控制、成本控制、质量控制，确保项目实施在时间和成本范围内满足客户需求。 6、对客户进行系统使用和维护的现场培训。 7、负责管理和执行项目实施，以及项目验收，确保项目按计划完成并通过客户验收。 8、负责合作伙伴及第三方的沟通协调、组织管理、实施管控等工作。 9、擅长客户协调、需求分析、项目计划的分析撰写及项目的进度掌控。 10、负责指导、处理、协调和解决项目中出现的技术和管理问题，保证项目的正常进行。', '', '', '163', '75', '1499156357', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('76', '1', '23', '0', '0,', '-1', '-1', '', 'IOS/Android无线研发工程师', '', '', 'a', '', 'admin', '', '', '', '负责垂直类目安卓、IOS系统的软件设计，研发&nbsp; - 快速进行Demo研发&nbsp; - 依据项目进度与需求，能按时完成所需功能开发', '', '', '65', '76', '1499156405', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('77', '1', '23', '0', '0,', '-1', '-1', '', '销售运营专员', '', '', 'a', '', 'admin', '', '', '', '- 客户管理项目及系统功能推广，指导销售录入和管理客户信息数据&nbsp; - 监控和维护CRM，监测数据异常并设置系统规则、参数，如行业，政策，销售范围等&nbsp; - 通过数据分析监控客户开发情况，有重点分析并寻找客户开发规则及方法优化方案&nbsp; - 根据销售、服务等业务需求处理数据，提供有效报告&nbsp; - 监督销售员客户销售漏斗及拜访覆盖情况，及时反馈其各级主管并推动工作&nbsp; - 合同流程管理及监控，对业务流进行分析和优化，如：合同审批流分析及优化&nbsp; - 新产品流程、系统、产品线准备；老产品流程更新&nbsp; - 协助部门管理相关工作，如销售人员KPI制定及计算', '', '', '185', '77', '1499156453', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('78', '1', '24', '0', '0,', '-1', '-1', '', '荣誉资质图片', '', '', 'a', '', 'admin', '', '', '', '', 'uploads/image/20170704/1499158325.jpg', '', '153', '78', '1499158217', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('79', '1', '24', '0', '0,', '-1', '-1', '', '荣誉资质右侧图片', '', '', 'h', '', 'admin', '', '', '', '', 'uploads/image/20170704/1499166235.jpg', '', '83', '79', '1499158790', 'true', '', '0');
INSERT INTO `pmw_infolist` VALUES ('80', '1', '26', '0', '0,', '-1', '-1', '', '详情页图片', '', '', 'a', '', 'admin', '', '', '', '', 'uploads/image/20170704/1499172236.jpg', '', '106', '80', '1499163643', 'true', '', '0');

-- ----------------------------
-- Table structure for pmw_infosrc
-- ----------------------------
DROP TABLE IF EXISTS `pmw_infosrc`;
CREATE TABLE `pmw_infosrc` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '来源id',
  `srcname` varchar(30) NOT NULL COMMENT '来源名称',
  `linkurl` varchar(80) NOT NULL COMMENT '来源地址',
  `orderid` smallint(5) unsigned NOT NULL COMMENT '来源排序',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_infosrc
-- ----------------------------

-- ----------------------------
-- Table structure for pmw_job
-- ----------------------------
DROP TABLE IF EXISTS `pmw_job`;
CREATE TABLE `pmw_job` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '招聘信息id',
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '1' COMMENT '站点id',
  `title` varchar(50) NOT NULL COMMENT '位岗名称',
  `jobplace` varchar(80) NOT NULL COMMENT '工作地点',
  `jobdescription` varchar(50) NOT NULL COMMENT '工作性质',
  `employ` smallint(5) unsigned NOT NULL COMMENT '招聘人数',
  `jobsex` enum('0','1','2') NOT NULL COMMENT '性别要求',
  `treatment` varchar(50) NOT NULL COMMENT '工资待遇',
  `usefullife` varchar(50) NOT NULL COMMENT '有效期',
  `experience` varchar(50) NOT NULL COMMENT '工作经验',
  `education` varchar(80) NOT NULL COMMENT '学历要求',
  `joblang` varchar(50) NOT NULL COMMENT '言语能力',
  `workdesc` mediumtext NOT NULL COMMENT '职位描述',
  `content` mediumtext NOT NULL COMMENT '职位要求',
  `orderid` mediumint(8) unsigned NOT NULL COMMENT '排列排序',
  `posttime` int(10) unsigned NOT NULL COMMENT '更新时间',
  `checkinfo` enum('true','false') NOT NULL COMMENT '审核状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_job
-- ----------------------------
INSERT INTO `pmw_job` VALUES ('1', '1', '销售运营专员', '北京', '市场及销售', '1', '0', '面议', '6个月', '2年以上', '本科', '较好', '- 客户管理项目及系统功能推广，指导销售录入和管理客户信息数据&nbsp;<br />\r\n- 监控和维护CRM，监测数据异常并设置系统规则、参数，如行业，政策，销售范围等&nbsp;<br />\r\n- 通过数据分析监控客户开发情况，有重点分析并寻找客户开发规则及方法优化方案&nbsp;<br />\r\n- 根据销售、服务等业务需求处理数据，提供有效报告&nbsp;<br />\r\n- 监督销售员客户销售漏斗及拜访覆盖情况，及时反馈其各级主管并推动工作&nbsp;<br />\r\n- 合同流程管理及监控，对业务流进行分析和优化，如：合同审批流分析及优化&nbsp;<br />\r\n- 新产品流程、系统、产品线准备；老产品流程更新&nbsp;<br />\r\n- 协助部门管理相关工作，如销售人员KPI制定及计算&nbsp;<br />', '<p>\r\n	- 本科以上学历，统计学、计算机或商业管理等相关专业 <br />\r\n- 一年以上互联网企业工作经验 <br />\r\n- 极强的数据分析和逻辑能力 <br />\r\n- 有优秀的统计学知识背景，并对商业运作有自身的理解 <br />\r\n- 熟悉excel、spss的使用及powerpoint的制作 <br />\r\n- 对数据库有一定了解，熟悉基本的使用操作 <br />\r\n- 学习能力强，责任心强，具有优秀的沟通表达和理解能力，团队合作能力 <br />\r\n- 思维活跃，有创新精神，能承受工作压力\r\n</p>', '1', '1326770483', 'true');
INSERT INTO `pmw_job` VALUES ('2', '1', 'IOS/Android无线研发工程师', '上海', '技术', '0', '0', '面议', '3个月', '2年以上', '本科以以上学历', '较好', '- 负责垂直类目安卓、IOS系统的软件设计，研发&nbsp;<br />\r\n- 快速进行Demo研发&nbsp;<br />\r\n- 依据项目进度与需求，能按时完成所需功能开发&nbsp;<br />', '<p>\r\n	- 本科或本科以上学历,计算机相关专业 <br />\r\n- 精通C/C++，熟悉Objective-C，有独立分析和解决问题的能力 <br />\r\n- 一年以上iPhone平台应用程序开发经验，有志于在手机平台方向发展，对技术有热忱 <br />\r\n- 熟悉手机应用软件的设计和开发；同时具有多种手机平台，IOS、android经验者优先 <br />\r\n- 学习能力强，拥有优秀的逻辑思维能力 <br />\r\n- 自我管理能力强，有良好的时间意识 <br />\r\n- 有较好的沟通交流能力\r\n</p>', '2', '1326770537', 'true');
INSERT INTO `pmw_job` VALUES ('3', '1', '数据中心主管', '北京', '管理支持', '1', '0', '面议', '1个月', '5年以上管理经验', '博士', '较强', '- 部门日常事务的协助与支持，活动组织、会务安排、会议记录等&nbsp;<br />\r\n- 整理周报及相关技术文档&nbsp;<br />\r\n- 协助负责人对项目进行技术评估及进度跟进&nbsp;<br />\r\n- 部门各项规章制度监督与执行&nbsp;<br />\r\n- 经理及项目负责人交办其他任务的督办、协调及落实&nbsp;<br />', '<p>\r\n	- 大学本科以上，具有企业管理、市场营销、电子商务等专业知识 <br />\r\n- 一年以上电话销售相关工作经验专业技能 <br />\r\n- 认同公司企业文化，能够承受工作压力，有优秀的销售能力 <br />\r\n- 对客户信息采集有独到的见解 <br />\r\n- 具有优秀的组织和协调能力 <br />\r\n- 具有优秀的演讲和培训能力 <br />\r\n- 有学习意识和团队意识 <br />\r\n- 良好的服务意识、耐心和责任心，工作积极主动 <br />\r\n- 良好的语言表达能力和人际沟通能力\r\n</p>', '3', '1326770577', 'true');
INSERT INTO `pmw_job` VALUES ('4', '1', '软件配置管理工程师', '北京', '技术', '3', '0', '面议', '长期', '2年以上', '本科', '较好', '（至少包含下列一项）&nbsp;<br />\r\n- 部门版本控制系统的维护&nbsp;<br />\r\n- 软件的版本控制&nbsp;<br />\r\n- 版本控制，软件构建工具的开发<br />', '<p>\r\n	- 熟悉CVS,SVN；<br />\r\n- 熟悉软件配置管理、产品数据管理的相关理论； <br />\r\n- 熟悉软件开发过程； <br />\r\n- 熟悉Linux系统基础操作和命令，及Linux环境下版本构建，软件部署； <br />\r\n- 有Python,Perl, ,Shell其中之一脚本语言编程经验者优先考虑； <br />\r\n- 有构建持续集成经验者优先。\r\n</p>', '4', '1326770633', 'true');
INSERT INTO `pmw_job` VALUES ('5', '1', '高级软件工程师(Java)', '上海', '技术', '6', '0', '面议', '长期', '2年以上开发经验', '不限制', '英语四级', '- 承担商业产品业务系统功能模块的设计开发工作&nbsp;<br />\r\n- 开展Java相关技术的调研工作&nbsp;<br />\r\n- 采用敏捷的软件流程方法推进项目实施&nbsp;<br />', '<p>\r\n	- 深刻理解OOA/OOD/OOP编程思想,掌握多种常用的设计模式 <br />\r\n- 熟悉现有主流的java框架(Spring、Struts、Spring mvc、Hibernate、Ibatis、Freemarker等)的基本原理，具备基于之上研发能力<br />\r\n- 关注新技术，了解Groovy，Jruby，熟悉ROR、COC、RESTful编程风格 <br />\r\n- 热爱软件开发，编码基本功扎实，追求完美，有上进心和很强的学习能力 <br />\r\n- 有丰富的web架构设计经验，对web站点的性能调优、站点扩展和内容集成有深刻的理解 <br />\r\n- 熟悉cache原理及主流的cache框架，有集群系统的开发经验优先考虑 <br />\r\n- 有软件项目管理、企业知识管理、研发流程体系管理经验者优先考虑 <br />\r\n- 有互联网互动产品设计开发经验、企业搜索经验者优先考虑 <br />\r\n- 此职位需要三年以上的软件产品研发经验\r\n</p>', '5', '1326770671', 'true');

-- ----------------------------
-- Table structure for pmw_lnk
-- ----------------------------
DROP TABLE IF EXISTS `pmw_lnk`;
CREATE TABLE `pmw_lnk` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '快捷方式id',
  `lnkname` varchar(30) NOT NULL COMMENT '快捷方式名称',
  `lnklink` varchar(50) NOT NULL COMMENT '跳转链接',
  `lnkico` varchar(50) NOT NULL COMMENT 'ico地址',
  `orderid` smallint(5) unsigned NOT NULL COMMENT '排列排序',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_lnk
-- ----------------------------
INSERT INTO `pmw_lnk` VALUES ('1', '栏目管理', 'infoclass.php', 'templates/images/lnkBg01.png', '1');
INSERT INTO `pmw_lnk` VALUES ('2', '列表管理', 'infolist.php', 'templates/images/lnkBg02.png', '2');
INSERT INTO `pmw_lnk` VALUES ('3', '图片管理', 'infoimg.php', 'templates/images/lnkBg03.png', '3');
INSERT INTO `pmw_lnk` VALUES ('4', '商品管理', 'goods.php', 'templates/images/lnkBg04.png', '4');

-- ----------------------------
-- Table structure for pmw_maintype
-- ----------------------------
DROP TABLE IF EXISTS `pmw_maintype`;
CREATE TABLE `pmw_maintype` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '二级类别id',
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '1' COMMENT '站点id',
  `parentid` smallint(5) unsigned NOT NULL COMMENT '类别上级id',
  `parentstr` varchar(50) NOT NULL COMMENT '类别上级id字符串',
  `classname` varchar(30) NOT NULL COMMENT '类别名称',
  `orderid` smallint(5) unsigned NOT NULL COMMENT '排列排序',
  `checkinfo` enum('true','false') NOT NULL COMMENT '审核状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_maintype
-- ----------------------------

-- ----------------------------
-- Table structure for pmw_member
-- ----------------------------
DROP TABLE IF EXISTS `pmw_member`;
CREATE TABLE `pmw_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户id',
  `username` varchar(32) NOT NULL COMMENT '用户名',
  `password` varchar(32) NOT NULL COMMENT '密码',
  `question` varchar(50) NOT NULL COMMENT '提问',
  `answer` varchar(50) NOT NULL COMMENT '回答',
  `cnname` varchar(10) NOT NULL COMMENT '姓名',
  `enname` varchar(20) NOT NULL COMMENT '英文名',
  `avatar` varchar(100) NOT NULL COMMENT '头像',
  `sex` tinyint(1) unsigned NOT NULL COMMENT '性别',
  `birthtype` tinyint(1) unsigned NOT NULL COMMENT '生日类型',
  `birth_year` varchar(10) NOT NULL DEFAULT '-1' COMMENT '生日_年',
  `birth_month` varchar(10) NOT NULL DEFAULT '-1' COMMENT '生日_月',
  `birth_day` varchar(10) NOT NULL DEFAULT '-1' COMMENT '生日_日',
  `astro` varchar(10) NOT NULL DEFAULT '-1' COMMENT '星座',
  `bloodtype` tinyint(2) NOT NULL DEFAULT '-1' COMMENT '血型',
  `trade` varchar(10) NOT NULL DEFAULT '-1' COMMENT '行业',
  `live_prov` varchar(10) NOT NULL DEFAULT '-1' COMMENT '现居地_省',
  `live_city` varchar(10) NOT NULL DEFAULT '-1' COMMENT '现居地_市',
  `live_country` varchar(15) NOT NULL DEFAULT '-1' COMMENT '现居地_区',
  `home_prov` varchar(10) NOT NULL DEFAULT '-1' COMMENT '故乡_省',
  `home_city` varchar(10) NOT NULL DEFAULT '-1' COMMENT '故乡_市',
  `home_country` varchar(15) NOT NULL DEFAULT '-1' COMMENT '故乡_区',
  `cardtype` tinyint(2) NOT NULL DEFAULT '-1' COMMENT '证件类型',
  `cardnum` varchar(32) NOT NULL COMMENT '证件号码',
  `intro` text NOT NULL COMMENT '个人说明',
  `email` varchar(40) NOT NULL COMMENT '电子邮件',
  `qqnum` varchar(20) NOT NULL COMMENT 'QQ号码',
  `mobile` varchar(20) NOT NULL COMMENT '手机',
  `telephone` varchar(20) NOT NULL COMMENT '固定电话',
  `address_prov` varchar(10) NOT NULL DEFAULT '-1' COMMENT '通信地址_省',
  `address_city` varchar(10) NOT NULL DEFAULT '-1' COMMENT '通信地址_市',
  `address_country` varchar(15) NOT NULL DEFAULT '-1' COMMENT '通信地址_区',
  `address` varchar(100) NOT NULL COMMENT '通信地址',
  `zipcode` varchar(10) NOT NULL COMMENT '邮编',
  `enteruser` set('1') NOT NULL COMMENT '认证',
  `expval` int(10) NOT NULL COMMENT '经验值',
  `integral` int(10) unsigned NOT NULL COMMENT '积分',
  `regtime` int(10) unsigned NOT NULL COMMENT '注册时间',
  `regip` varchar(20) NOT NULL COMMENT '注册IP',
  `logintime` int(10) unsigned NOT NULL COMMENT '登录时间',
  `loginip` varchar(20) NOT NULL COMMENT '登录IP',
  `qqid` varchar(32) NOT NULL COMMENT '绑定QQ',
  `weiboid` varchar(32) NOT NULL COMMENT '绑定微博',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_member
-- ----------------------------
INSERT INTO `pmw_member` VALUES ('1', 'testuser', '85f0fb9cc2792a9b87e3b3facccedc40', '6', '你猜呢', '测试账号', 'TestUser', '', '0', '0', '-1', '-1', '-1', '-1', '-1', '-1', '-1', '-1', '--', '-1', '-1', '--', '-1', '', '', 'webmaster@phpmywind.com', '', '', '', '-1', '-1', '-1', '', '', '1', '1000', '0', '1350904403', '127.0.0.1', '1350904403', '127.0.0.1', '', '');

-- ----------------------------
-- Table structure for pmw_message
-- ----------------------------
DROP TABLE IF EXISTS `pmw_message`;
CREATE TABLE `pmw_message` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '留言id',
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '1' COMMENT '站点id',
  `nickname` varchar(30) NOT NULL COMMENT '昵称',
  `contact` varchar(50) NOT NULL COMMENT '联系方式',
  `content` text NOT NULL COMMENT '留言内容',
  `htop` set('true') NOT NULL COMMENT '置顶',
  `rtop` set('true') NOT NULL COMMENT '推荐',
  `ip` char(20) NOT NULL COMMENT '留言IP',
  `recont` text NOT NULL COMMENT '回复内容',
  `retime` int(10) unsigned NOT NULL COMMENT '回复时间',
  `orderid` mediumint(8) unsigned NOT NULL COMMENT '排列排序',
  `posttime` int(10) unsigned NOT NULL COMMENT '更新时间',
  `checkinfo` enum('true','false') NOT NULL COMMENT '审核状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_message
-- ----------------------------
INSERT INTO `pmw_message` VALUES ('1', '1', '游客', 'QQ：10000', '站点很好很漂亮，超喜欢，赞！', '', 'true', '127.0.0.1', '感谢您的留言！', '1326770722', '1', '1326770722', 'true');

-- ----------------------------
-- Table structure for pmw_nav
-- ----------------------------
DROP TABLE IF EXISTS `pmw_nav`;
CREATE TABLE `pmw_nav` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '导航id',
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '1' COMMENT '站点id',
  `parentid` smallint(5) unsigned NOT NULL COMMENT '导航分类',
  `parentstr` varchar(50) NOT NULL COMMENT '导航分类父id字符串',
  `classname` varchar(30) NOT NULL COMMENT '导航名称',
  `linkurl` varchar(255) NOT NULL COMMENT '跳转链接',
  `relinkurl` varchar(255) NOT NULL COMMENT '重写地址',
  `picurl` varchar(100) NOT NULL COMMENT '导航图片',
  `target` varchar(30) NOT NULL COMMENT '打开方式',
  `orderid` smallint(5) unsigned NOT NULL COMMENT '排列排序',
  `checkinfo` enum('true','false') NOT NULL COMMENT '隐藏导航',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_nav
-- ----------------------------
INSERT INTO `pmw_nav` VALUES ('1', '1', '0', '0,', '主菜单', '#', '', '', '', '1', 'true');
INSERT INTO `pmw_nav` VALUES ('2', '1', '1', '0,1,', '首　页', 'index.php', 'index.html', '', '', '2', 'true');
INSERT INTO `pmw_nav` VALUES ('3', '1', '1', '0,1,', '解决方案', 'Solution.php', 'product-5-1.html', '', '', '3', 'true');
INSERT INTO `pmw_nav` VALUES ('4', '1', '1', '0,1,', '新闻中心', 'news.php', 'news-4-1.html', '', '', '4', 'true');
INSERT INTO `pmw_nav` VALUES ('8', '1', '1', '0,1,', '案例展示', 'case.php', 'case-8-1.html', '', '', '5', 'true');
INSERT INTO `pmw_nav` VALUES ('7', '1', '1', '0,1,', '关于我们', 'about.php', 'about-2-1.html', '', '', '6', 'true');
INSERT INTO `pmw_nav` VALUES ('9', '1', '1', '0,1,', '加入奥昇', 'join.php', 'join-1.html', '', '', '7', 'true');

-- ----------------------------
-- Table structure for pmw_paymode
-- ----------------------------
DROP TABLE IF EXISTS `pmw_paymode`;
CREATE TABLE `pmw_paymode` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '支付方式id',
  `classname` varchar(30) NOT NULL COMMENT '支付方式名称',
  `orderid` smallint(5) unsigned NOT NULL COMMENT '排列排序',
  `checkinfo` enum('true','false') NOT NULL COMMENT '审核状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_paymode
-- ----------------------------
INSERT INTO `pmw_paymode` VALUES ('1', '在线支付', '1', 'true');
INSERT INTO `pmw_paymode` VALUES ('2', '货到付款', '2', 'true');

-- ----------------------------
-- Table structure for pmw_postmode
-- ----------------------------
DROP TABLE IF EXISTS `pmw_postmode`;
CREATE TABLE `pmw_postmode` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '配送方式id',
  `classname` varchar(30) NOT NULL COMMENT '配送方式',
  `postprice` varchar(10) NOT NULL COMMENT '配送价格',
  `orderid` smallint(5) unsigned NOT NULL COMMENT '排列排序',
  `checkinfo` enum('true','false') NOT NULL COMMENT '审核状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_postmode
-- ----------------------------
INSERT INTO `pmw_postmode` VALUES ('1', '申通', '15', '1', 'true');
INSERT INTO `pmw_postmode` VALUES ('2', '中通', '15', '2', 'true');
INSERT INTO `pmw_postmode` VALUES ('3', '圆通', '15', '3', 'true');
INSERT INTO `pmw_postmode` VALUES ('4', '顺丰', '22', '4', 'true');
INSERT INTO `pmw_postmode` VALUES ('5', 'EMS', '20', '5', 'true');

-- ----------------------------
-- Table structure for pmw_site
-- ----------------------------
DROP TABLE IF EXISTS `pmw_site`;
CREATE TABLE `pmw_site` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '站点ID',
  `sitename` varchar(30) NOT NULL COMMENT '站点名称',
  `sitekey` varchar(30) NOT NULL COMMENT '站点标识',
  `sitelang` varchar(50) NOT NULL COMMENT '站点语言包',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_site
-- ----------------------------
INSERT INTO `pmw_site` VALUES ('1', '默认站点', 'zh_CN', 'zh_CN');

-- ----------------------------
-- Table structure for pmw_sysevent
-- ----------------------------
DROP TABLE IF EXISTS `pmw_sysevent`;
CREATE TABLE `pmw_sysevent` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '信息id',
  `uname` varchar(30) NOT NULL COMMENT '用户名',
  `siteid` tinyint(1) unsigned NOT NULL COMMENT '站点id',
  `model` varchar(30) NOT NULL COMMENT '操作模块',
  `classid` int(10) unsigned NOT NULL COMMENT '栏目id',
  `action` varchar(10) NOT NULL COMMENT '执行操作',
  `posttime` int(10) NOT NULL COMMENT '操作时间',
  `ip` varchar(20) NOT NULL COMMENT '操作ip',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=244 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_sysevent
-- ----------------------------
INSERT INTO `pmw_sysevent` VALUES ('1', 'admin', '1', 'login', '0', '', '1498972589', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('2', 'admin', '1', 'infoclass', '0', 'all', '1498986883', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('3', 'admin', '1', 'infolist', '0', 'all', '1498986918', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('4', 'admin', '1', 'infoclass', '0', 'all', '1498986953', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('5', 'admin', '1', 'infoclass', '0', 'all', '1498987027', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('6', 'admin', '1', 'infolist', '0', 'all', '1498987044', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('7', 'admin', '1', 'infolist', '0', 'all', '1498987229', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('8', 'admin', '1', 'infolist', '4', 'add', '1498987229', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('9', 'admin', '1', 'info', '0', 'all', '1498987254', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('10', 'admin', '1', 'infolist', '0', 'all', '1498987330', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('11', 'admin', '1', 'infolist', '4', 'add', '1498987330', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('12', 'admin', '1', 'infoclass', '0', 'all', '1498987398', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('13', 'admin', '1', 'maintype', '0', 'all', '1498987402', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('14', 'admin', '1', 'info', '0', 'all', '1498987407', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('15', 'admin', '1', 'infoimg', '0', 'all', '1498987419', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('16', 'admin', '1', 'infolist', '0', 'all', '1498987428', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('17', 'admin', '1', 'infolist', '0', 'all', '1498987661', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('18', 'admin', '1', 'infolist', '4', 'update', '1498987696', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('19', 'admin', '1', 'infolist', '0', 'all', '1498987724', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('20', 'admin', '1', 'login', '0', '', '1499068783', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('21', 'admin', '1', 'infoclass', '0', 'all', '1499068806', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('22', 'admin', '1', 'infolist', '0', 'all', '1499068828', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('23', 'admin', '1', 'infolist', '4', 'del', '1499068865', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('24', 'admin', '1', 'infoclass', '0', 'all', '1499068884', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('25', 'admin', '1', 'infoclass', '0', 'all', '1499069019', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('26', 'admin', '1', 'info', '14', 'add', '1499069019', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('27', 'admin', '1', 'infolist', '0', 'all', '1499069033', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('28', 'admin', '1', 'info', '15', 'del', '1499069067', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('29', 'admin', '1', 'maintype', '0', 'all', '1499069124', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('30', 'admin', '1', 'info', '0', 'all', '1499069129', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('31', 'admin', '1', 'infolist', '0', 'all', '1499069134', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('32', 'admin', '1', 'infoclass', '0', 'all', '1499069195', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('33', 'admin', '1', 'info', '14', 'update', '1499069207', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('34', 'admin', '1', 'infolist', '0', 'all', '1499069212', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('35', 'admin', '1', 'infolist', '14', 'add', '1499069260', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('36', 'admin', '1', 'infolist', '0', 'all', '1499069311', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('37', 'admin', '1', 'infolist', '14', 'add', '1499069364', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('38', 'admin', '1', 'infolist', '0', 'all', '1499069373', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('39', 'admin', '1', 'infolist', '14', 'update', '1499069379', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('40', 'admin', '1', 'infolist', '0', 'all', '1499070140', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('41', 'admin', '1', 'infolist', '14', 'update', '1499070148', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('42', 'admin', '1', 'infolist', '0', 'all', '1499070201', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('43', 'admin', '1', 'infoclass', '0', 'all', '1499072791', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('44', 'admin', '1', 'infolist', '0', 'all', '1499072829', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('45', 'admin', '1', 'infolist', '0', 'all', '1499072906', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('46', 'admin', '1', 'infolist', '16', 'add', '1499072906', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('47', 'admin', '1', 'infolist', '16', 'update', '1499072922', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('48', 'admin', '1', 'infolist', '0', 'all', '1499072979', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('49', 'admin', '1', 'infolist', '16', 'add', '1499072979', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('50', 'admin', '1', 'infolist', '0', 'all', '1499073040', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('51', 'admin', '1', 'infolist', '16', 'add', '1499073040', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('52', 'admin', '1', 'infolist', '16', 'update', '1499073100', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('53', 'admin', '1', 'infolist', '0', 'all', '1499073101', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('54', 'admin', '1', 'infolist', '0', 'all', '1499080415', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('55', 'admin', '1', 'web_config', '0', 'all', '1499080423', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('56', 'admin', '1', 'infolist', '0', 'all', '1499080663', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('57', 'admin', '1', 'infolist', '4', 'add', '1499080663', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('58', 'admin', '1', 'infolist', '0', 'all', '1499081105', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('59', 'admin', '1', 'infolist', '4', 'update', '1499081120', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('60', 'admin', '1', 'infolist', '0', 'all', '1499081334', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('61', 'admin', '1', 'infolist', '4', 'update', '1499081357', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('62', 'admin', '1', 'infoclass', '0', 'all', '1499081396', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('63', 'admin', '1', 'infolist', '0', 'all', '1499081397', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('64', 'admin', '1', 'infolist', '0', 'all', '1499082127', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('65', 'admin', '1', 'infolist', '4', 'add', '1499082127', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('66', 'admin', '1', 'infolist', '0', 'all', '1499083107', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('67', 'admin', '1', 'infolist', '0', 'all', '1499083742', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('68', 'admin', '1', 'infolist', '4', 'update', '1499083742', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('69', 'admin', '1', 'infolist', '4', 'add', '1499083790', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('70', 'admin', '1', 'infolist', '0', 'all', '1499083933', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('71', 'admin', '1', 'infolist', '0', 'all', '1499084413', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('72', 'admin', '1', 'infolist', '4', 'add', '1499084467', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('73', 'admin', '1', 'infolist', '0', 'all', '1499084475', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('74', 'admin', '1', 'infolist', '0', 'all', '1499084581', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('75', 'admin', '1', 'infolist', '4', 'add', '1499084581', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('76', 'admin', '1', 'infolist', '4', 'update', '1499084592', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('77', 'admin', '1', 'infolist', '0', 'all', '1499084658', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('78', 'admin', '1', 'infolist', '4', 'add', '1499084658', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('79', 'admin', '1', 'infoclass', '0', 'all', '1499086657', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('80', 'admin', '1', 'infolist', '0', 'all', '1499086670', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('81', 'admin', '1', 'infolist', '0', 'all', '1499086785', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('82', 'admin', '1', 'infolist', '14', 'add', '1499086785', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('83', 'admin', '1', 'infolist', '0', 'all', '1499086955', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('84', 'admin', '1', 'infolist', '14', 'update', '1499086995', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('85', 'admin', '1', 'infoimg', '0', 'all', '1499087205', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('86', 'admin', '1', 'infoimg', '0', 'all', '1499087279', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('87', 'admin', '1', 'infoimg', '13', 'add', '1499087279', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('88', 'admin', '1', 'infoclass', '0', 'all', '1499087578', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('89', 'admin', '1', 'maintype', '0', 'all', '1499087605', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('90', 'admin', '1', 'info', '0', 'all', '1499087608', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('91', 'admin', '1', 'infolist', '0', 'all', '1499087613', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('92', 'admin', '1', 'infolist', '14', 'update', '1499087641', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('93', 'admin', '1', 'infolist', '0', 'all', '1499088740', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('94', 'admin', '1', 'infoimg', '0', 'all', '1499088746', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('95', 'admin', '1', 'infoclass', '0', 'all', '1499089790', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('96', 'admin', '1', 'infolist', '0', 'all', '1499089822', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('97', 'admin', '1', 'infoimg', '0', 'all', '1499089869', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('98', 'admin', '1', 'infolist', '0', 'all', '1499089952', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('99', 'admin', '1', 'infolist', '17', 'add', '1499089952', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('100', 'admin', '1', 'infolist', '0', 'all', '1499090021', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('101', 'admin', '1', 'infolist', '17', 'add', '1499090021', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('102', 'admin', '1', 'infolist', '17', 'update', '1499090076', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('103', 'admin', '1', 'infolist', '0', 'all', '1499090884', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('104', 'admin', '1', 'infolist', '17', 'update', '1499090918', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('105', 'admin', '1', 'infolist', '0', 'all', '1499090952', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('106', 'admin', '1', 'infolist', '0', 'all', '1499091317', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('107', 'admin', '1', 'infolist', '0', 'all', '1499091405', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('108', 'admin', '1', 'infolist', '17', 'add', '1499091405', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('109', 'admin', '1', 'infolist', '0', 'all', '1499091510', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('110', 'admin', '1', 'infolist', '17', 'add', '1499091510', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('111', 'admin', '1', 'infoclass', '0', 'all', '1499092568', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('112', 'admin', '1', 'infolist', '0', 'all', '1499092591', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('113', 'admin', '1', 'maintype', '0', 'all', '1499092601', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('114', 'admin', '1', 'infoclass', '0', 'all', '1499092646', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('115', 'admin', '1', 'infoimg', '0', 'all', '1499092693', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('116', 'admin', '1', 'infoimg', '0', 'all', '1499092794', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('117', 'admin', '1', 'infoimg', '0', 'all', '1499092862', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('118', 'admin', '1', 'infoimg', '13', 'add', '1499092862', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('119', 'admin', '1', 'info', '0', 'all', '1499094471', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('120', 'admin', '1', 'infolist', '0', 'all', '1499094472', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('121', 'admin', '1', 'infolist', '0', 'all', '1499094544', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('122', 'admin', '1', 'infolist', '18', 'add', '1499094544', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('123', 'admin', '1', 'infolist', '0', 'all', '1499094621', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('124', 'admin', '1', 'infolist', '18', 'add', '1499094621', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('125', 'admin', '1', 'infolist', '0', 'all', '1499094684', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('126', 'admin', '1', 'infolist', '18', 'add', '1499094698', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('127', 'admin', '1', 'infolist', '0', 'all', '1499096564', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('128', 'admin', '1', 'infolist', '18', 'add', '1499096608', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('129', 'admin', '1', 'infolist', '0', 'all', '1499096806', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('130', 'admin', '1', 'infoclass', '0', 'all', '1499097505', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('131', 'admin', '1', 'infoimg', '0', 'all', '1499097753', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('132', 'admin', '1', 'infoimg', '0', 'all', '1499097836', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('133', 'admin', '1', 'infoimg', '13', 'add', '1499097836', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('134', 'admin', '1', 'infolist', '0', 'all', '1499098373', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('135', 'admin', '1', 'infoclass', '0', 'all', '1499098390', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('136', 'admin', '1', 'infoclass', '0', 'all', '1499098451', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('137', 'admin', '1', 'infolist', '0', 'all', '1499098457', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('138', 'admin', '1', 'infolist', '0', 'all', '1499098537', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('139', 'admin', '1', 'infolist', '14', 'add', '1499098537', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('140', 'admin', '1', 'infolist', '0', 'all', '1499098629', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('141', 'admin', '1', 'infolist', '14', 'add', '1499098629', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('142', 'admin', '1', 'infolist', '0', 'all', '1499099549', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('143', 'admin', '1', 'infolist', '14', 'add', '1499099577', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('144', 'admin', '1', 'infolist', '14', 'update', '1499099593', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('145', 'admin', '1', 'login', '0', '', '1499129545', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('146', 'admin', '1', 'infolist', '0', 'all', '1499129556', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('147', 'admin', '1', 'infolist', '0', 'all', '1499129626', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('148', 'admin', '1', 'infolist', '14', 'update', '1499129638', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('149', 'admin', '1', 'infolist', '0', 'all', '1499129689', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('150', 'admin', '1', 'infolist', '14', 'update', '1499129710', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('151', 'admin', '1', 'infolist', '0', 'all', '1499130252', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('152', 'admin', '1', 'infoclass', '0', 'all', '1499130261', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('153', 'admin', '1', 'infoclass', '0', 'all', '1499130379', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('154', 'admin', '1', 'infolist', '0', 'all', '1499130445', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('155', 'admin', '1', 'infolist', '0', 'all', '1499130872', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('156', 'admin', '1', 'infolist', '19', 'add', '1499130872', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('157', 'admin', '1', 'infolist', '0', 'all', '1499131015', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('158', 'admin', '1', 'infolist', '19', 'add', '1499131015', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('159', 'admin', '1', 'infolist', '0', 'all', '1499131081', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('160', 'admin', '1', 'infolist', '19', 'add', '1499131081', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('161', 'admin', '1', 'infolist', '0', 'all', '1499135789', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('162', 'admin', '1', 'infolist', '14', 'del', '1499135841', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('163', 'admin', '1', 'infolist', '0', 'all', '1499135850', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('164', 'admin', '1', 'infoimg', '0', 'all', '1499135930', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('165', 'admin', '1', 'infolist', '0', 'all', '1499135986', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('166', 'admin', '1', 'infolist', '0', 'all', '1499136075', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('167', 'admin', '1', 'infolist', '14', 'add', '1499136075', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('168', 'admin', '1', 'infolist', '0', 'all', '1499136243', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('169', 'admin', '1', 'infolist', '14', 'add', '1499136243', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('170', 'admin', '1', 'infolist', '0', 'all', '1499136355', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('171', 'admin', '1', 'infolist', '14', 'update', '1499136355', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('172', 'admin', '1', 'infolist', '0', 'all', '1499136441', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('173', 'admin', '1', 'infolist', '14', 'add', '1499136441', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('174', 'admin', '1', 'infolist', '14', 'update', '1499136475', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('175', 'admin', '1', 'infolist', '0', 'all', '1499140915', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('176', 'admin', '1', 'login', '0', '', '1499148259', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('177', 'admin', '1', 'web_config', '0', 'all', '1499148268', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('178', 'admin', '1', 'infolist', '0', 'all', '1499148274', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('179', 'admin', '1', 'infoclass', '0', 'all', '1499148279', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('180', 'admin', '1', 'infoimg', '0', 'all', '1499148531', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('181', 'admin', '1', 'infoimg', '13', 'update', '1499148551', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('182', 'admin', '1', 'infoimg', '0', 'all', '1499148767', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('183', 'admin', '1', 'infoimg', '13', 'update', '1499148773', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('184', 'admin', '1', 'infoimg', '0', 'all', '1499148980', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('185', 'admin', '1', 'infoimg', '13', 'update', '1499148987', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('186', 'admin', '1', 'infolist', '0', 'all', '1499149295', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('187', 'admin', '1', 'infolist', '0', 'all', '1499149360', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('188', 'admin', '1', 'infolist', '20', 'add', '1499149360', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('189', 'admin', '1', 'infoclass', '0', 'all', '1499149924', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('190', 'admin', '1', 'infolist', '0', 'all', '1499149957', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('191', 'admin', '1', 'infolist', '0', 'all', '1499150188', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('192', 'admin', '1', 'infolist', '21', 'add', '1499150188', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('193', 'admin', '1', 'infolist', '0', 'all', '1499150442', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('194', 'admin', '1', 'infolist', '21', 'add', '1499150442', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('195', 'admin', '1', 'infolist', '0', 'all', '1499150504', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('196', 'admin', '1', 'infolist', '21', 'add', '1499150504', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('197', 'admin', '1', 'infoclass', '0', 'all', '1499152009', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('198', 'admin', '1', 'infolist', '0', 'all', '1499152029', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('199', 'admin', '1', 'infolist', '0', 'all', '1499152111', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('200', 'admin', '1', 'infolist', '16', 'add', '1499152111', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('201', 'admin', '1', 'infolist', '0', 'all', '1499152199', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('202', 'admin', '1', 'infolist', '0', 'all', '1499152318', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('203', 'admin', '1', 'infolist', '16', 'update', '1499152318', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('204', 'admin', '1', 'infoclass', '0', 'all', '1499152602', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('205', 'admin', '1', 'infolist', '0', 'all', '1499152636', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('206', 'admin', '1', 'infolist', '22', 'add', '1499152696', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('207', 'admin', '1', 'infolist', '0', 'all', '1499152697', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('208', 'admin', '1', 'infolist', '0', 'all', '1499153781', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('209', 'admin', '1', 'infolist', '0', 'all', '1499153902', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('210', 'admin', '1', 'infolist', '22', 'add', '1499153902', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('211', 'admin', '1', 'infoclass', '0', 'all', '1499155021', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('212', 'admin', '1', 'infolist', '0', 'all', '1499155070', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('213', 'admin', '1', 'infoclass', '0', 'all', '1499155096', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('214', 'admin', '1', 'infolist', '0', 'all', '1499155207', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('215', 'admin', '1', 'infolist', '23', 'add', '1499155207', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('216', 'admin', '1', 'infolist', '0', 'all', '1499155681', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('217', 'admin', '1', 'infolist', '0', 'all', '1499156010', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('218', 'admin', '1', 'infolist', '0', 'all', '1499156132', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('219', 'admin', '1', 'infolist', '0', 'all', '1499156242', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('220', 'admin', '1', 'infolist', '23', 'add', '1499156242', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('221', 'admin', '1', 'infolist', '23', 'update', '1499156257', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('222', 'admin', '1', 'infolist', '0', 'all', '1499156309', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('223', 'admin', '1', 'infolist', '23', 'add', '1499156309', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('224', 'admin', '1', 'infolist', '0', 'all', '1499156395', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('225', 'admin', '1', 'infolist', '23', 'add', '1499156395', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('226', 'admin', '1', 'infolist', '0', 'all', '1499156550', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('227', 'admin', '1', 'infolist', '23', 'add', '1499156550', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('228', 'admin', '1', 'infolist', '0', 'all', '1499157502', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('229', 'admin', '1', 'infoclass', '0', 'all', '1499157504', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('230', 'admin', '1', 'infolist', '0', 'all', '1499158212', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('231', 'admin', '1', 'infolist', '0', 'all', '1499158313', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('232', 'admin', '1', 'infolist', '24', 'add', '1499158313', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('233', 'admin', '1', 'infolist', '0', 'all', '1499158790', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('234', 'admin', '1', 'infolist', '0', 'all', '1499158882', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('235', 'admin', '1', 'infolist', '24', 'add', '1499158882', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('236', 'admin', '1', 'infolist', '0', 'all', '1499160391', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('237', 'admin', '1', 'infoclass', '0', 'all', '1499160406', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('238', 'admin', '1', 'infoclass', '0', 'all', '1499161162', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('239', 'admin', '1', 'infolist', '25', 'del', '1499161162', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('240', 'admin', '1', 'infoclass', '0', 'all', '1499163603', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('241', 'admin', '1', 'infolist', '0', 'all', '1499163637', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('242', 'admin', '1', 'infolist', '0', 'all', '1499163706', '0.0.0.0');
INSERT INTO `pmw_sysevent` VALUES ('243', 'admin', '1', 'infolist', '26', 'add', '1499163706', '0.0.0.0');

-- ----------------------------
-- Table structure for pmw_uploads
-- ----------------------------
DROP TABLE IF EXISTS `pmw_uploads`;
CREATE TABLE `pmw_uploads` (
  `id` mediumint(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '上传信息id',
  `name` varchar(30) NOT NULL COMMENT '文件名称',
  `path` varchar(100) NOT NULL COMMENT '文件路径',
  `size` int(10) NOT NULL COMMENT '文件大小',
  `type` enum('image','soft','media') NOT NULL COMMENT '文件类型',
  `posttime` int(10) NOT NULL COMMENT '上传日期',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_uploads
-- ----------------------------
INSERT INTO `pmw_uploads` VALUES ('1', '1498994447.jpg', 'uploads/image/20170702/1498994447.jpg', '44236', 'image', '1498987183');
INSERT INTO `pmw_uploads` VALUES ('2', '1498994664.jpg', 'uploads/image/20170702/1498994664.jpg', '35213', 'image', '1498987325');
INSERT INTO `pmw_uploads` VALUES ('3', '1498995818.jpg', 'uploads/image/20170702/1498995818.jpg', '56732', 'image', '1498987360');
INSERT INTO `pmw_uploads` VALUES ('4', '1499075389.jpg', 'uploads/image/20170703/1499075389.jpg', '44236', 'image', '1499069008');
INSERT INTO `pmw_uploads` VALUES ('5', '1499078872.jpg', 'uploads/image/20170703/1499078872.jpg', '44236', 'image', '1499069239');
INSERT INTO `pmw_uploads` VALUES ('6', '1499074524.jpg', 'uploads/image/20170703/1499074524.jpg', '35213', 'image', '1499069301');
INSERT INTO `pmw_uploads` VALUES ('7', '1499073099.jpg', 'uploads/image/20170703/1499073099.jpg', '56732', 'image', '1499069357');
INSERT INTO `pmw_uploads` VALUES ('8', '1499073473.png', 'uploads/image/20170703/1499073473.png', '32149', 'image', '1499072896');
INSERT INTO `pmw_uploads` VALUES ('9', '1499074532.png', 'uploads/image/20170703/1499074532.png', '31978', 'image', '1499072962');
INSERT INTO `pmw_uploads` VALUES ('11', '1499080433.png', 'uploads/image/20170703/1499080433.png', '31634', 'image', '1499073031');
INSERT INTO `pmw_uploads` VALUES ('12', '1499077572.png', 'uploads/image/20170703/1499077572.png', '32365', 'image', '1499073076');
INSERT INTO `pmw_uploads` VALUES ('13', '1499086828.png', 'uploads/image/20170703/1499086828.png', '140084', 'image', '1499080605');
INSERT INTO `pmw_uploads` VALUES ('14', '1499087659.jpg', 'uploads/image/20170703/1499087659.jpg', '61950', 'image', '1499086759');
INSERT INTO `pmw_uploads` VALUES ('15', '1499092139.jpg', 'uploads/image/20170703/1499092139.jpg', '61950', 'image', '1499086987');
INSERT INTO `pmw_uploads` VALUES ('16', '1499091799.jpg', 'uploads/image/20170703/1499091799.jpg', '61950', 'image', '1499087253');
INSERT INTO `pmw_uploads` VALUES ('17', '1499090401.jpg', 'uploads/image/20170703/1499090401.jpg', '44236', 'image', '1499089914');
INSERT INTO `pmw_uploads` VALUES ('18', '1499094112.jpg', 'uploads/image/20170703/1499094112.jpg', '28437', 'image', '1499090011');
INSERT INTO `pmw_uploads` VALUES ('19', '1499098642.jpg', 'uploads/image/20170703/1499098642.jpg', '33284', 'image', '1499090059');
INSERT INTO `pmw_uploads` VALUES ('20', '1499091715.png', 'uploads/image/20170703/1499091715.png', '811279', 'image', '1499091392');
INSERT INTO `pmw_uploads` VALUES ('21', '1499095329.jpg', 'uploads/image/20170703/1499095329.jpg', '28838', 'image', '1499091435');
INSERT INTO `pmw_uploads` VALUES ('22', '1499092099.jpg', 'uploads/image/20170703/1499092099.jpg', '56732', 'image', '1499091503');
INSERT INTO `pmw_uploads` VALUES ('23', '1499094291.jpg', 'uploads/image/20170703/1499094291.jpg', '51427', 'image', '1499092846');
INSERT INTO `pmw_uploads` VALUES ('24', '1499103002.jpg', 'uploads/image/20170704/1499103002.jpg', '42553', 'image', '1499097823');
INSERT INTO `pmw_uploads` VALUES ('25', '1499100269.jpg', 'uploads/image/20170704/1499100269.jpg', '44236', 'image', '1499098527');
INSERT INTO `pmw_uploads` VALUES ('26', '1499099221.jpg', 'uploads/image/20170704/1499099221.jpg', '35213', 'image', '1499098583');
INSERT INTO `pmw_uploads` VALUES ('27', '1499105595.jpg', 'uploads/image/20170704/1499105595.jpg', '56732', 'image', '1499098622');
INSERT INTO `pmw_uploads` VALUES ('28', '1499100681.jpg', 'uploads/image/20170704/1499100681.jpg', '44236', 'image', '1499099570');
INSERT INTO `pmw_uploads` VALUES ('29', '1499141634.jpg', 'uploads/image/20170704/1499141634.jpg', '44236', 'image', '1499136070');
INSERT INTO `pmw_uploads` VALUES ('30', '1499137675.jpg', 'uploads/image/20170704/1499137675.jpg', '35213', 'image', '1499136185');
INSERT INTO `pmw_uploads` VALUES ('31', '1499146122.jpg', 'uploads/image/20170704/1499146122.jpg', '56732', 'image', '1499136399');
INSERT INTO `pmw_uploads` VALUES ('32', '1499150243.jpg', 'uploads/image/20170704/1499150243.jpg', '78164', 'image', '1499149351');
INSERT INTO `pmw_uploads` VALUES ('33', '1499159160.png', 'uploads/image/20170704/1499159160.png', '140084', 'image', '1499150182');
INSERT INTO `pmw_uploads` VALUES ('34', '1499153188.png', 'uploads/image/20170704/1499153188.png', '209327', 'image', '1499150410');
INSERT INTO `pmw_uploads` VALUES ('35', '1499158460.png', 'uploads/image/20170704/1499158460.png', '161769', 'image', '1499150483');
INSERT INTO `pmw_uploads` VALUES ('36', '1499161818.jpg', 'uploads/image/20170704/1499161818.jpg', '48374', 'image', '1499152675');
INSERT INTO `pmw_uploads` VALUES ('37', '1499158325.jpg', 'uploads/image/20170704/1499158325.jpg', '51427', 'image', '1499158274');
INSERT INTO `pmw_uploads` VALUES ('38', '1499166235.jpg', 'uploads/image/20170704/1499166235.jpg', '113303', 'image', '1499158838');
INSERT INTO `pmw_uploads` VALUES ('39', '1499172236.jpg', 'uploads/image/20170704/1499172236.jpg', '27439', 'image', '1499163698');

-- ----------------------------
-- Table structure for pmw_usercomment
-- ----------------------------
DROP TABLE IF EXISTS `pmw_usercomment`;
CREATE TABLE `pmw_usercomment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '评论id',
  `aid` int(10) unsigned NOT NULL COMMENT '信息id',
  `molds` tinyint(1) unsigned NOT NULL COMMENT '信息类型',
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `uname` varchar(20) NOT NULL COMMENT '用户名',
  `body` text NOT NULL COMMENT '评论内容',
  `reply` text NOT NULL COMMENT '回复内容',
  `link` varchar(200) NOT NULL COMMENT '评论网址',
  `time` int(10) unsigned NOT NULL COMMENT '评论时间',
  `ip` varchar(30) NOT NULL COMMENT '评论ip',
  `isshow` tinyint(1) unsigned NOT NULL COMMENT '是否显示',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_usercomment
-- ----------------------------

-- ----------------------------
-- Table structure for pmw_userfavorite
-- ----------------------------
DROP TABLE IF EXISTS `pmw_userfavorite`;
CREATE TABLE `pmw_userfavorite` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '收藏id',
  `aid` int(10) unsigned NOT NULL COMMENT '信息id',
  `molds` tinyint(1) unsigned NOT NULL COMMENT '信息类型',
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `uname` varchar(20) NOT NULL COMMENT '用户名',
  `link` varchar(200) NOT NULL COMMENT '收藏网址',
  `time` int(10) unsigned NOT NULL COMMENT '评论时间',
  `ip` varchar(30) NOT NULL COMMENT '评论ip',
  `isshow` tinyint(1) unsigned NOT NULL COMMENT '是否显示',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_userfavorite
-- ----------------------------

-- ----------------------------
-- Table structure for pmw_usergroup
-- ----------------------------
DROP TABLE IF EXISTS `pmw_usergroup`;
CREATE TABLE `pmw_usergroup` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户组id',
  `groupname` varchar(30) NOT NULL COMMENT '用户组名称',
  `expvala` int(11) NOT NULL COMMENT '用户组经验介于a',
  `expvalb` int(11) NOT NULL COMMENT '用户组经验介于b',
  `stars` int(10) unsigned NOT NULL COMMENT '星星数',
  `color` varchar(10) NOT NULL COMMENT '头衔颜色',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_usergroup
-- ----------------------------
INSERT INTO `pmw_usergroup` VALUES ('1', '禁止访问', '-99999', '0', '0', '');
INSERT INTO `pmw_usergroup` VALUES ('2', '新手会员', '1', '50', '1', '');
INSERT INTO `pmw_usergroup` VALUES ('3', '初级会员', '51', '200', '4', '');
INSERT INTO `pmw_usergroup` VALUES ('4', '中级会员', '201', '500', '8', '');
INSERT INTO `pmw_usergroup` VALUES ('5', '高级会员', '501', '1000', '12', '');
INSERT INTO `pmw_usergroup` VALUES ('6', '金牌会员', '1001', '3000', '16', '');

-- ----------------------------
-- Table structure for pmw_vote
-- ----------------------------
DROP TABLE IF EXISTS `pmw_vote`;
CREATE TABLE `pmw_vote` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '投票id',
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '1' COMMENT '站点id',
  `title` varchar(30) NOT NULL COMMENT '投票标题',
  `content` text NOT NULL COMMENT '投票描述',
  `starttime` int(10) unsigned NOT NULL COMMENT '开始时间',
  `endtime` int(10) unsigned NOT NULL COMMENT '结束时间',
  `isguest` enum('true','false') NOT NULL COMMENT '游客投票',
  `isview` enum('true','false') NOT NULL COMMENT '查看投票',
  `intval` int(10) unsigned NOT NULL COMMENT '投票间隔',
  `isradio` tinyint(1) unsigned NOT NULL COMMENT '是否多选',
  `orderid` smallint(5) unsigned NOT NULL COMMENT '排列排序',
  `posttime` int(10) unsigned NOT NULL COMMENT '更新时间',
  `checkinfo` enum('true','false') NOT NULL COMMENT '审核状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_vote
-- ----------------------------
INSERT INTO `pmw_vote` VALUES ('1', '1', '您是从哪得知本站的？', '茫茫网海，您的来访让我们深感高兴。', '0', '0', 'true', 'true', '60', '2', '1', '1326863548', 'true');

-- ----------------------------
-- Table structure for pmw_votedata
-- ----------------------------
DROP TABLE IF EXISTS `pmw_votedata`;
CREATE TABLE `pmw_votedata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '投票数据id',
  `voteid` smallint(6) unsigned NOT NULL COMMENT '投票id',
  `optionid` text NOT NULL COMMENT '选票id',
  `userid` int(10) unsigned NOT NULL COMMENT '投票人id',
  `posttime` int(10) unsigned NOT NULL COMMENT '投票时间',
  `ip` varchar(30) NOT NULL COMMENT '投票ip',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_votedata
-- ----------------------------

-- ----------------------------
-- Table structure for pmw_voteoption
-- ----------------------------
DROP TABLE IF EXISTS `pmw_voteoption`;
CREATE TABLE `pmw_voteoption` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '投票选项id',
  `voteid` smallint(6) unsigned NOT NULL COMMENT '投票id',
  `options` varchar(30) NOT NULL COMMENT '投票选项',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_voteoption
-- ----------------------------
INSERT INTO `pmw_voteoption` VALUES ('1', '1', '友情链接');
INSERT INTO `pmw_voteoption` VALUES ('2', '1', '搜索引擎');
INSERT INTO `pmw_voteoption` VALUES ('3', '1', '朋友介绍');
INSERT INTO `pmw_voteoption` VALUES ('4', '1', '其他');

-- ----------------------------
-- Table structure for pmw_webconfig
-- ----------------------------
DROP TABLE IF EXISTS `pmw_webconfig`;
CREATE TABLE `pmw_webconfig` (
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '1' COMMENT '站点id',
  `varname` varchar(50) NOT NULL COMMENT '变量名称',
  `varinfo` varchar(80) NOT NULL COMMENT '参数说明',
  `vargroup` smallint(5) unsigned NOT NULL COMMENT '所属组',
  `vartype` char(10) NOT NULL COMMENT '变量类型',
  `varvalue` text NOT NULL COMMENT '变量值',
  `orderid` smallint(5) unsigned NOT NULL COMMENT '排列排序',
  PRIMARY KEY (`varname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_webconfig
-- ----------------------------
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_webname', '网站名称', '0', 'string', '我的网站', '1');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_weburl', '网站地址', '0', 'string', 'http://localhost', '2');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_webpath', '网站目录', '0', 'string', '/phpMyWind', '3');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_author', '网站作者', '0', 'string', '', '4');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_generator', '程序引擎', '0', 'string', 'PHPMyWind CMS', '5');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_seotitle', 'SEO标题', '0', 'string', '', '6');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_keyword', '关键字设置', '0', 'string', '', '7');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_description', '网站描述', '0', 'bstring', '', '8');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_copyright', '版权信息', '0', 'bstring', 'Copyright © 2010 - 2017 phpMyWind.com All Rights Reserved', '9');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_hotline', '客服热线', '0', 'string', '400-800-8888', '10');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_icp', '备案编号', '0', 'string', '', '11');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_webswitch', '启用站点', '0', 'bool', 'Y', '12');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_switchshow', '关闭说明', '0', 'bstring', '对不起，网站维护，请稍后登录。<br />网站维护期间对您造成的不便，请谅解！', '13');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_upload_img_type', '上传图片类型', '1', 'string', 'gif|png|jpg|bmp', '23');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_upload_soft_type', '上传软件类型', '1', 'string', 'zip|gz|rar|iso|doc|xls|ppt|wps|txt', '24');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_upload_media_type', '上传媒体类型', '1', 'string', 'swf|flv|mpg|mp3|rm|rmvb|wmv|wma|wav', '25');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_max_file_size', '上传文件大小', '1', 'string', '2097152', '26');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_imgresize', '自动缩略图方式　<br />(是\"裁切\",否\"填充\")', '1', 'bool', 'Y', '27');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_countcode', '流量统计代码', '1', 'bstring', '', '28');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_qqcode', '在线QQ　<br />(多个用\",\"分隔)', '1', 'bstring', '', '29');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_mysql_type', '数据库类型(支持mysql和mysqli)', '2', 'string', 'mysqli', '40');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_pagenum', '每页显示记录数', '2', 'string', '20', '41');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_timezone', '服务器时区设置', '2', 'string', '8', '42');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_mobile', '自动跳转手机版', '2', 'bool', 'Y', '43');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_member', '开启会员功能', '2', 'bool', 'Y', '44');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_oauth', '开启一键登录', '2', 'bool', 'Y', '45');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_comment', '开启文章评论', '2', 'bool', 'Y', '46');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_maintype', '开启二级类别', '2', 'bool', 'N', '47');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_typefold', '类别默认折叠', '2', 'bool', 'N', '48');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_quicktool', '管理页工具条', '2', 'bool', 'Y', '49');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_diserror', 'PHP错误显示', '2', 'bool', 'Y', '50');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_isreurl', '是否启用伪静态', '3', 'bool', 'N', '60');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_reurl_index', '首页规则', '3', 'string', 'index.html', '61');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_reurl_about', '关于我们页', '3', 'string', '{about}-{cid}-{page}.html', '62');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_reurl_news', '新闻中心页', '3', 'string', '{news}-{cid}-{page}.html', '63');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_reurl_newsshow', '新闻内容页', '3', 'string', '{newsshow}-{cid}-{id}-{page}.html', '64');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_reurl_product', '产品展示页', '3', 'string', '{product}-{cid}-{page}.html', '65');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_reurl_productshow', '产品内容页', '3', 'string', '{productshow}-{cid}-{id}-{page}.html', '66');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_reurl_case', '案例展示页', '3', 'string', '{case}-{cid}-{page}.html', '67');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_reurl_caseshow', '案例内容页', '3', 'string', '{caseshow}-{cid}-{id}-{page}.html', '68');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_reurl_join', '人才招聘页', '3', 'string', '{join}-{page}.html', '69');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_reurl_joinshow', '招聘内容页', '3', 'string', '{joinshow}-{id}.html', '70');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_reurl_message', '客户留言页', '3', 'string', '{message}-{page}.html', '71');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_reurl_contact', '联系我们页', '3', 'string', '{contact}-{cid}-{page}.html', '72');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_reurl_soft', '软件下载页', '3', 'string', '{soft}-{cid}-{page}.html', '73');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_reurl_softshow', '软件内容页', '3', 'string', '{softshow}-{cid}-{id}-{page}.html', '74');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_reurl_goods', '商品展示页', '3', 'string', '{goods}-{cid}-{tid}-{page}.html', '75');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_reurl_goodsshow', '商品内容页', '3', 'string', '{goodsshow}-{cid}-{tid}-{id}-{page}.html', '76');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_reurl_vote', '投票内容页', '3', 'string', '{vote}-{id}.html', '77');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_reurl_custom', '自定义规则', '3', 'string', '{file}.html', '78');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_auth_key', '网站标识码', '4', 'string', 'gvOtRyL3RiSloDRx', '90');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_alipay_uname', '支付宝帐户', '4', 'string', '', '91');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_alipay_partner', '支付宝合作身份者ID', '4', 'string', '', '92');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_alipay_key', '支付宝安全检验码', '4', 'string', '', '93');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_qq_appid', 'QQ登录组件AppID', '4', 'string', '', '94');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_qq_appkey', 'QQ登录组件AppKey', '4', 'string', '', '95');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_weibo_appid', '微博登录组件AppID', '4', 'string', '', '96');
INSERT INTO `pmw_webconfig` VALUES ('1', 'cfg_weibo_appkey', '微博登录组件AppKey', '4', 'string', '', '97');

-- ----------------------------
-- Table structure for pmw_weblink
-- ----------------------------
DROP TABLE IF EXISTS `pmw_weblink`;
CREATE TABLE `pmw_weblink` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '友情链接id',
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '1' COMMENT '站点id',
  `classid` smallint(5) unsigned NOT NULL COMMENT '所属类别id',
  `parentid` smallint(5) unsigned NOT NULL COMMENT '所属类别父id',
  `parentstr` varchar(80) NOT NULL COMMENT '所属类别父id字符串',
  `webname` varchar(30) NOT NULL COMMENT '网站名称',
  `webnote` varchar(200) NOT NULL COMMENT '网站描述',
  `picurl` varchar(100) NOT NULL COMMENT '缩略图片',
  `linkurl` varchar(255) NOT NULL COMMENT '跳转链接',
  `orderid` smallint(5) unsigned NOT NULL COMMENT '排列排序',
  `posttime` int(10) unsigned NOT NULL COMMENT '更新时间',
  `checkinfo` enum('true','false') NOT NULL COMMENT '审核状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_weblink
-- ----------------------------
INSERT INTO `pmw_weblink` VALUES ('1', '1', '1', '0', '0,', '腾讯', '生活精彩，在线更精彩', 'http://mat1.gtimg.com/www/iskin960/qqcomlogo.png', 'http://www.qq.com/', '1', '1326770776', 'true');
INSERT INTO `pmw_weblink` VALUES ('2', '1', '1', '0', '0,', '百度', '百度一下，你就知道', 'http://www.baidu.com/img/baidu_sylogo1.gif', 'http://www.baidu.com/', '2', '1326770790', 'true');
INSERT INTO `pmw_weblink` VALUES ('3', '1', '1', '0', '0,', 'phpMyWind', '我们追求速度与舒适度', '', 'http://phpmywind.com/', '3', '1326770806', 'true');

-- ----------------------------
-- Table structure for pmw_weblinktype
-- ----------------------------
DROP TABLE IF EXISTS `pmw_weblinktype`;
CREATE TABLE `pmw_weblinktype` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '友情链接类型id',
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '1' COMMENT '站点id',
  `parentid` smallint(5) unsigned NOT NULL COMMENT '类别父id',
  `parentstr` varchar(50) NOT NULL COMMENT '类别父id字符串',
  `classname` varchar(30) NOT NULL COMMENT '类别名称',
  `orderid` smallint(5) unsigned NOT NULL COMMENT '排列顺序',
  `checkinfo` enum('true','false') NOT NULL COMMENT '审核状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pmw_weblinktype
-- ----------------------------
INSERT INTO `pmw_weblinktype` VALUES ('1', '1', '0', '0,', '默认分类', '1', 'true');
