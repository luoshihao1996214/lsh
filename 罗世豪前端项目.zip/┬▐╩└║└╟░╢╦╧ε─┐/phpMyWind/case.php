<?php
require_once(dirname(__FILE__).'/include/config.inc.php');

//初始化参数检测正确性
$cid = empty($cid) ? 8 : intval($cid);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php echo GetHeader(1,$cid); ?>
<link rel="stylesheet" type="text/css" href="css/case.css">
<link rel="stylesheet"  href="css/bootstrap.min.css"/>
<script src="js/jquery.min.js"/></script>
<script src="js/bootstrap.min.js"/></script>
<link href="templates/default/style/webstyle.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="templates/default/js/jquery.min.js"></script>
<script type="text/javascript" src="templates/default/js/loadimage.js"></script>
<script type="text/javascript" src="templates/default/js/top.js"></script>
<script type="text/javascript">
$(function(){
    $(".caselist a.img img").LoadImage({width:100,height:80});
});
</script>
</head>
<body>
<div class="body">
<!-- header-->
<?php require_once('header.php'); ?>
<!-- /header-->
<!-- 案列展示图片 -->
<div class="myImg">
			<?php
			$dosql->Execute("SELECT * FROM `#@__infoimg` WHERE classid=13 AND flag LIKE '%h%' AND delstate='' AND checkinfo=true ORDER BY orderid DESC LIMIT 0,1");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl'] != '')$gourl = $row['linkurl'];
				else $gourl = 'javascript:;';
			?>
            <img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>"  width="900px" height="150px">
        <?php
			}
			?>
</div>
<!-- /案列展示图片 -->
	<div class="center">
	<p class="aMan"><a href="case.html">案例展示</a></p>
	<p class="seat">您当前所在的位置：<a href="index.html"><?php echo GetPosStr($cid); ?></a> ></p>
	</div>
<!-- /mainbody-->
<!-- 案列展示水平线 -->
<div class="hr"></div>
<div class="abouts">案例展示</div>
<div class="Hr"></div>
<!-- 案列展示图片排版 -->

<div class="my-study">
	<div class="row">
	    	<?php $dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=17 AND flag LIKE '%a%' AND delstate='' AND checkinfo=true ORDER BY orderid ASC LIMIT 0,3");
				while($row = $dosql->GetArray())
				{
					//获取链接地址
					if($row['linkurl']=='' and $cfg_isreurl!='Y')
						$gourl = 'newsshow.php?cid='.$row['classid'].'&id='.$row['id'];
					else if($cfg_isreurl=='Y')
						$gourl = 'newsshow-'.$row['classid'].'-'.$row['id'].'-1.html';
					else
						$gourl = $row['linkurl'];
				?>
		<div class="picture">
	        <div class="col-md-4">
	        <div class="ss-myImg1">
			      <a href="detailsNav.html"><img src="<?php echo $row['picurl']; ?>" class="img-circle" width="280px" height="150px"></a>
			         <p><a href="<?php echo $gourl ?> "><?php echo $row['title']; ?></a></p>
	        </div>
	        </div>
	      </div>
	      <?php
			}
			?>
 
</div>
</div>
<div class="my-study1">
	<div class="row">
	    	<?php $dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=17 AND flag LIKE '%a%' AND delstate='' AND checkinfo=true ORDER BY orderid ASC LIMIT 3,3");
				while($row = $dosql->GetArray())
				{
					//获取链接地址
					if($row['linkurl']=='' and $cfg_isreurl!='Y')
						$gourl = 'newsshow.php?cid='.$row['classid'].'&id='.$row['id'];
					else if($cfg_isreurl=='Y')
						$gourl = 'newsshow-'.$row['classid'].'-'.$row['id'].'-1.html';
					else
						$gourl = $row['linkurl'];
				?>
		<div class="picture-my-img">
	        <div class="col-md-4">
	        <div class="my-myImg1">
			      <a href="detailsNav.html"><img src="<?php echo $row['picurl']; ?>" class="img-circle" width="280px" height="150px"></a>
		<p><a href="detailsNav.html"><?php echo $row['title']; ?></a></p>
	        </div>
	        </div>
	      </div>
	      <?php
			}
			?>
  </div>
</div>
</div>
	</div>
<!-- footer-->
<?php require_once('footer.php'); ?>
<!-- /footer-->
</div>
</body>
</html>