<?php
require_once(dirname(__FILE__).'/include/config.inc.php');

//初始化参数检测正确性
$cid = empty($cid) ? 22 : intval($cid);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php echo GetHeader(1,$cid); ?>
	<link rel="stylesheet" type="text/css" href="css/aboutUs-honnor.css">
	<link rel="stylesheet"  href="css/bootstrap.min.css"/>
	<script src="js/jquery.min.js"/></script>
	<script src="js/bootstrap.min.js"/></script>
<link rel="stylesheet" type="text/css" href="css/about.css">
<link rel="stylesheet"  href="css/bootstrap.min.css"/>
<script src="js/jquery.min.js"/></script>
<script src="js/bootstrap.min.js"/></script>
<link href="templates/default/style/webstyle.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="templates/default/js/jquery.min.js"></script>
<script type="text/javascript" src="templates/default/js/top.js"></script>
</head>
<body>
<div class="body">
<!-- header-->
<?php require_once('header.php'); ?>
<!-- /header-->

<!-- 荣誉资质图片调整 -->
	<div class="myImg">
		    <?php
			$dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=24 AND flag LIKE '%a%' AND delstate='' AND checkinfo=true ORDER BY orderid DESC LIMIT 0,1");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl'] != '')$gourl = $row['linkurl'];
				else $gourl = 'javascript:;';
			?>
            <img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>"  width="900px" height="150px">
        <?php
			}
			?>
		</div>
<!-- /荣誉资质图片调整 -->
<!-- 荣誉资质 -->
<div class="center">
		<p class="aMan"><a href="#">荣誉资质</a></p>
		<p class="seat">您当前所在的位置：<a href="index.php">首页</a> > 关于我们 > 荣誉资质</p>
</div>
			<div class="hr"></div>
			<div class="abouts">关于我们</div>
			<div class="Hr"></div>


<div class="fonts">
<div class="container">
	<div class="row">
      	  	<div class="col-lg-3 col-md-3 col-xs-3">
	  	       <div class="about-img">
	  	       <a href="">关于我们/About Us</a>
			    </div> 
			 <div class="img-about">
	  	     <ul>
				<li><a href="">公司简介</a></li>
				<li><a href="aboutUs-honnor.php">荣誉资质</a></li>
				<li><a href="">企业文化</a></li>
				<li><a href="">董事长致辞</a></li>
				<li><a href="">公司风采</a></li>
				<li><a href="">合作伙伴</a></li>
				<li><a href="">公司地址</a></li>
			</ul>
			    </div> 
		    </div>
		     <?php $dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=24 AND flag LIKE '%h%' AND delstate='' AND checkinfo=true ORDER BY orderid ASC LIMIT 0,1");
				while($row = $dosql->GetArray())
				{
				?>
            <div class="col-lg-9 col-md-9 col-xs-9">
	  	      <div class="my-font-style">
              <img src="images/honor.jpg" width="600px" height="350px" alt="" class="my-style-img">
			   </div> 
		    </div>  
		            <?php
			}
			?>    
	</div>
</div>

</div>


<!-- 奥昇所获荣誉资质 -->
<div class="honors">
<p align="center">奥昇所获荣誉资质</p>
</div>

     <div class="myUl">
					<ul>
						<li><a href="#">奥昇 智慧教育-三通两平台主站系统</a></li>
						<li><a href="#">网络学习空间人人通</a></li>
						<li><a href="#">智慧教育-家校互联网软件(APP-Andriod)</a></li>
						<li><a href="#">智慧教育-家校互联网软件(APP-IOS)</a></li>
						<li><a href="#">智慧教育-教育资源中心系统</a></li>
						<li><a href="#">智慧教育-授课软件</a></li>
						<li><a href="#">智慧教育-数学校园管理系统</a></li>
						<li><a href="#">智慧教育-同步助手软件(APP-Andriod)</a></li>
						<li><a href="#">智慧演示系统</a></li>
					</ul>
		</div>
</div>
</div>

<!-- footer-->
<?php require_once('footer.php'); ?>
<!-- /footer-->
</body>
</html>