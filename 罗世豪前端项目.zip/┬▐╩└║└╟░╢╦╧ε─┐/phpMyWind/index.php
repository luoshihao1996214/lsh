<?php require_once(dirname(__FILE__).'/include/config.inc.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php echo GetHeader(); ?>
	<link rel="stylesheet" type="text/css" href="css/index1.css">
    <link rel="stylesheet"  href="css/bootstrap.min.css"/>
	<script src="js/jquery.min.js"/></script>
	<script src="js/bootstrap.min.js"/></script>
<link href="templates/default/style/webstyle.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="templates/default/js/jquery.min.js"></script>
<script type="text/javascript" src="templates/default/js/slideplay.js"></script>
<script type="text/javascript" src="templates/default/js/srcollimg.js"></script>
<script type="text/javascript" src="templates/default/js/loadimage.js"></script>
<script type="text/javascript" src="templates/default/js/top.js"></script>
<script type="text/javascript">
$(function(){
    $(".imgwrap li img").LoadImage({width:60,height:45});
	$(".newsfocus div img").LoadImage({width:60,height:60});
});
</script>
</head>
<body>
<!-- header-->
<?php require_once('header.php'); ?>
<!-- /header-->
<!-- banner-->
<div id="myCarousel" class="carousel slide">
	<!-- 轮播（Carousel）指标 -->

	<ol class="carousel-indicators">
		<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
		<li data-target="#myCarousel" data-slide-to="1"></li>
		<li data-target="#myCarousel" data-slide-to="2"></li>
	</ol>   

	<!-- 轮播（Carousel）项目 -->
	<div class="carousel-inner">
				<div class="item active">
					<img src="images/01.jpg" width="100%" height="300px" alt="First slide">
				</div>
				<div class="item">
					<img src="images/02.jpg" width="100%" height="300px" alt="Second slide">
				</div>
				<div class="item">
					<img src="images/03.jpg" width="100%" height="300px" alt="Third slide">
				</div>
	</div>
	<!-- 轮播（Carousel）导航 -->

	<a class="carousel-control left" href="#myCarousel" 
	   data-slide="prev"><img src="images/left-arrow.png" alt=""> </a>
	<a class="carousel-control right" href="#myCarousel" 
	   data-slide="next"><img src="images/right-arrow.png" alt=""></a> 
</div>
<!-- 解决方案 -->
<div class="solve">
	    <p align="center" class="solve"><a href="Solution.php">解决方案/NEWS More</a></p>
	</div>
<div class="Hr"></div>
	<!-- 湖南奥昇信息网+监督 项目介绍 -->
	<!-- 使用网格布局图片 -->
<div class="container-ss">
	    <div class="row">
	
	    	<?php $dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=14 AND flag LIKE '%a%' AND delstate='' AND checkinfo=true ORDER BY orderid ASC LIMIT 0,3");
				while($row = $dosql->GetArray())
				{
					//获取链接地址
					if($row['linkurl']=='' and $cfg_isreurl!='Y')
						$gourl = 'newsshow.php?cid='.$row['classid'].'&id='.$row['id'];
					else if($cfg_isreurl=='Y')
						$gourl = 'newsshow-'.$row['classid'].'-'.$row['id'].'-1.html';
					else
						$gourl = $row['linkurl'];
				?>
		
	        <div class="col-md-4" id="myImg1">
	        <div class="my-case-new">
	     <img src="<?php echo $row['picurl']; ?>">
	       <p><a href="<?php echo $gourl ?> "><?php echo $row['title']; ?></a></p>
	      </div>
	      </div>
	      <?php
			}
			?>
    </div>
  </div>
</div>
  <!-- 关于我们/NEWS More -->  
	<div class="my-about">
		 <p class="my-about" align="center"><a href="about.php">关于我们/NEWS More</a></p>
	</div>
		<div class="Hr"></div>
 <!-- 关于我们/NEWS More -->  

	<div class="company">
	<?php $dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=16 AND flag LIKE '%a%' AND delstate='' AND checkinfo=true ORDER BY orderid ASC LIMIT 0,4");
	while($row = $dosql->GetArray())
	{
					//获取链接地址
					if($row['linkurl']=='' and $cfg_isreurl!='Y')
						$gourl = 'newsshow.php?cid='.$row['classid'].'&id='.$row['id'];
					else if($cfg_isreurl=='Y')
						$gourl = 'newsshow-'.$row['classid'].'-'.$row['id'].'-1.html';
					else
						$gourl = $row['linkurl'];
	?>
         <div class="my-conpany">
		       <img src="<?php echo $row['picurl']; ?>" >
		       <p><a href="aboutUs-honnor.php"> <?php echo $row['title']; ?></a></p>
          </div>
	      <?php
			}
			?>
</div>
<!-- 新闻资讯/NEWS More -->
	<div class="my-new">
	    <p  class="my-new" align="center"><a href="news.php">新闻资讯/NEWS More</a></p>
	    </div>
	<div class="Hr"></div>
<!-- 新闻资讯/NEWS More 左侧布局 -->


<!-- start 新闻资讯 -->

<!--start 左侧内容 -->
<div class="footr-Left">
			<div class="row">
				<?php
					$dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=4 AND flag LIKE '%c%' AND delstate='' AND checkinfo=true ORDER BY orderid ASC LIMIT 1,1");
					while($row = $dosql->GetArray())
					{
					if($row['linkurl'] != '')$gourl = $row['linkurl'];
					else $gourl = 'javascript:;';
				?>
				    <div class="col-lg-6 col-md-6 col-xs-6" id="my-col" >
					    <aside>
							<p>
								<img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>">
							</p>
							<div class="n-my-font"><?php echo $row['content']; ?></div>
						</aside>
				    </div>
			    <?php
					}
				?>
<!--end 左侧内容 -->

<!-- 右侧内容 -->
				<?php
					$dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=4 AND flag LIKE '%j%' AND delstate='' AND checkinfo=true ORDER BY orderid ASC");
					while($row = $dosql->GetArray())
					{
					if($row['linkurl']=='' and $cfg_isreurl!='Y')
					$gourl = 'newsshow.php?cid='.$row['classid'].'&id='.$row['id'];
					else if($cfg_isreurl=='Y')
						$gourl = 'newsshow-'.$row['classid'].'-'.$row['id'].'-1.html';
					else
						$gourl = $row['linkurl'];
				?>

				<div class="col-lg-6 col-md-6">
					<div class="n-right-div">
					   <div class="footr-right">
					<ul class="news-Ul">
					<p class="myNesul"></p> 
					<li><a href="<?php echo $gourl ?> "><?php echo $row['description']; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo GetDatetime($row['posttime']); ?></a></li>
					</ul>
						</div>
					</div>
				</div>
				<?php
					}
				?>
			</div>
			</div>
		</div>
	</div>
<!--end 右侧内容 -->
<!-- end 新闻资讯 -->
<!-- footer-->
<?php require_once('footer.php'); ?>
<!-- /footer-->



</body>
</html>
