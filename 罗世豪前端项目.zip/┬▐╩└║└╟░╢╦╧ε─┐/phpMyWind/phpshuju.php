<div class="banner">
	<div id="slideplay">
		<ul>
			<?php
			$dosql->Execute("SELECT * FROM `#@__infoimg` WHERE classid=13 AND delstate='' AND checkinfo=true ORDER BY orderid DESC LIMIT 0,5");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl'] != '')$gourl = $row['linkurl'];
				else $gourl = 'javascript:;';
			?>
			<li><a href="<?php echo $gourl; ?>"><img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>" /></a></li>
			<?php
			}
			?>
		</ul>
	</div>
</div>
<!-- /banner-->
<!-- notice-->
<div class="notice">
	<div class="notice_a"><strong>网站公告：</strong><?php echo Info(1); ?></div>
	<div class="search">
		<form name="search" id="search" method="get" action="product.php">
			<input type="text" name="keyword" id="keyword" title="输入产品名进行搜索" value="" class="key" />
			<button type="submit" id="search_btn" class="sub"><span>搜索</span></button>
		</form>
	</div>
</div>
<!-- /notice-->
<!-- mainbody-->
<div class="mainbody">
	<!-- mainbody 1of2 2of2-->
	<div class="OneOfTwo">
		<!-- newslist-->
		<div class="newwarp">
			<div class="newstitle">
			<?php
			if($cfg_isreurl!='Y') $gourl = 'news.php';
			else $gourl = 'news.html';
			?>
			<a href="<?php echo $gourl; ?>">更多&gt;&gt;</a></div>
			<div class="newsfocus">
				<?php
				$row = $dosql->GetOne("SELECT * FROM `#@__infolist` WHERE classid=4 AND flag LIKE '%h%' AND delstate='' AND checkinfo=true ORDER BY orderid DESC");
				if(isset($row['id']))
				{
					//获取链接地址
					if($row['linkurl']=='' and $cfg_isreurl!='Y')
						$gourl = 'newsshow.php?cid='.$row['classid'].'&id='.$row['id'];
					else if($cfg_isreurl=='Y')
						$gourl = 'newsshow-'.$row['classid'].'-'.$row['id'].'-1.html';
					else
						$gourl = $row['linkurl'];

					//获取缩略图地址
					if($row['picurl']!='')
						$picurl = $row['picurl'];
					else
						$picurl = 'templates/default/images/nofoundpic.gif';
				?>
				<div><a href="<?php echo $gourl; ?>"><img src="<?php echo $picurl; ?>" /></a></div>
				<h3><a href="<?php echo $gourl; ?>" style="color:<?php echo $row['colorval']; ?>;font-weight:<?php echo $row['boldval']; ?>;"><?php echo ReStrLen($row['title'],16); ?></a></h3>
				<p><?php echo ReStrLen($row['description'],34); ?></p>
				<?php
				}
				else
				{
					echo '网站资料更新中...';
				}
				?>
			</div>
			<ul class="newslist">
				<?php $dosql->Execute("SELECT * FROM `#@__infolist` WHERE (classid=4 or parentid=4) AND delstate='' AND checkinfo=true ORDER BY orderid DESC LIMIT 0,3");
				while($row = $dosql->GetArray())
				{
					//获取链接地址
					if($row['linkurl']=='' and $cfg_isreurl!='Y')
						$gourl = 'newsshow.php?cid='.$row['classid'].'&id='.$row['id'];
					else if($cfg_isreurl=='Y')
						$gourl = 'newsshow-'.$row['classid'].'-'.$row['id'].'-1.html';
					else
						$gourl = $row['linkurl'];
				?>
				<li><span><?php echo MyDate('m-d', $row['posttime']); ?></span>· <a href="<?php echo $gourl; ?>" style="color:<?php echo $row['colorval']; ?>;font-weight:<?php echo $row['boldval']; ?>;"><?php echo ReStrLen($row['title'],19); ?></a></li>
				<?php
				}
				?>
			</ul>
		</div>
		<!-- /newslist-->
		<!-- aboutus-->
		<div class="aboutus"><img src="<?php echo InfoPic(3); ?>" width="154" height="83" />
		<?php
		if($cfg_isreurl!='Y') $gourl = 'about.php';
		else $gourl = 'about.html';
		echo Info(3,147,$gourl);
		?>
		</div>
		<!-- /aboutus-->
		<div class="cl"></div>
	</div>
	<div class="TowOfTow">
		<div class="contact"> <?php echo Info(10); ?> </div>
		<div class="follow"><a href="http://weibo.com/phpMyWind" class="sina" target="_blank">收听新浪微博</a><a href="http://t.qq.com/phpMyWind" class="tqq" target="_blank">收听腾讯微博</a></div>
	</div>
	<div class="cl"></div>
	<!-- /mainbody 1of2 2of2-->
	<!-- product-->
	<div class="scrollimg">
		<div class="imgwrap">
			<ul>
				<?php
				$dosql->Execute("SELECT * FROM `#@__infoimg` WHERE (classid=5 OR parentstr LIKE '%,5,%') AND delstate='' AND checkinfo=true ORDER BY orderid DESC LIMIT 0,18");
				while($row = $dosql->GetArray())
				{
					//获取链接地址
					if($row['linkurl']=='' and $cfg_isreurl!='Y')
						$gourl = 'productshow.php?cid='.$row['classid'].'&id='.$row['id'];
					else if($cfg_isreurl=='Y')
						$gourl = 'productshow-'.$row['classid'].'-'.$row['id'].'-1.html';
					else
						$gourl = $row['linkurl'];

					//获取缩略图地址
					if($row['picurl']!='')
						$picurl = $row['picurl'];
					else
						$picurl = 'templates/default/images/nofoundpic.gif';
				?>
				<li>
					<dl>
						<dt><a href="<?php echo $gourl; ?>"><img src="<?php echo $picurl; ?>" title="<?php echo $row['title']; ?>" /></a></dt>
						<dd><a href="<?php echo $gourl; ?>"><?php echo $row['title']; ?></a><?php echo $row['keywords']; ?></dd>
					</dl>
				</li>
				<?php
				}
				?>
			</ul>
		</div>
	</div>
	<!-- /product-->
</div>
<!-- /mainbody-->
<?php require_once('footer.php'); ?>


<!-- 解决方案页面 -->

<div class="subBanner"> <img src="templates/default/images/banner-ir.png" /> </div>
<!-- /banner-->
<!-- notice-->
<div class="subnotice"><strong>网站公告：</strong><?php echo Info(1); ?></div>
<!-- /notice-->
<!-- mainbody-->
<div class="subBody">
	<div class="subTitle"> <span class="catname"><?php echo GetCatName($cid); ?></span> <span class="fr">您当前所在位置：<?php echo GetPosStr($cid); ?></span>
		<div class="cl"></div>
	</div>
	<div class="OneOfTwo">
		<div class="subCont">
			<ul class="caselist">
				<?php

				$dopage->GetPage("SELECT * FROM `#@__infoimg` WHERE (classid=$cid OR parentstr LIKE '%,$cid,%') AND delstate='' AND checkinfo=true ORDER BY orderid DESC",5);
				while($row = $dosql->GetArray())
				{
					if($row['picurl'] != '') $picurl = $row['picurl'];
					else $picurl = 'templates/default/images/nofoundpic.gif';
					
					if($row['linkurl']=='' and $cfg_isreurl!='Y') $gourl = 'caseshow.php?cid='.$row['classid'].'&id='.$row['id'];
					else if($cfg_isreurl=='Y') $gourl = 'caseshow-'.$row['classid'].'-'.$row['id'].'-1.html';
					else $gourl = $row['linkurl'];

					$r = $dosql->GetOne("SELECT `classname` FROM `#@__infoclass` WHERE id=".$row['classid']);
					if(isset($r['classname'])) $classname = $r['classname'];
					else $classname = '';

					if($cfg_isreurl!='Y') $gourl2 = 'case.php?cid='.$row['classid'];
					else $gourl2 = 'case-'.$row['classid'].'-1.html';
				?>
				<li>
					<p class="preview"><a href="<?php echo $gourl; ?>" class="img"><img src="<?php echo $picurl; ?>" /></a></p>
					[<a href="<?php echo $gourl2; ?>" class="type"><?php echo $classname; ?></a>] <a href="<?php echo $gourl; ?>" class="title" style="color:<?php echo $row['colorval']; ?>;font-weight:<?php echo $row['boldval']; ?>;"><?php echo $row['title']; ?></a> <span> 日期：<small><?php echo GetDateMk($row['posttime']); ?></small>点击：<small><?php echo $row['hits']; ?></small></span>
					<p class="desc"><?php echo ReStrLen($row['description'],90); ?></p>
					<div class="cl"></div>
				</li>
				<?php
				}
				?>
			</ul>
			<?php echo $dopage->GetList(); ?>
		</div>
	</div>
	<div class="TwoOfTwo">
		<?php require_once('lefter.php'); ?>
	</div>
	<div class="cl"></div>
</div>

<!-- 关于我们页面 -->

<div class="subBanner"> <img src="templates/default/images/banner-ir.png" /> </div>
<!-- /banner-->
<!-- notice-->
<div class="subnotice"><strong>网站公告：</strong><?php echo Info(1); ?></div>
<!-- /notice-->
<!-- mainbody-->
<div class="subBody">
	<div class="subTitle"> <span class="catname"><?php echo GetCatName($cid); ?></span> <span class="fr">您当前所在位置：<?php echo GetPosStr($cid); ?></span>
		<div class="cl"></div>
	</div>
	<div class="OneOfTwo">
		<div class="subCont"> <?php echo Info($cid); ?> </div>
	</div>
	<div class="TwoOfTwo">
		<?php require_once('lefter.php'); ?>
	</div>
	<div class="cl"></div>
</div>
<!-- /mainbody-->





<!-- 新闻资讯页面 -->
<div class="subBanner"> <img src="templates/default/images/banner-ir.png" /> </div>
<!-- /banner-->
<!-- notice-->
<div class="subnotice"><strong>网站公告：</strong><?php echo Info(1); ?></div>
<!-- /notice-->
<!-- mainbody-->
<div class="subBody">
	<div class="subTitle"> <span class="catname"><?php echo GetCatName($cid); ?></span> <span class="fr">您当前所在位置：<?php echo GetPosStr($cid); ?></span>
		<div class="cl"></div>
	</div>
	<div class="OneOfTwo">
		<div class="subCont">
			<ul class="news_list2">
				<?php

				$dopage->GetPage("SELECT * FROM `#@__infolist` WHERE (classid=$cid OR parentstr LIKE '%,$cid,%') AND delstate='' AND checkinfo=true ORDER BY orderid DESC",8);
				while($row = $dosql->GetArray())
				{
					if($row['linkurl']=='' and $cfg_isreurl!='Y') $gourl = 'newsshow.php?cid='.$row['classid'].'&id='.$row['id'];
					else if($cfg_isreurl=='Y') $gourl = 'newsshow-'.$row['classid'].'-'.$row['id'].'-1.html';
					else $gourl = $row['linkurl'];

					$row2 = $dosql->GetOne("SELECT `classname` FROM `#@__infoclass` WHERE `id`=".$row['classid']);
					if($cfg_isreurl!='Y') $gourl2 = 'news.php?cid='.$row['classid'];
					else $gourl2 = 'news-'.$row['classid'].'-1.html';
				?>
			<li> <span class="title"><a href="<?php echo $gourl; ?>" style="color:<?php echo $row['colorval']; ?>;font-weight:<?php echo $row['boldval']; ?>;"><?php echo $row['title']; ?></a></span><span class="hits">点击次数：<?php echo $row['hits']; ?></span><br />
				<span class="time"><?php echo GetDateTime($row['posttime']); ?></span> <span class="class">分类：<a href="<?php echo $gourl2; ?>"><?php echo $row2['classname']; ?></a></span> </li>
			<?php
				}
				?>
			</ul>
			<?php echo $dopage->GetList(); ?>
		</div>
	</div>
	<div class="TwoOfTwo">
		<?php require_once('lefter.php'); ?>
	</div>
	<div class="cl"></div>
</div>
<!-- /mainbody-->


<!-- 加入奥昇 -->

<div class="subBanner"> <img src="templates/default/images/banner-ir.png" /> </div>
<!-- /banner-->
<!-- notice-->
<div class="subnotice"><strong>网站公告：</strong><?php echo Info(1); ?> </div>
<!-- /notice-->
<!-- mainbody-->
<div class="subBody">
	<div class="subTitle"> <span class="catname">人才招聘</span> <span>您当前所在位置：<a href="<?php echo $cfg_webpath; ?>">首页</a> &gt; <a href="join.php">人才招聘</a></span>
		<div class="cl"></div>
	</div>
	<div class="OneOfTwo">
		<div class="subCont">
			<div class="news_list">
				<ul>
					<?php
					$dopage->GetPage("SELECT * FROM `#@__job` WHERE checkinfo=true ORDER BY orderid DESC",10);
					while($row = $dosql->GetArray())
					{
						if($cfg_isreurl!='Y') $gourl = 'joinshow.php?id='.$row['id'];
						else $gourl = 'joinshow-'.$row['id'].'.html';
						
					?>
					<li><span>[<?php echo GetDateMk($row['posttime']); ?>]</span><strong>&gt;&gt;</strong><a href="<?php echo $gourl; ?>"><?php echo $row['title']; ?></a></li>
					<?php
					}
					?>
				</ul>
			</div>
			<?php echo $dopage->GetList(); ?>
		</div>
	</div>
	<div class="TwoOfTwo">
		<?php require_once('lefter.php'); ?>
	</div>
	<div class="cl"></div>
</div>