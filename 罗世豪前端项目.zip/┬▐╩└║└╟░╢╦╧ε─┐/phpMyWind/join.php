<?php require_once(dirname(__FILE__).'/include/config.inc.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php echo GetHeader(1,0,0,'人才招聘'); ?>
<link rel="stylesheet" type="text/css" href="css/joinUs.css">
	<link rel="stylesheet"  href="css/bootstrap.min.css"/>
	<script src="js/jquery.min.js"/></script>
	<script src="js/bootstrap.min.js"/></script>
<link href="templates/default/style/webstyle.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="templates/default/js/jquery.min.js"></script>
<script type="text/javascript" src="templates/default/js/top.js"></script>
</head>
<body>
<!-- header-->
<?php require_once('header.php'); ?>
<!-- /header-->
<div class="body">
<!-- 加入奥昇图片 -->
	<div class="myImg">
		    <?php
			$dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=22 AND flag LIKE '%a%' AND delstate='' AND checkinfo=true ORDER BY orderid DESC LIMIT 0,1");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl'] != '')$gourl = $row['linkurl'];
				else $gourl = 'javascript:;';
			?>
            <img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>"  width="900px" height="150px">
        <?php
			}
			?>
		</div>
	<!-- 加入奥昇导航 -->
<div class="center">
<p class="aMan"><a href="joinUs.html">加入奥昇</a></p>
<p class="seat">您当前所在的位置：<a href="index.php">首页</a> > 加入奥昇</p>
</div>
	<!-- 加入奥昇搜素 -->

	 <?php $dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=22 AND flag LIKE '%h%' AND delstate='' AND checkinfo=true ORDER BY orderid ASC LIMIT 0,1");
		while($row = $dosql->GetArray())
			{
			?>

<div class="center-work">
<div class="center-work1"><p><?php echo $row['title']; ?></p></div>
<div class="center-work2"><p><?php echo $row['content']; ?></p>
</div>
         <?php
			}
			?> 
	<div class="center-seo">
	    <label for="exampleInputEmail2">请输入职位</label>
	    <input type="text" class="mytext" id="mytext" name="keywords" placeholder="关键字..." value="" height="50px">
	    <button type="submit" class="my-button" style="width: 54px; height: 25px; ">搜索</button>
	</div>
</div>
	<!-- /加入奥昇搜素 -->

<!-- 软件研发部经理/高级软件工程师 -->
	 <?php $dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=23 AND flag LIKE '%a%' AND delstate='' AND checkinfo=true ORDER BY orderid ASC LIMIT 0,7");
		while($row = $dosql->GetArray())
			{
				if($row['linkurl']=='' and $cfg_isreurl!='Y')
					$gourl = 'newsshow.php?cid='.$row['classid'].'&id='.$row['id'];
					else if($cfg_isreurl=='Y')
						$gourl = 'newsshow-'.$row['classid'].'-'.$row['id'].'-1.html';
					else
						$gourl = $row['linkurl'];
			?>

<div class="center-work3">
<div class="center-work4"><p><a href="<?php echo $gourl ?> "><?php echo $row['title']; ?></a></p>
</div>
<div class="center-work5">
<p>职位描述：</p>
<p><p><?php echo $row['content']; ?></p></div>
		
<div class="center-seo1">
 <button type="submit" class="btn btn-default" style="width: 80px; height: 30px; background-color: #000; color: #fff ">发布时间</button>
 <em>2015-09-15</em> 有效时间:
 <button type="submit" class="btn btn-default" style="width: 70px; height: 30px; background-color:#3971fe; color: #fff">不限</button>
</div>
</div>
          <?php
			}
			?> 


<div class="myfoort">
<p align="center">共1页7条记录</p>
</div>

</div>
<!-- footer-->
<?php require_once('footer.php'); ?>
<!-- /footer-->
</body>
</html>