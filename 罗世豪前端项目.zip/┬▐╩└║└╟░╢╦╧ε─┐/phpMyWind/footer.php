  <div class="my-footss-style">
		  <div class="container">
			  	<div class="row">
				  	    <div class="col-lg-8 col-md-8 col-xs-8">
						  	       <div class="my-footss-img">
								    <img src="images/header-logo.png" alt="">
									<p>合作热线 4000998698 13968594875 公司地址：湖南省长沙市麓谷工业园8栋大楼</p>
									<p>Copyrght$2014-2015 acrose.com All Rights Reserved 网站备案 湘ICP备15016651号</p>
									<p>在逻辑上将视为一个整体的一系列页面的有机集合称为网站（Website或Web）</p>
							      </div>
				  	    </div>
				  	    <div class="col-lg-4 col-md-4 col-xs-4">
					        <div class="my-foot-Rightss">
									<p><img src="images/scanCode.PNG" height="90px"></p>
									<p>奥昇教育公众号</p>
				             </div>
				  	    </div>
			  	</div>
		  </div>
	</div>
</div>