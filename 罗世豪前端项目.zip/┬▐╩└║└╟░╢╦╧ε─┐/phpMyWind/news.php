<?php
require_once(dirname(__FILE__).'/include/config.inc.php');

//初始化参数检测正确性
$cid = empty($cid) ? 4 : intval($cid);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php echo GetHeader(1,$cid); ?>
	<link rel="stylesheet" type="text/css" href="css/news.css">
	<link rel="stylesheet"  href="css/bootstrap.min.css"/>
	<script src="js/jquery.min.js"/></script>
	<script src="js/bootstrap.min.js"/></script>
<link href="templates/default/style/webstyle.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="templates/default/js/jquery.min.js"></script>
<script type="text/javascript" src="templates/default/js/top.js"></script>
</head>
<body>
<div class="body">
<!-- header-->
<?php require_once('header.php'); ?>
<!-- /header-->
<!--新闻中心图片调整-->
	<div class="myImg">
		    <?php
			$dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=20 AND flag LIKE '%a%' AND delstate='' AND checkinfo=true ORDER BY orderid DESC LIMIT 0,1");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl'] != '')$gourl = $row['linkurl'];
				else $gourl = 'javascript:;';
			?>
            <img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>"  width="900px" height="150px">
           <a href="<?php echo $gourl ?>"><?php echo $row['title']; ?></a>

        <?php
			}
			?>
		</div>
<!--/新闻中心图片调整-->
		<div class="center">
			<p class="aMan"><a href="news.html">新闻中心</a></p>
			<p class="seat">您当前所在的位置：<a href="index.php"><?php echo GetPosStr($cid); ?></a> ></p>
       </div>

<!--新闻资讯-->
			<div class="hr"></div>
			<div class="my-news">新闻资讯</div>
			<div class="Hr"></div>

<!--新闻资讯图片排版-->

              <?php $dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=21 AND flag LIKE '%a%' AND delstate='' AND checkinfo=true ORDER BY orderid ASC LIMIT 0,3");
				while($row = $dosql->GetArray())
				{
					
				if($row['linkurl']=='' and $cfg_isreurl!='Y')
					$gourl = 'newsshow.php?cid='.$row['classid'].'&id='.$row['id'];
					else if($cfg_isreurl=='Y')
						$gourl = 'newsshow-'.$row['classid'].'-'.$row['id'].'-1.html';
					else
						$gourl = $row['linkurl'];
				?>
	<div class="center1">
     <div class="container">
		<div class="row">
		  	   <div class="col-lg-4 col-md-4 col-xs-4">
			  	       <div class="news-img">
					     <img src="<?php echo $row['picurl']; ?>" width="320px" height="150px" >
				      </div>
			     </div>
		     <div class="col-lg-8 col-md-8 col-xs-8">
		  	     <div class="news-font">
							<p class="Font"><a href="<?php echo $gourl ?> "><?php echo $row['title']; ?></a></p>
							<p class="Font1">时间:<?php echo GetDatetime($row['posttime']); ?></p>
							<p class="Font2"><?php echo $row['description']; ?></p>
			        </div>
		      </div>
		      </div>
			
		</div>
    
     </div>	
        <?php
			}
			?>
    </div>
</div>




</div>
<!-- footer-->
<?php require_once('footer.php'); ?>
<!-- /footer-->
</body>
</html>