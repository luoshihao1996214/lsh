<?php

/**
 * @brief      英文语言包
 *
 * @author     Feng <feng@phpmywind.com>
 * @since      2014-11-6 23:27:48
 * @version    1.0
 */
