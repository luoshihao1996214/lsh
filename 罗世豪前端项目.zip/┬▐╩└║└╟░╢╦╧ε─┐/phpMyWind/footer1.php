
<?php
require_once(dirname(__FILE__).'/include/config.inc.php');

//初始化参数检测正确性
$cid = empty($cid) ? 25 : intval($cid);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php echo GetHeader(1,$cid); ?>
	<link rel="stylesheet" type="text/css" href="css/footer1.css">
	<link rel="stylesheet"  href="css/bootstrap.min.css"/>
	<script src="js/jquery.min.js"/></script>
	<script src="js/bootstrap.min.js"/></script>
<link rel="stylesheet" type="text/css" href="css/about.css">
<link rel="stylesheet"  href="css/bootstrap.min.css"/>
<script src="js/jquery.min.js"/></script>
<script src="js/bootstrap.min.js"/></script>
<link href="templates/default/style/webstyle.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="templates/default/js/jquery.min.js"></script>
<script type="text/javascript" src="templates/default/js/top.js"></script>
</head>
<body>
  <div class="my-footss-style">
		  <div class="container">
			  	<div class="row">
				  	    <div class="col-lg-8 col-md-8 col-xs-8">
						  	       <div class="my-footss-img">
								    <img src="images/header-logo.png" alt="">
									<p>合作热线 4000998698 13968594875 公司地址：湖南省长沙市麓谷工业园8栋大楼</p>
									<p>Copyrght$2014-2015 acrose.com All Rights Reserved 网站备案 湘ICP备15016651号</p>
									<p>在逻辑上将视为一个整体的一系列页面的有机集合称为网站（Website或Web）</p>
							      </div>
				  	    </div>
				  	    <div class="col-lg-4 col-md-4 col-xs-4">
					        <div class="my-foot-Rightss">
									<p><img src="images/scanCode.PNG" height="90px"></p>
									<p>奥昇教育公众号</p>
				             </div>
				  	    </div>
			  	</div>
		  </div>
	</div>
</div>

</body>
</html>